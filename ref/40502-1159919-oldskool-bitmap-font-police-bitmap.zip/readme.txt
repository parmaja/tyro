Oldskool bitmap font (police bitmap)------------------------------------
Url     : http://codes-sources.commentcamarche.net/source/40502-oldskool-bitmap-font-police-bitmapAuteur  : SiZiOUSDate    : 03/08/2013
Licence :
=========

Ce document intitul� � Oldskool bitmap font (police bitmap) � issu de CommentCaMarche
(codes-sources.commentcamarche.net) est mis � disposition sous les termes de
la licence Creative Commons. Vous pouvez copier, modifier des copies de cette
source, dans les conditions fix�es par la licence, tant que cette note
appara�t clairement.

Description :
=============

Exemple montrant comment convertir une chaine de caract&egrave;re dans son &eacu
te;quivalent bitmap. 
<br />Cet exemple contient trois dossiers :
<br />
<br 
/>- bmpfont :
<br />Ce dossier contient toutes les unit&eacute;s utilis&eacute;
es pour arriver &agrave; nos fins. Consultez les deux fichiers
<br />pour plus 
d'informations.
<br />
<br />- demo : 
<br />Contient l'exemple proprement di
t. Une capture est associ&eacute;e (example.jpg).
<br />		
<br />- fontmap : 

<br />Programme permettant la visualisation d'une texture de font d&eacute;coup
&eacute;e. Une texture se trouve dans
<br />le dossier rsrc de l'exemple (font0
25.bmp). Pour l'utiliser, lancez le programme fontmap, cliquez sur
<br />browse
 et s&eacute;lectionnez votre fichier. Dans la case Cols, entrez 10 (10 colonnes
 de chars) et 6 pour
<br />les lignes. Cliquez sur Go et vous obtenez la map de
 votre font (exemple : fontmap.jpg). N'oubliez pas
<br />que vous pouvez zoomer
 sur un caract&egrave;re pour voir si c'est bien d&eacute;coup&eacute; (ou si y'
a des ajustements &agrave; faire).
<br />Une texture doit &ecirc;tre bien ajust
&eacute;e (dans le sens ou si vous avez 10 colonnes et qu'un char fait 32 de lon
gueur,
<br />la texture doit faire 10 * 32 = 320 pixels de longueur, pareil pou
r la hauteur).
<br /><a name='conclusion'></a><h2> Conclusion : </h2>
<br />I
l s'agit d'une alternative au code de Technix59, situ&eacute; ici :
<br /><a hr
ef='http://www.delphifr.com/codes/SCROLLING-AVEC-FONTE-GRAPHIQUE_21299.aspx' tar
get='_blank'>http://www.delphifr.com/codes/SCROLLING-AVEC-FONTE-GRAPHIQUE_21299.
aspx</a>
<br />
<br />Si vous souhaitez, vous pouvez venir jeter un oeil &agra
ve; mes quelques vieux sources codes que j'ai distribu&eacute; ainsi que les que
lques nouveaux (les deux derniers en fait...) que j'ai mis en ligne :
<br /><a 
href='http://sbibuilder.dc-france.com/download/?idsys=1&idcat=17' target='_blank
'>http://sbibuilder.dc-france.com/download/?idsys=1&idcat=17</a>
<br />
<br />
Have fun ...
