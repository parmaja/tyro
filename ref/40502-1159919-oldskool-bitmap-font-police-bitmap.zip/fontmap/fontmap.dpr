program fontmap;

uses
  Forms,
  main in 'main.pas' {Main_Form},
  zoom in 'zoom.pas' {Zoom_Form},
  about in 'about.pas' {AboutBox};

{$R *.res}

begin
  Application.Initialize;
  Application.CreateForm(TMain_Form, Main_Form);
  Application.CreateForm(TZoom_Form, Zoom_Form);
  //Application.CreateForm(TAboutBox, AboutBox);
  Application.Run;
end.
