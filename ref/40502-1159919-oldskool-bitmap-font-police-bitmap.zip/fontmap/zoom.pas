unit zoom;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, ExtCtrls, ComCtrls;

type
  TZoom_Form = class(TForm)
    pBottom: TPanel;
    sb: TStatusBar;
    pLeft: TPanel;
    pTop: TPanel;
    pRight: TPanel;
    iZoomed: TImage;
    Panel1: TPanel;
    bPrev: TButton;
    bClose: TButton;
    bNext: TButton;
    procedure bCloseClick(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure bPrevClick(Sender: TObject);
    procedure bNextClick(Sender: TObject);
  private
    { D�clarations priv�es }
  public
    { D�clarations publiques }
    CurrentIndex : Integer;
    procedure UpdateButtons();
    procedure SetZoomWindowSize(OneCharWidth, OneCharHeight : Integer);
  end;

var
  Zoom_Form: TZoom_Form;

implementation

{$R *.dfm}

uses
  main;

//------------------------------------------------------------------------------

procedure TZoom_Form.SetZoomWindowSize(OneCharWidth, OneCharHeight : Integer);
begin
  Constraints.MinWidth := pLeft.Width + pRight.Width + OneCharWidth * 6;
  Constraints.MinHeight := pTop.Height + pBottom.Height + sb.Height + OneCharHeight * 6;

  Width := pLeft.Width + pRight.Width + OneCharWidth * 10;
  Height := pTop.Height + pBottom.Height + sb.Height + OneCharHeight * 10;
end;

//------------------------------------------------------------------------------

procedure TZoom_Form.UpdateButtons();
begin
  bPrev.Enabled := CurrentIndex - 1 >= 0;
  bNext.Enabled := CurrentIndex + 1 < Main_Form.TotalChars;
end;

//------------------------------------------------------------------------------

procedure TZoom_Form.bCloseClick(Sender: TObject);
begin
  Close;
end;

//------------------------------------------------------------------------------

procedure TZoom_Form.FormCreate(Sender: TObject);
var
  i : Integer;
  
begin
  Panel1.Color := clBtnFace;
  
  DoubleBuffered := True;

  // supprimer le bug de transparance XP avec les TPanels
  for i := 0 to ComponentCount - 1 do
    if Components[i] is TPanel then
      (Components[i] as TPanel).ParentBackground := False;
end;

//------------------------------------------------------------------------------

procedure TZoom_Form.bPrevClick(Sender: TObject);
begin
  CurrentIndex := CurrentIndex - 1;
  Main_Form.ZoomOnChar(CurrentIndex);
end;

//------------------------------------------------------------------------------

procedure TZoom_Form.bNextClick(Sender: TObject);
begin
  CurrentIndex := CurrentIndex + 1;
  Main_Form.ZoomOnChar(CurrentIndex);
end;

//------------------------------------------------------------------------------

end.

