object Main_Form: TMain_Form
  Left = 289
  Top = 244
  Width = 536
  Height = 387
  Caption = 
    'OldSkool Chars Map Viewer - v1.2 - (C)reated by [big_fury]SiZiOU' +
    'S'
  Color = clBtnFace
  Font.Charset = ANSI_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  Position = poScreenCenter
  OnCreate = FormCreate
  OnResize = FormResize
  PixelsPerInch = 96
  TextHeight = 13
  object sb: TStatusBar
    Left = 0
    Top = 334
    Width = 528
    Height = 19
    Panels = <>
    SimplePanel = True
  end
  object lv: TListView
    Left = 4
    Top = 121
    Width = 520
    Height = 213
    Align = alClient
    Columns = <>
    LargeImages = il
    PopupMenu = pmLV
    SmallImages = il
    StateImages = il
    TabOrder = 1
    OnContextPopup = lvContextPopup
    OnDblClick = Open1Click
  end
  object Panel1: TPanel
    Left = 0
    Top = 0
    Width = 528
    Height = 121
    Align = alTop
    BevelOuter = bvNone
    TabOrder = 2
    DesignSize = (
      528
      121)
    object Label1: TLabel
      Left = 16
      Top = 83
      Width = 31
      Height = 13
      Caption = 'Lines :'
    end
    object Label2: TLabel
      Left = 20
      Top = 52
      Width = 27
      Height = 13
      Caption = 'Cols :'
    end
    object Label3: TLabel
      Left = 103
      Top = 83
      Width = 10
      Height = 13
      Caption = '@'
    end
    object Label4: TLabel
      Left = 103
      Top = 51
      Width = 10
      Height = 13
      Caption = '@'
    end
    object Label5: TLabel
      Left = 166
      Top = 83
      Width = 27
      Height = 13
      Caption = 'pixels'
    end
    object Label6: TLabel
      Left = 166
      Top = 51
      Width = 27
      Height = 13
      Caption = 'pixels'
    end
    object Label7: TLabel
      Left = 214
      Top = 83
      Width = 68
      Height = 13
      Caption = 'Chars height :'
    end
    object Label8: TLabel
      Left = 218
      Top = 52
      Width = 64
      Height = 13
      Caption = 'Chars width :'
    end
    object lCharsH: TLabel
      Left = 334
      Top = 83
      Width = 27
      Height = 13
      Caption = 'pixels'
    end
    object lCharsW: TLabel
      Left = 334
      Top = 51
      Width = 27
      Height = 13
      Caption = 'pixels'
    end
    object Label9: TLabel
      Left = 8
      Top = 3
      Width = 110
      Height = 13
      Caption = 'Bitmap image font file :'
    end
    object lWarn: TLabel
      Left = 16
      Top = 104
      Width = 54
      Height = 13
      Caption = 'WARNING'
      Font.Charset = ANSI_CHARSET
      Font.Color = clRed
      Font.Height = -11
      Font.Name = 'Tahoma'
      Font.Style = [fsBold]
      ParentFont = False
    end
    object eFontLines: TEdit
      Left = 56
      Top = 80
      Width = 41
      Height = 21
      TabOrder = 0
      Text = '6'
    end
    object eFontCols: TEdit
      Left = 56
      Top = 48
      Width = 41
      Height = 21
      TabOrder = 1
      Text = '10'
    end
    object eFile: TEdit
      Left = 8
      Top = 18
      Width = 433
      Height = 21
      Anchors = [akLeft, akTop, akRight]
      TabOrder = 2
    end
    object Button1: TButton
      Left = 448
      Top = 16
      Width = 75
      Height = 25
      Anchors = [akTop, akRight]
      Caption = '&Browse ...'
      TabOrder = 3
      OnClick = Button1Click
    end
    object Button2: TButton
      Left = 448
      Top = 48
      Width = 75
      Height = 25
      Anchors = [akTop, akRight]
      Caption = '&Go !'
      Default = True
      TabOrder = 4
      OnClick = Button2Click
    end
    object eFontHeight: TEdit
      Left = 120
      Top = 80
      Width = 41
      Height = 21
      Color = clBtnFace
      ReadOnly = True
      TabOrder = 5
    end
    object eFontWidth: TEdit
      Left = 120
      Top = 48
      Width = 41
      Height = 21
      Color = clBtnFace
      ReadOnly = True
      TabOrder = 6
    end
    object eCharsWidth: TEdit
      Left = 288
      Top = 48
      Width = 41
      Height = 21
      Color = clBtnFace
      ReadOnly = True
      TabOrder = 7
    end
    object eCharsHeight: TEdit
      Left = 288
      Top = 80
      Width = 41
      Height = 21
      Color = clBtnFace
      ReadOnly = True
      TabOrder = 8
    end
    object Button3: TButton
      Left = 448
      Top = 88
      Width = 75
      Height = 25
      Anchors = [akTop, akRight]
      Caption = '&About ...'
      TabOrder = 9
      OnClick = Button3Click
    end
  end
  object Panel2: TPanel
    Left = 0
    Top = 121
    Width = 4
    Height = 213
    Align = alLeft
    BevelOuter = bvNone
    TabOrder = 3
  end
  object Panel3: TPanel
    Left = 524
    Top = 121
    Width = 4
    Height = 213
    Align = alRight
    BevelOuter = bvNone
    TabOrder = 4
  end
  object XPManifest1: TXPManifest
    Left = 424
    Top = 128
  end
  object il: TImageList
    Left = 456
    Top = 128
  end
  object od: TOpenDialog
    DefaultExt = 'bmp'
    Filter = 'Bitmap (*.bmp;*.dib)|*.bmp;*.dib|All files (*.*)|*.*'
    Options = [ofHideReadOnly, ofFileMustExist, ofEnableSizing]
    Title = 'Select your Bitmap font'
    Left = 488
    Top = 128
  end
  object pmLV: TPopupMenu
    Left = 184
    Top = 272
    object Open1: TMenuItem
      Caption = '&Zoom'
      Default = True
      OnClick = Open1Click
    end
  end
end
