unit main;

interface

uses
  Windows, SysUtils, Messages, Graphics, Forms, Variants, Classes, XPMan,
  Controls, Dialogs, StdCtrls, ImgList, ComCtrls, ExtCtrls, Menus;

type
  TMain_Form = class(TForm)
    sb: TStatusBar;
    lv: TListView;
    Panel1: TPanel;
    Label1: TLabel;
    Label2: TLabel;
    Label3: TLabel;
    Label4: TLabel;
    Label5: TLabel;
    Label6: TLabel;
    Label7: TLabel;
    Label8: TLabel;
    lCharsH: TLabel;
    lCharsW: TLabel;
    eFontLines: TEdit;
    eFontCols: TEdit;
    eFile: TEdit;
    Button1: TButton;
    Button2: TButton;
    eFontHeight: TEdit;
    eFontWidth: TEdit;
    XPManifest1: TXPManifest;
    il: TImageList;
    od: TOpenDialog;
    eCharsWidth: TEdit;
    eCharsHeight: TEdit;
    Panel2: TPanel;
    Panel3: TPanel;
    Button3: TButton;
    Label9: TLabel;
    pmLV: TPopupMenu;
    Open1: TMenuItem;
    lWarn: TLabel;
    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure FormResize(Sender: TObject);
    procedure lvContextPopup(Sender: TObject; MousePos: TPoint;
      var Handled: Boolean);
    procedure Open1Click(Sender: TObject);
    procedure Button3Click(Sender: TObject);
  private
    fTotalChars : Integer;
    CharsCount : Word;
    Font : array of TBitmap;
    procedure LoadFont(const FromFileName : TFileName);
    procedure ShowFontMap;
    { D�clarations priv�es }
  public
    { D�clarations publiques }
    procedure ZoomOnChar(ImageIndex : Integer);
    property TotalChars : Integer read fTotalChars;
  end;

var
  Main_Form: TMain_Form;

implementation

uses
  zoom, about;

{$R *.dfm}

//------------------------------------------------------------------------------

procedure TMain_Form.LoadFont(const FromFileName : TFileName);
var
  X, Y : Word;
  i : Word;
  _font_src : TBitmap;

begin
  _font_src := TBitmap.Create;
  try
    _font_src.LoadFromFile(FromFileName);

    //initialisation du tableau de Bitmap
    CharsCount := (_font_src.Width div il.Width) * (_font_src.Height div il.Height);
    SetLength(Font, CharsCount);

    for i := 0 to CharsCount - 1 do
    begin
      if Assigned(Font[i]) then FreeAndNil(Font[i]); // d�truire l'ancien TBitmap (sinon fuite de m�moire !)
      Font[i] := TBitmap.Create;
      Font[i].Width := il.Width;
      Font[i].Height := il.Height;
    end;

    //d�coupage
    X := 0;
    Y := 0;
    
    repeat
      i := (X div il.Width)
        + ((Y div il.Height) * (_font_src.Width div il.Width));

      //extraction de la police
      Font[i].Canvas.CopyRect(Rect(0, 0, il.Width, il.Height),
        _font_src.Canvas, Rect(X, Y, il.Width + X, il.Height + Y));

      //Font[i].SaveToFile('x\' + IntToStr(i) + '.bmp');
      
      //d�calages 
      Inc(X, il.Width);

      if (X >= _font_src.Width) then
      begin
        Inc(Y, il.Height);
        X := 0;
      end;

    until (Y >= _font_src.Height);

  finally
    _font_src.Free;
  end;
end;

//------------------------------------------------------------------------------

procedure TMain_Form.ShowFontMap;
var
  i : Integer;

begin
  lv.Clear;
  
  for i := 0 to CharsCount - 1 do
  begin
    il.Add(Font[i], nil);
    
    with lv.Items.Add do
    begin
      Caption := IntToStr(i);
      ImageIndex := i;
    end;

  end;
end;

//------------------------------------------------------------------------------

procedure TMain_Form.Button1Click(Sender: TObject);
begin
  with od do
    if Execute then
      eFile.Text := Filename;
end;

//------------------------------------------------------------------------------

procedure TMain_Form.Button2Click(Sender: TObject);
var
  tmp : TImage;
  
begin
  if not FileExists(eFile.Text) then
  begin
    MessageBoxA(Handle, 'Please enter valid a filename !', 'Warning', MB_ICONWARNING);
    Exit;
  end;

  //effacer la listview et l'imagelist associ�e
  lv.Clear;
  il.Clear;
  sb.SimpleText := '';
  
  // charger la bitmap font
  tmp := TImage.Create(Self);
  try
    tmp.Picture.LoadFromFile(eFile.Text);
    tmp.AutoSize := True;
    eFontWidth.Text := IntToStr(tmp.Width);
    eFontHeight.Text := IntToStr(tmp.Height);

    // char width = bitmap font width div cols
    // char height = bitmap font height div lines
    try
      il.Width := StrToInt(eFontWidth.Text) div StrToInt(eFontCols.Text);
      il.Height := StrToInt(eFontHeight.Text) div StrToInt(eFontLines.Text);
    except
      MessageBoxA(Handle, 'Doh ! What are you doing ?', 'Warning', MB_ICONWARNING);
      Exit;
    end;

    // on affiche �a dans les edits readonly
    eCharsWidth.Text := IntToStr(il.Width);
    eCharsHeight.Text := IntToStr(il.Height);

    // on calcule si c'est carr�
    lWarn.Caption := '';
    if ((il.Width * StrToInt(eFontCols.Text)) <> tmp.Width)
      or ((il.Height * StrToInt(eFontLines.Text)) <> tmp.Height) then
        lWarn.Caption := 'WARNING ! This Bitmap Font is NOT squared !'; // PROBLEME !!!
  finally
    tmp.Free;
  end;

  // proc�der au d�coupage de la bitmap font    
  try
    sb.SimpleText := 'Parsing ...';
    LoadFont(eFile.Text);
  except
    sb.SimpleText := '';
    MessageBoxA(Handle, PChar('Sorry guy, but at least one entry parameter is wrong.' + #13#10
      + 'Make sure your bitmap font is *REALLY* squared (each chars is '
      + eCharsWidth.Text + 'x' + eCharsHeight.Text + ' *EXACTLY*).'), 'Warning', MB_ICONWARNING);
    Exit; 
  end;

  // afficher le r�sultat dans la listview
  ShowFontMap;

  fTotalChars := StrToInt(eFontCols.Text) * StrToInt(eFontLines.Text);
  sb.SimpleText := IntToStr(TotalChars) + ' characters.';
end;

//------------------------------------------------------------------------------

procedure TMain_Form.FormCreate(Sender: TObject);
begin
  Application.Title := Caption;
  Constraints.MinHeight := Height;
  Constraints.MinWidth := Width;
  lWarn.Caption := '';
end;

//------------------------------------------------------------------------------

procedure TMain_Form.FormResize(Sender: TObject);
begin
  ShowFontMap;
end;

//------------------------------------------------------------------------------

procedure TMain_Form.lvContextPopup(Sender: TObject; MousePos: TPoint;
  var Handled: Boolean);
begin
  if not Assigned(lv.Selected) then lv.PopupMenu := nil else lv.PopupMenu := pmLV;
end;

//------------------------------------------------------------------------------

procedure TMain_Form.Open1Click(Sender: TObject);
begin
  //cet evenement est associ� au double click donc faut bien v�rifier qu'il double clique sur un item
  if not Assigned(lv.Selected) then Exit;

  // ok
  ZoomOnChar(lv.Selected.ImageIndex);
end;

//------------------------------------------------------------------------------

procedure TMain_Form.ZoomOnChar(ImageIndex : Integer);
begin
  with Zoom_Form do
  begin
    CurrentIndex := ImageIndex;
    iZoomed.Picture.Bitmap := Self.Font[CurrentIndex];

    sb.SimpleText := 'Character ID : ' + IntToStr(CurrentIndex)
      + ' (Total : ' + IntToStr(TotalChars) + ')';

    UpdateButtons();

    if not Zoom_Form.Showing then
    begin
      SetZoomWindowSize(il.Width, il.Height);
      ShowModal;
    end;
  end;
end;

//------------------------------------------------------------------------------

procedure TMain_Form.Button3Click(Sender: TObject);
begin
  AboutBox := TAboutBox.Create(Application);
  try
    AboutBox.ShowModal;
  finally
    AboutBox.Free;
  end;
end;

//------------------------------------------------------------------------------

end.
