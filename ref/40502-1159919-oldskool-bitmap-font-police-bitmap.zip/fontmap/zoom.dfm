object Zoom_Form: TZoom_Form
  Left = 368
  Top = 229
  Width = 221
  Height = 229
  BorderIcons = [biSystemMenu, biMaximize]
  Caption = 'Zoom'
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Shell Dlg 2'
  Font.Style = []
  OldCreateOrder = False
  Position = poScreenCenter
  OnCreate = FormCreate
  PixelsPerInch = 96
  TextHeight = 13
  object iZoomed: TImage
    Left = 4
    Top = 4
    Width = 205
    Height = 132
    Align = alClient
    Center = True
    Stretch = True
  end
  object pBottom: TPanel
    Left = 0
    Top = 136
    Width = 213
    Height = 40
    Align = alBottom
    BevelOuter = bvNone
    TabOrder = 0
    DesignSize = (
      213
      40)
    object Panel1: TPanel
      Left = 16
      Top = 5
      Width = 185
      Height = 31
      Anchors = [akTop]
      BevelOuter = bvNone
      Color = clMaroon
      TabOrder = 0
      object bPrev: TButton
        Left = 20
        Top = 4
        Width = 33
        Height = 25
        Caption = '<'
        TabOrder = 0
        OnClick = bPrevClick
      end
      object bClose: TButton
        Left = 57
        Top = 4
        Width = 75
        Height = 25
        Caption = '&Close'
        Default = True
        TabOrder = 1
        OnClick = bCloseClick
      end
      object bNext: TButton
        Left = 136
        Top = 4
        Width = 33
        Height = 25
        Caption = '>'
        TabOrder = 2
        OnClick = bNextClick
      end
    end
  end
  object sb: TStatusBar
    Left = 0
    Top = 176
    Width = 213
    Height = 19
    Panels = <>
    SimplePanel = True
  end
  object pLeft: TPanel
    Left = 0
    Top = 4
    Width = 4
    Height = 132
    Align = alLeft
    BevelOuter = bvNone
    TabOrder = 2
  end
  object pTop: TPanel
    Left = 0
    Top = 0
    Width = 213
    Height = 4
    Align = alTop
    BevelOuter = bvNone
    TabOrder = 3
  end
  object pRight: TPanel
    Left = 209
    Top = 4
    Width = 4
    Height = 132
    Align = alRight
    BevelOuter = bvNone
    TabOrder = 4
  end
end
