program bmpfont;

uses
  Forms,
  main in 'main.pas' {frmMain},
  oldskool_font_mapper in '..\bmpfont\oldskool_font_mapper.pas',
  oldskool_font_vcl in '..\bmpfont\oldskool_font_vcl.pas';

{$R *.res}

begin
  Application.Initialize;
  Application.MainFormOnTaskbar := True;
  Application.CreateForm(TfrmMain, frmMain);
  Application.Run;
end.
