unit main;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, ExtCtrls;

type
  TfrmMain = class(TForm)
    bStart: TButton;
    iFontMap: TImage;
    iResultat: TImage;
    procedure bStartClick(Sender: TObject);
    procedure FormCreate(Sender: TObject);
  private
    { D�clarations priv�es }
  public
    { D�clarations publiques }
  end;

var
  frmMain: TfrmMain;

implementation

{$R *.dfm}

uses oldskool_font_vcl;

procedure TfrmMain.bStartClick(Sender: TObject);
var
  BitmapVcl: TOldskoolFontBitmapVcl;
  BmpBuf: TBitmap;
  Str: string;
  
begin
  InputQuery('Oldskool Font Demo', 'Entrez une petite chaine:', Str);
  if Str = '' then Exit;

  // ici le "*" sert de caract�re "� trou". C'est un choix. A chaque fois qu'il
  // y'aura un "*", �a repr�sentera un index de 0 (car NullIndex = 0)
  BitmapVcl := TOldskoolFontBitmapVcl.Create(
                                        ' !"****''()' +
                                        '**,-. 0123' +
                                        '456789:*<=' +
                                        '>**ABCDEFG' +
                                        'HIJKLMNOPQ' +
                                        'RSTUVWXYZ*', 0, '*', iFontMap.Picture.Bitmap, 6, 10);
  BmpBuf := TBitmap.Create;
  try
    BitmapVcl.DrawString(Str, BmpBuf);
    iResultat.Picture.Assign(BmpBuf);
  finally
    BitmapVcl.Free;
    BmpBuf.Free;
  end;
end;

procedure TfrmMain.FormCreate(Sender: TObject);
begin
  Application.Title := Caption;
end;

end.
