--------------------------------------------------------------------------------
--//DiscUI Map Capture Rendering
--------------------------------------------------------------------------------

--local references for optimization
local string_sub = string.sub

--local vars
local UIMapCaptureRenderCellSize = 20

--------------------------------------------------------------------------------
function UIMapCaptureRenderCharStreet(ARenderTarget, ADataChar, ADataColour, Left, Top, Right, Bottom)

   
   local CircleRadi = Vec2Length((Right-Left)/2,0)
   local QuadCorner = Vec2Length((Right-Left)/2,(Bottom-Top)/2)
   local LengthDiff = QuadCorner-CircleRadi   
   local NLeft, NTop = Vec2Mul(-1,-1,LengthDiff)   
   local NRight, NBottom = Vec2Mul(1,1,LengthDiff)
   local FLineWidth = 5        
   NLeft = (Left+NLeft)--+FLineWidth
   NTop = (Top+NTop)--+FLineWidth
   NRight = (Right+NRight)---FLineWidth
   NBottom = (Bottom+NBottom)---FLineWidth
   
   ARenderTarget.LineWidth(FLineWidth)      
     
     
   if (ADataChar == '|') then
      ARenderTarget.Line(Left+(Right-Left)/2, Top,Left+(Right-Left)/2, Bottom)
   elseif (ADataChar == '-') then
      ARenderTarget.Line( Left, Top+(Bottom-Top)/2, Right, Top+(Bottom-Top)/2)
   elseif (ADataChar == '\\') then      
      ARenderTarget.Line(NLeft,NTop,NRight,NBottom)
   elseif (ADataChar == '/') then
    ARenderTarget.Line(NLeft,NBottom,NRight,NTop)
   elseif (ADataChar == 'x') then
    ARenderTarget.Line(NLeft,NTop,NRight,NBottom)
    ARenderTarget.Line(NLeft,NBottom,NRight,NTop)
   end
       
end
--------------------------------------------------------------------------------
function UIMapCaptureRenderCharOther(ARenderTarget, ADataChar, ADataColour, Left, Top, Right, Bottom)

   
   local CircleRadi = Vec2Length((Right-Left)/2,0)
   local QuadCorner = Vec2Length((Right-Left)/2,(Bottom-Top)/2)
   local LengthDiff = QuadCorner-CircleRadi   
   local NLeft, NTop = Vec2Mul(-1,-1,LengthDiff)   
   local NRight, NBottom = Vec2Mul(1,1,LengthDiff)
   local FLineWidth = 1        
   NLeft = (Left+NLeft)+FLineWidth
   NTop = (Top+NTop)+FLineWidth
   NRight = (Right+NRight)-FLineWidth
   NBottom = (Bottom+NBottom)-FLineWidth
   
   ARenderTarget.LineWidth(FLineWidth)      
     
     
   if (ADataChar == '+') then      
      ARenderTarget.LineColour(0x777777)
      ARenderTarget.CircleColour(ADataColour)
      ARenderTarget.Circle(Left+4, Top+4, Right-4, Bottom-4)
   else   
      --if UIMapBuffer.CurrentRegion.RegionType == 2 then                           
         if (ADataChar == '*') or (ADataChar == '&') or (ADataChar == '$') or (ADataChar == '@') then
            if (ADataChar == '*') then
            ADataColour = 0x222222
            end                   
            ARenderTarget.LineColour(0x777777)
            ARenderTarget.CircleColour(ADataColour)
            ARenderTarget.Circle(Left,Top,Right,Bottom)
         else
      --else
         local ACharWidthDiv2 = UIMapCaptureRenderCellSize/2 --ARenderTarget.TextWidth(ADataChar, ARenderTarget.Font) / 2
         local ACharHeightDiv2 = UIMapCaptureRenderCellSize/2 --ARenderTarget.TextHeight(ADataChar, ARenderTarget.Font) / 2      
               
         ARenderTarget.TextColour(ADataColour)
         ARenderTarget.Text(ADataChar, ARenderTarget.Font, Left+ACharWidthDiv2, Top+ACharHeightDiv2, Right, Bottom)
      end                   
   
   --else
   --   local ACharWidthDiv2 = UIMapCaptureRenderCellSize/2 --ARenderTarget.TextWidth(ADataChar, ARenderTarget.Font) / 2
   --   local ACharHeightDiv2 = UIMapCaptureRenderCellSize/2 --ARenderTarget.TextHeight(ADataChar, ARenderTarget.Font) / 2      
               
   --   ARenderTarget.TextColour(ADataColour)
   --   ARenderTarget.Text(ADataChar, ARenderTarget.Font, Left+ACharWidthDiv2, Top+ACharHeightDiv2, Right, Bottom)
   end
       
end
--------------------------------------------------------------------------------
function UIMapCaptureRenderToTarget(ARenderTarget, AViewportLeft, AViewportTop, AViewportRight, AViewportBottom)

   local AX = 0
   local AY = 0
   local AXPixels = 0
   local AYPixels = 0
   local AXPixelsOffset = 0
   local AYPixelsOffset = 0 
   
   local ADataTextLine = ""
   local ADataColourLine = ""
   local ADataChar = ""
   local ADataColour = 0
   
   local ACharWidthDiv2 = 0
   local ACharHeightDiv2 = 0
   
   UIWindowMapLocal.RectColour(0x0000002)
   UIWindowMapLocal.Rect(AViewportLeft,AViewportTop,AViewportRight,AViewportBottom)
   
   
   
   if ((UIMapCaptureCellHeight > 0) and (UIMapCaptureCellWidth > 0)) then
                        
      local AXCapture = (((UIMapCapturePlayerPositionX)) * UIMapCaptureRenderCellSize)      
      local AYCapture = ((( UIMapCapturePlayerPositionY)) * UIMapCaptureRenderCellSize) 
           
         
      AXPixelsOffset = (((AViewportRight-AViewportLeft) / 2) - AXCapture)
      AYPixelsOffset = (((AViewportRight-AViewportLeft) / 2) - AYCapture)
      
      --Render Streets
      for AY = 1, UIMapCaptureCellHeight do
         AYPixels = (AY) * UIMapCaptureRenderCellSize
         ADataTextLine = UIMapCaptureDataText[AY]
         ADataColourLine = UIMapCaptureDataColour[AY]            
         for AX = 1, UIMapCaptureCellWidth do
            AXPixels = (AX) * UIMapCaptureRenderCellSize
                        
            ADataChar = string_sub(ADataTextLine,AX,AX)
            
            if (ADataChar == "|") or (ADataChar == "-") or (ADataChar == "\\") or (ADataChar == "/") or (ADataChar == "x") then
                                                    
               ADataColour = string_sub(ADataColourLine,AX,AX)            
               ADataColour = string.byte(ADataColour)-47                                     
               ADataColour = UIMapColours[ADataColour]
               
               local ACharWidthDiv2 = UIMapCaptureRenderCellSize/2 --ARenderTarget.TextWidth(ADataChar, ARenderTarget.Font) / 2
               local ACharHeightDiv2 = UIMapCaptureRenderCellSize/2 --ARenderTarget.TextHeight(ADataChar, ARenderTarget.Font) / 2          
                                                                                                                                                                                     
               UIMapCaptureRenderCharStreet(ARenderTarget, ADataChar, ADataColour,
                  AXPixelsOffset + AXPixels - ACharWidthDiv2, 
                  AYPixelsOffset + AYPixels - ACharHeightDiv2, 
                  AXPixelsOffset + AXPixels - ACharWidthDiv2 + UIMapCaptureRenderCellSize + 1, 
                  AYPixelsOffset + AYPixels - ACharHeightDiv2 + UIMapCaptureRenderCellSize + 1)
            end
         end 
      end
          
      --Render Rooms/Other
      for AY = 1, UIMapCaptureCellHeight do
         AYPixels = (AY) * UIMapCaptureRenderCellSize
         ADataTextLine = UIMapCaptureDataText[AY]
         ADataColourLine = UIMapCaptureDataColour[AY]            
         for AX = 1, UIMapCaptureCellWidth do
            AXPixels = (AX) * UIMapCaptureRenderCellSize
                        
            ADataChar = string_sub(ADataTextLine,AX,AX)
            
            if not ((ADataChar == "|") or (ADataChar == "-") or (ADataChar == "\\") or (ADataChar == "/") or (ADataChar == "x")) then
                                                    
               ADataColour = string_sub(ADataColourLine,AX,AX)            
               ADataColour = string.byte(ADataColour)-47                                     
               ADataColour = UIMapColours[ADataColour]
               
               local ACharWidthDiv2 = UIMapCaptureRenderCellSize/2 --ARenderTarget.TextWidth(ADataChar, ARenderTarget.Font) / 2
               local ACharHeightDiv2 = UIMapCaptureRenderCellSize/2 --ARenderTarget.TextHeight(ADataChar, ARenderTarget.Font) / 2          
                                                                                                                                                                                     
               UIMapCaptureRenderCharOther(ARenderTarget, ADataChar, ADataColour,
                  AXPixelsOffset + AXPixels - ACharWidthDiv2, 
                  AYPixelsOffset + AYPixels - ACharHeightDiv2, 
                  AXPixelsOffset + AXPixels - ACharWidthDiv2 + UIMapCaptureRenderCellSize + 1, 
                  AYPixelsOffset + AYPixels - ACharHeightDiv2 + UIMapCaptureRenderCellSize + 1)
            end
         end 
      end   
   end
   
   --Render Living Objects String
   
   local AStringHeight = ARenderTarget.TextHeight("!0,gI~�XyqQ", ARenderTarget.Font)
   local AStringBorder = 5
   local AStringLineSpacing = 2
   local AStringWidth = (AViewportRight-AStringBorder)-(AViewportLeft+AStringBorder) 
   local AStringLeft = AViewportLeft+AStringBorder
   local AStringTop = AViewportTop+AStringBorder
   local AStringRight = AViewportRight-AStringBorder
   local AStringBottom = AViewportTop+AStringBorder+AStringHeight  
   local AStringY = AStringTop
   local AObjectsLivingString = ""
   ARenderTarget.TextColour(0x00FFFF)   
   
      
   for AX = 1, #UIMapCaptureRoomObjectsLiving do
   
      --if the width has gone over, wrap around
      if ARenderTarget.TextWidth(AObjectsLivingString .. UIMapCaptureRoomObjectsLiving[AX], ARenderTarget.Font) > AStringWidth then
         
         
         ARenderTarget.Text(AObjectsLivingString, ARenderTarget.Font, 
         AStringLeft, AStringY, AStringRight, AStringY+AStringHeight)
                  
         AStringY = AStringY + AStringHeight + AStringLineSpacing
         AObjectsLivingString = ""         
      end
      
      AObjectsLivingString = AObjectsLivingString .. UIMapCaptureRoomObjectsLiving[AX]      
      if (AX < #UIMapCaptureRoomObjectsLiving) then
         AObjectsLivingString = AObjectsLivingString .. ", "
      end      
   end
   
   ARenderTarget.Text(AObjectsLivingString, ARenderTarget.Font, 
      AStringLeft, AStringY, AStringRight, AStringY+AStringHeight)
   
   
   
   --Render Exit Strings
   
   local AExitString = ""
   for AX = 1, #UIMapCaptureDataRoomExits do
   
      --AExitString = AExitString .. UIMapDirectionConvert[ UIMapCaptureDataRoomExits[AX]]
         
      AExitString = AExitString .. string.upper(UIMapCaptureDataRoomExits[AX])
      
      if (AX < #UIMapCaptureDataRoomExits) then
         AExitString = AExitString .. ", "
      end
   end
   
   --AExitString = StringCapitalizeAll(AExitString)
   
   AStringHeight = ARenderTarget.TextHeight(AExitString, ARenderTarget.Font)   
      
   ARenderTarget.TextColour(0x0000FF)
   ARenderTarget.Text(AExitString, ARenderTarget.Font, 
      AViewportLeft + AStringBorder, 
      AViewportBottom-(AStringHeight+AStringBorder), 
      AViewportRight-AStringBorder, 
      AViewportBottom-AStringBorder)
      
   --UIMapCaptureDataRoomExits = {}
   
end