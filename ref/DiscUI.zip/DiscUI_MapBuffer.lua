--------------------------------------------------------------------------------
--//DiscUI Map Buffer Variables
--------------------------------------------------------------------------------
local UIMapBufferCounter = 0 -- Global private variable

--local references for optimization
local round = round
local math_floor = math.floor  
local math_ceil = math.ceil
local table_insert = table.insert
local string_sub = string.sub
local string_char = string.char
local string_format = string.format

--The map buffer controlled by movement in the mud
UIMapBuffer = {}

function UIBufferQueueItemReset(AItem)  
   AItem.Type = 0 --the type of request, region, sector, rooms intersecting geometric region etc
   AItem.Data = {} --the instance to populate
end
 
function UIMapBufferCreate()   
   --create self instance
   local self = {}
   self.id = UIMapBufferCounter
   UIMapBufferCounter = UIMapBufferCounter + 1
         
   -----------------------------------------------------------------------------
   --Private                                                             Private
   -----------------------------------------------------------------------------   
         
   local FDirectionAttemptQueue = {}    
            
   --Capture data cell rect
   local FCaptureCellWidth = 0
   local FCaptureCellHeight = 0   
   local FCaptureCellLeft = 0
   local FCaptureCellTop = 0
   local FCaptureCellRight = 0
   local FCaptureCellBottom = 0   
   
   --Capture data sector rect
   local FCaptureSectorLeft = 0
   local FCaptureSectorTop = 0
   local FCaptureSectorRight = 0
   local FCaptureSectorBottom = 0   
      
   --Region processing queues
   local FQueueRegionGetSectors = {}
   local FQueueRegionGetRooms = {}
   local FQueueRegionGetStreets = {}
   local FQueueRegionGetChildren = {}
   
   --Tracking Mode
   local FMapTrackingRoomHistory = {}
   
      
   -----------------------------------------------------------------------------
   --Public                                                               Public
   -----------------------------------------------------------------------------
   
   
   self.TrackingMode = true
   
   self.MergeRooms = false
   self.MergeSectors = false
      
   self.Regions = {} --RegionID indexed      
   self.Sectors = {} -- SectorID indexed      
   self.Rooms = {}  -- RoomID indexed   
   self.Places = {} -- PlaceID Indexed
   self.Streets = {} -- StreetID Indexed
          
   self.RootRegion = nil   
   self.CurrentRegion = nil
   self.CurrentSector = nil  
   self.CurrentRoom = nil   
   self.CurrentPortal = nil   
   self.CurrentPlace = nil   
   self.CurrentStreet = nil
   
   self.PreviousRegion = nil
   self.PreviousSector = nil     
   self.PreviousRoom = nil
     
   self.PreviousDirection = ""   
   self.PreviousDirectionVectorX = 0
   self.PreviousDirectionVectorY = 0
   self.PreviousDirectionVectorZ = 0
   
   self.PlayerPositionX = 0
   self.PlayerPositionY = 0
   self.PlayerPositionZ = 0
                        
   self.SectorLeft = 0 
   self.SectorTop = 0
   self.SectorRight = 0
   self.SectorBottom = 0
      
   self.CellLeft = 0
   self.CellTop = 0
   self.CellRight = 0
   self.CellBottom = 0
   self.CellWidth = 0
   self.CellHeight = 0
               
   self.HoveringRoom = nil
   self.HoveringStreet = nil      
   self.SelectedRegions = {}
   self.SelectedRooms = {}
   self.SelectedPlaces = {}
   self.SelectedStreets = {}  
   
   --A* Path Finding
   self.Path = {}
   self.PathRoomStart = nil
   self.PathRoomEnd = nil      
   
   
   
   local BufferQueue = {} --DB load request queue
      
   function BufferQueue.new(AType, AData, AMinX, AMinY, AMaxX, AMaxY)
      return {
         first = 0, 
         last = -1,
         Type = AType,
         Data = AData,
         MinX = AMinX,
         MinY = AMinY,
         MaxX = AMaxX,
         MaxY = AMaxY        
         }
   end
   function BufferQueue.pushleft(value)
      local first = BufferQueue.first - 1
      BufferQueue.first = first
      BufferQueue[first] = value
   end
    
   function BufferQueue.pushright(value)
      local last = BufferQueue.last + 1
      BufferQueue.last = last
      BufferQueue[last] = value
   end
    
   function BufferQueue.popleft()
      local first = BufferQueue.first
      if first > BufferQueue.last then return nil end
      local value = BufferQueue[first]
      BufferQueue[first] = nil        -- to allow garbage collection
      BufferQueue.first = first + 1
      return value
   end
    
   function BufferQueue.popright()
      local last = BufferQueue.last
      if BufferQueue.first > last then return nil end
      local value = BufferQueue[last]
      BufferQueue[last] = nil         -- to allow garbage collection
      BufferQueue.last = last - 1
      return value
   end 
   
   
   --Buffer some stuff from the database, try not to exceeds MaxMS
   function self.ProcessBufferQueue(MaxMS)
      
      local TickStart = UIMushGetTimeMS()
      local TickDelta = 0
      local CurrentItem = {}
       
      while TickDelta < MaxMS do
      
         CurrentItem = BufferQueue.popleft()       
         
         if CurrentItem.Type == 1 then
            self.RegionGet(CurrentItem.Data.RegionID)         
         end
         
         if CurrentItem.Type == 2 then
            self.SectorGet(CurrentItem.Data.SectorID)         
         end
         
         if CurrentItem.Type == 3 then         
            self.RoomGet(CurrentItem.Data.RoomID)         
         end         
                              
         TickDelta = UIMushGetTimeMS() - TickStart      
      end 
   
   end   
   
         
   function self.TrackingModeAddCurrentRoom()
   
      local ATrackingItem = {}
      UIMapTrackingItemReset(ATrackingItem)
      
      
      
      ATrackingItem.RoomName = UIMapCaptureRoomName
      ATrackingItem.Exits = UIMapCaptureDataRoomExits
      
      --if UI_DebugMapBuffer then
         UILog("UIMapBuffer.TrackingModeAddCurrentRoom","Adding Room '"..ATrackingItem.RoomName.."'")
         
         local SExits = ""
         for I = 1, #ATrackingItem.Exits do
            SExits = SExits .. ATrackingItem.Exits[I] .. ","
         end
         UILog("UIMapBuffer.TrackingModeAddCurrentRoom","Exits '"..SExits.."'")
      --end                   
      
      table.insert(FMapTrackingRoomHistory, ATrackingItem)      
   end 
   
   
   function self.TrackingModeQuery()
            
      local RoomName = UIDatabasePrepareString(FMapTrackingRoomHistory[#FMapTrackingRoomHistory].RoomName)
      
      --Query Tracking List to see if we have a match
      DatabasePrepare(UIDatabaseMap, string_format(       
      "SELECT RoomID, RegionID, SectorID, RoomTypeID, RoomSubTypeID, RoomPositionX, RoomPositionY, RoomPositionZ, RoomName, RoomDescription, ExitNorth, ExitNorthType, ExitNorthEast, ExitNorthEastType, ExitEast, ExitEastType, ExitSouthEast, ExitSouthEastType, ExitSouth, ExitSouthType, ExitSouthWest, ExitSouthWestType, ExitWest, ExitWestType, ExitNorthWest, ExitNorthWestType, ExitUp, ExitUpType, ExitDown, ExitDownType FROM Rooms WHERE (RoomName = %s)",
      RoomName))
      
      local ColumnCount = DatabaseColumns(UIDatabaseMap)      
      local ColumnNames = DatabaseColumnNames(UIDatabaseMap)         
      local Row = DatabaseStep(UIDatabaseMap)   
      local RowValues = {}
      local I = 0                                        
      -- Loop Result Rows
      while Row == sqlite3.ROW do        
         I=I+1
         RowValues = DatabaseColumnValues(UIDatabaseMap)            
         --AArray[I] = RowValues[1]                            
         Row = DatabaseStep(UIDatabaseMap)         
      end 
   
      DatabaseFinalize(UIDatabaseMap)
      
      if (I == 1) then
      
         self.TrackingModeFound(RowValues[1])
                        
         self.TrackingMode = false
                  
      end      
      --"SELECT RoomID, RegionID, SectorID, RoomTypeID, RoomSubTypeID, RoomPositionX, RoomPositionY, RoomPositionZ, RoomName, RoomDescription, ExitNorth, ExitNorthType, ExitNorthEast, ExitNorthEastType, ExitEast, ExitEastType, ExitSouthEast, ExitSouthEastType, ExitSouth, ExitSouthType, ExitSouthWest, ExitSouthWestType, ExitWest, ExitWestType, ExitNorthWest, ExitNorthWestType, ExitUp, ExitUpType, ExitDown, ExitDownType FROM Rooms WHERE (RoomName = %s) and (RoomPositionX = %i) and (RoomPositionY = %i) and (RoomPositionZ = %i)",
      --ARegionID, APositionX, APositionY, APositionZ))
      
      return I
   end  
   
   function self.TrackingModeFound(ARoomID)
      local ARoom = self.RoomGet(ARoomID) 
      self.CurrentRoom = ARoom 
      self.CurrentSector = self.SectorGet(self.CurrentRoom.SectorID)
      self.CurrentRegion = self.RegionGet(self.CurrentRoom.RegionID)
      self.PlayerPositionX = ARoom.RoomPositionX
      self.PlayerPositionY = ARoom.RoomPositionY
      self.PlayerPositionZ = ARoom.RoomPositionZ
 
      local FWorldX, FWorldY, FWorldZ = self.RegionGetWorldPos(self.CurrentRegion,ARoom.RoomPositionX,ARoom.RoomPositionY,ARoom.RoomPositionZ)    
    
      --Move the camera to track the players position  
      UIWindowMap.CameraPositionX = FWorldX
      UIWindowMap.CameraPositionY = FWorldY            
      UIWindowMap.CameraScale = self.RegionGetWorldScale(self.CurrentRegion, 1)
      UIWindowMap.CellSize = (UIWindowMapUnitSize*UIWindowMap.CameraScale)
      UIWindowMap.CellSizeDiv2 = UIWindowMap.CellSize / 2
      UIWindowMap.CellSizeDiv4 = UIWindowMap.CellSize / 4
      UIWindowMap.CellSizeDiv5 = UIWindowMap.CellSize / 5
                     
      local CellWidth = math_floor(UIWindowMap.ViewPort.Width / (UIWindowMapUnitSize*UIWindowMap.CameraScale))
      local CellHeight = math_floor(UIWindowMap.ViewPort.Height / (UIWindowMapUnitSize*UIWindowMap.CameraScale))   
      local CellLeft = math_floor(UIWindowMap.CameraPositionX - (CellWidth / 2))
      local CellTop = math_floor(UIWindowMap.CameraPositionY - (CellHeight / 2))
      local CellRight = CellLeft + CellWidth
      local CellBottom = CellTop + CellHeight         
      
      self.SetView(CellLeft, CellTop, CellLeft+CellWidth, CellTop+CellHeight)                                                
   end            
                    
   -----------------------------------------------------------------------------
   function self.SelectedRegionAdd(ARegion)
   
   end  
   -----------------------------------------------------------------------------
   function self.SelectedRegionRemove(ARegion)
   
   end   
   -----------------------------------------------------------------------------
   function self.SelectedRegionRemoveAll()
   
   end   
   -----------------------------------------------------------------------------
   function self.SelectedRoomAdd(ARoom)
   
   end   
   -----------------------------------------------------------------------------
   function self.SelectedRoomRemove(ARoom)
   
   end   
   -----------------------------------------------------------------------------
   function self.SelectedRoomRemoveAll()
   
   end   
   -----------------------------------------------------------------------------
   function self.SelectedPlaceAdd(APlace)
   
   end   
   -----------------------------------------------------------------------------
   function self.SelectedPlaceRemove(APlace)
   
   end   
   -----------------------------------------------------------------------------
   function self.SelectedPlaceRemoveAll()
   
   end   
   -----------------------------------------------------------------------------
   function self.SelectedStreetAdd(AStreet)
   
   end   
   -----------------------------------------------------------------------------
   function self.SelectedStreetRemove(AStreet)
   
   end   
   -----------------------------------------------------------------------------
   function self.SelectedStreetRemoveAll()
   
   end   
   -----------------------------------------------------------------------------
   function self.SelectedRemoveAll()
      self.SelectedRegionRemoveAll()
      self.SelectedRoomRemoveAll()
      self.SelectedPlaceRemoveAll()
      self.SelectedStreetRemoveAll()
   end
   
   ---------------------------------------------------------------------------------------------------------------------------------------------------------------
   --//Region                                                                                                                                               Region
   ---------------------------------------------------------------------------------------------------------------------------------------------------------------
   
   -----------------------------------------------------------------------------
   function self.RegionCreate(ARegionName, ARegionParent, ARegionType, ARegionStride, AScale, AOffsetX, AOffsetY, AOffsetZ)
       
      local ARegion = {}                 
      UIMapRegionReset(ARegion)      
     
      ARegion.RegionName = ARegionName
      ARegion.RegionStride = ARegionStride
      ARegion.RegionType = ARegionType
      ARegion.RegionParentScale = AScale        
      ARegion.RegionParentPositionX = AOffsetX   
      ARegion.RegionParentPositionY = AOffsetY
      ARegion.RegionParentPositionZ = AOffsetZ        
      if ARegionParent then
         ARegion.RegionParentID = ARegionParent.RegionID
      end     
       
      Note("RegionCreate RegionWrite")
      UIMapDBRegionWrite(ARegion) --will create a new DB regord                                                         
      --Additions not in DB
      if ARegion.RegionID > 0 then     
         Note("RegionCreate GOT REGION ID")                            
         self.Regions[ARegion.RegionID] = ARegion --Add to the main buffer
      end
      ARegion.RegionParent = ARegionParent
      if ARegion.RegionParent then --add this region as a child of the parent
         table.insert(ARegion.RegionParent.RegionChildren, ARegion)                                   
      end                              
                  
      if UI_DebugMapRegions then
         UILog("UIMapBuffer.RegionCreate", "New RegionID=" .. ARegion.RegionID,0)
      end
      
      return ARegion 
   end
    
   -----------------------------------------------------------------------------         
   function self.RegionGet(RegionID) 
      local ARegion = nil                 
      if RegionID <= 0 then return nil end --not a valid ID                       
      
      ARegion = self.Regions[RegionID] --Query buffer to see if we already have this region
                                          
      if not ARegion then --if not query the database and try to load this region         
         ARegion = UIMapDBRegionIDRead(RegionID)
                            
         if ARegion then
                                                                                                                           
            self.Regions[RegionID] = ARegion
                        
            --Prebuffer sectors
            self.RegionGetSectors(ARegion)
            
            --Prebuffer Rooms
            self.RegionGetRooms(ARegion)
                                                
            --Prebugger streets
            self.RegionGetStreets(ARegion)            
            
            self.RegionGetChildren(ARegion)
            
            --if ARegion.RegionParentID > 0 then --get parent region if any
            --   ARegion.RegionParent = self.RegionGet(ARegion.RegionParentID)
            --   if ARegion.RegionParent then --add this region as a child of the parent
            --      table.insert(ARegion.RegionParent.RegionChildren, ARegion)                                   
            --   end
            --end                                                                                                                                                                                                                           
         end                 
      end      
      return ARegion --return region (or not)               
   end
   
   -----------------------------------------------------------------------------
   function self.RegionGetChildren(ARegion)         
      local Result = 0
                 
      local AChildrenIDs = {}
      local AChildRegion = {}            
      local RowValues = {}
                              
      if ARegion.RegionID == 0 then return false end --Region not in DB
                                                                                          
      UIMapDBReadArrayValue(AChildrenIDs, "Regions", "RegionID", "RegionParentID", ARegion.RegionID)
            
      for _,ARegionID in pairs(AChildrenIDs) do                                                                   
         AChildRegion = self.RegionGet(ARegionID)                                                                      
         if AChildRegion then                                                                
            AChildRegion.RegionParent = ARegion
            ARegion.RegionChildren[ARegionID] = AChildRegion                       
            Result = Result + 1
         end                       
      end                                                        
      return Result 
   end
   
   -----------------------------------------------------------------------------
   function self.RegionGetSectors(ARegion)         
      local Result = 0
      local ASectorIDs = {}
      local ASector = {}            
      local RowValues = {}                        
      if ARegion.RegionID == 0 then return false end --Region not in DB so no streets               
                                                                         
      UIMapDBReadArrayValue(ASectorIDs, "Sectors", "SectorID", "RegionID", ARegion.RegionID)      
      for _,ASectorID in pairs(ASectorIDs) do                                                        
         ASector = self.SectorGet(ASectorID)
                                                               
         if ASector then                                                           
            Result = Result + 1
         end                       
      end                                                        
      return Result 
   end
   
   -----------------------------------------------------------------------------
   function self.RegionGetRooms(ARegion)         
      local Result = 0
      local ARoomIDs = {}
      local ARoom = nil      
                             
      if ARegion.RegionID == 0 then return false end --Sector not in DB so no rooms         
                        
      UIMapDBReadArrayValue(ARoomIDs, "Rooms", "RoomID", "RegionID", ARegion.RegionID)
      
      --for ARoomID = 1,50 do                                                                   
      for _,ARoomID in pairs(ARoomIDs) do                                      
         ARoom = self.RoomGet(ARoomID)         
         if ARoom then                               
            Result = Result + 1
         end                       
      end
                                                            
      return Result   
   end
   
   
   -----------------------------------------------------------------------------
   function self.RegionGetStreets(ARegion)         
      local Result = 0
      local AStreetIDs = {}
      local AStreet = {}            
      local RowValues = {}                        
      if ARegion.RegionID == 0 then return false end --Region not in DB so no streets               
      ARegion.RegionStreets = {} --clear any previous streets                                                                
      UIMapDBReadArrayValue(AStreetIDs, "Streets", "StreetID", "RegionID", ARegion.RegionID)      
      for _,AStreetID in pairs(AStreetIDs) do                                                        
         AStreet = self.StreetGet(AStreetID)                                                      
         if AStreet then                                                  
            table_insert(ARegion.RegionStreets, AStreet)
            Result = Result + 1
         end                       
      end                                                        
      return Result 
   end
   
   -----------------------------------------------------------------------------   
   function self.RegionGetWorldPos(ARegion, APosX, APosY, APosZ)

      --return coords within this region (ie region room position) in world coordinates  
      APosX = ARegion.RegionParentPositionX + (APosX * ARegion.RegionParentScale)
      APosY = ARegion.RegionParentPositionY + (APosY * ARegion.RegionParentScale)
      APosZ = ARegion.RegionParentPositionZ + (APosZ * ARegion.RegionParentScale)   
         
      if ARegion.RegionParent then      
         APosX, APosY, APosZ = self.RegionGetWorldPos(ARegion.RegionParent,APosX,APosY,APosZ)
      else
         
      end      
                                          
      return APosX, APosY, APosZ   
   end
   
   -----------------------------------------------------------------------------   
   function self.RegionGetWorldScale(ARegion, AScale)
      --return scale within this region as world scale
      if ARegion.RegionParent then
         AScale = AScale / (ARegion.RegionParentScale / self.RegionGetWorldScale(ARegion.RegionParent, AScale))
      else                   
         AScale = AScale /ARegion.RegionParentScale
      end
      return AScale   
   end
      
   
   ---------------------------------------------------------------------------------------------------------------------------------------------------------------
   --//Sector                                                                                                                                               Sector
   ---------------------------------------------------------------------------------------------------------------------------------------------------------------
    
   -----------------------------------------------------------------------------    
   function self.SectorCreate(ARegion, APositionX, APositionY, APositionZ)      
      local ASector = {}           
      UIMapSectorReset(ASector)            
      ASector.RegionID = ARegion.RegionID
      ASector.SectorPositionX = APositionX
      ASector.SectorPositionY = APositionY      
      ASector.CellLeft = APositionX * UIMapSectorSize
      ASector.CellTop = APositionY * UIMapSectorSize
      ASector.CellRight = ASector.CellLeft + UIMapSectorSize-1
      ASector.CellBottom = ASector.CellTop + UIMapSectorSize-1                     
      UIMapDBSectorWrite(ASector) --will create a new DB record for a reset sector             
      ASector.Region = ARegion
      ARegion.RegionSectorsXYZ[APositionX..":"..APositionY..":"..APositionZ] = ASector --add the sector to the region XY buffer 
           
      if ASector.SectorID > 0 then         
         self.Sectors[ASector.SectorID] = ASector --Add to the main buffer
      end                                         
      if (APositionX < ARegion.RegionSectorLeft) or (APositionY < ARegion.RegionSectorTop) or (APositionX > ARegion.RegionSectorRight) or (APositionY > ARegion.RegionSectorBottom) or (APositionZ < ARegion.RegionSectorDown) or (APositionZ > ARegion.RegionSectorUp) then      
         if APositionX < ARegion.RegionSectorLeft then ARegion.RegionSectorLeft = APositionX end
         if APositionY < ARegion.RegionSectorTop then ARegion.RegionSectorTop = APositionY end       
         if APositionX > ARegion.RegionSectorRight then ARegion.RegionSectorRight = APositionX end
         if APositionY > ARegion.RegionSectorBottom then ARegion.RegionSectorBottom = APositionY end    
         if APositionZ < ARegion.RegionSectorDown then ARegion.RegionSectorDown = APositionZ end
         if APositionZ > ARegion.RegionSectorUp then ARegion.RegionSectorUp = APositionZ end     
         if UI_DebugMapSectors then
            UILog("UIMapBuffer.SectorCreate", "Expanded Region '"..ARegion.RegionName.."' Sector Bounds ["..ARegion.RegionSectorLeft..","..ARegion.RegionSectorTop..","..ARegion.RegionSectorRight..","..ARegion.RegionSectorBottom.."]",0)
         end                  
         UIMapDBRegionWrite(ARegion)         
      end                  
      if UI_DebugMapSectors then
         UILog("UIMapBuffer.SectorCreate", "New SectorID=" .. ASector.SectorID,0)
      end                      
      return ASector  
   end
   
   -----------------------------------------------------------------------------         
   function self.SectorGet(ASectorID)   
      local ASector = nil
      local ARegion = nil            
      if ASectorID <= 0 then return nil end --not a valid ID            
      ASector = self.Sectors[ASectorID] --Query buffer to see if we already have this room                  
      if ASector == nil then --if not query the database and try to load this room 
         
         ASector = UIMapDBSectorIDRead(ASectorID)                   
         
         if ASector ~= nil then                     
            self.Sectors[ASector.SectorID] = ASector --Add to the main buffer
            ARegion = self.RegionGet(ASector.RegionID)                                    
            ARegion.RegionSectorsXYZ[ASector.SectorPositionX..":"..ASector.SectorPositionY..":"..ASector.SectorPositionZ] = ASector
            ASector.Region = ARegion                        
            
            --self.SectorGetRooms(ASector) --Load Room records                                                                                                                    
         end
                          
      end      
      if UI_DebugMapSectors then
         if ASector then
            UILog("UIMapBuffer.SectorGet","Got SectorID = "..ASector.SectorID,0)
         else
            UILog("UIMapBuffer.SectorGet","Failed to get SectorID = "..ASectorID,1)
         end
      end     
      return ASector  
   end
   
   -----------------------------------------------------------------------------         
   function self.SectorGetXYZ(ARegion, APositionX, APositionY, APositionZ)
      if ARegion == nil then return nil end
      if not APositionZ then APositionZ = 0 end      
      local ASector = nil                                         
      ASector = ARegion.RegionSectorsXYZ[APositionX..":"..APositionY..":"..APositionZ] --Query buffer to see if we already have this sector                        
      if not ASector then                              
         ASector = UIMapDBSectorRead(ARegion.RegionID, APositionX, APositionY, APositionZ)
         if ASector ~= nil then                                                            
            self.Sectors[ASector.SectorID] = ASector                        
            ARegion.RegionSectorsXYZ[APositionX..":"..APositionY..":"..APositionZ] = ASector
            ASector.Region = ARegion
            
            --self.SectorGetRooms(ASector) --add it into the buffer                                                                                                         
         end                                            
      end                             
      if ASector then                     
         if APositionX < ARegion.RegionSectorLeft then ARegion.RegionSectorLeft = APositionX end
         if APositionY < ARegion.RegionSectorTop then ARegion.RegionSectorTop = APositionY end       
         if APositionX > ARegion.RegionSectorRight then ARegion.RegionSectorRight = APositionX end
         if APositionY > ARegion.RegionSectorBottom then ARegion.RegionSectorBottom = APositionY end         
         if APositionZ < ARegion.RegionSectorDown then ARegion.RegionSectorDown = APositionZ end
         if APositionZ > ARegion.RegionSectorUp then ARegion.RegionSectorUp = APositionZ end
         
         if UI_DebugMapSectors then              
            UILog("UIMapBuffer.SectorGetXYZ", "Expanded Region '" .. ARegion.RegionName .."' Sector Bounds [" ..ARegion.RegionSectorLeft.."," ..ARegion.RegionSectorTop.."," ..ARegion.RegionSectorRight.."," ..ARegion.RegionSectorBottom.."]", 0)
         end   
      end                       
      if UI_DebugMapSectors then
         if ASector then UILog("UIMapBuffer.SectorGetXYZ","Got SectorID = "..ASector.SectorID,0)
         else UILog("UIMapBuffer.SectorGetXYZ","Failed to get SectorXYZ ["..APositionX..","..APositionY..","..APositionZ.."]",1) end
      end                 
      return ASector
   end
   
   -----------------------------------------------------------------------------
   function self.SectorGetRooms(ASector)      
      local Result = 0
      local ARoomIDs = {}
      local ARoom = nil      
                             
      if ASector.SectorID == 0 then return false end --Sector not in DB so no rooms         
                  
      
      UIMapDBReadArrayValue(ARoomIDs, "Rooms", "RoomID", "SectorID", ASector.SectorID)
      Note("SectorGetRooms")                                                                   
      for _,ARoomID in pairs(ARoomIDs) do                                      
         ARoom = self.RoomGet(ARoomID)         
         if ARoom then                               
            Result = Result + 1
         end                       
      end
                                                            
      return Result   
   end   
   
   ---------------------------------------------------------------------------------------------------------------------------------------------------------------
   --//Room                                                                                                                                                   Room
   ---------------------------------------------------------------------------------------------------------------------------------------------------------------
  
   function self.RoomCreate(ARegion, ASector, APositionX, APositionY, APositionZ)
      if not APositionZ then APositionZ = 0 end         
      local ARoom = {}     
      UIMapRoomReset(ARoom)        
      ARoom.RegionID = ARegion.RegionID            
      ARoom.SectorID = ASector.SectorID            
      ARoom.RoomPositionX = APositionX
      ARoom.RoomPositionY = APositionY
      ARoom.RoomPositionZ = APositionZ                               
      UIMapDBRoomWrite(ARoom) --will create a new DB record for a reset room                  
      ARegion.RegionRoomsXYZ[APositionX..":"..APositionY..":"..APositionZ] = ARoom      
      ASector.SectorRoomsXYZ[APositionX..":"..APositionY..":"..APositionZ] = ARoom
      ARoom.Region = ARegion
      ARoom.Sector = ASector
   
      if ARoom.RoomID > 0 then                                 
         self.Rooms[ARoom.RoomID] = ARoom --Add to the main buffer
      end       
      if UI_DebugMapRooms then
         UILog("UIMapBuffer.RoomCreate", "New RoomID=" .. ARoom.RoomID,0)
      end                                                  
      return ARoom    
   end
   
   -----------------------------------------------------------------------------
   function self.RoomGet(RoomID)
      local ARoom = nil            
      if RoomID <= 0 then return nil end                  
      ARoom = self.Rooms[RoomID] --Query buffer to see if we already have this room                        
      if not ARoom then --if not query the database and try to load this room          
         ARoom = UIMapDBRoomIDRead(RoomID)                            
         if ARoom ~= nil then
            self.Rooms[ARoom.RoomID] = ARoom --Add to the main buffer          
            self.RoomGetStreets(ARoom)            
                                                                                                 
            local ARegion = self.RegionGet(ARoom.RegionID)                           
            ARegion.RegionRoomsXYZ[ARoom.RoomPositionX..":"..ARoom.RoomPositionY..":"..ARoom.RoomPositionZ] = ARoom                        
            local ASector = self.SectorGet(ARoom.SectorID)  --self.Sectors[ARoom.SectorID]
            ASector.SectorRoomsXYZ[ARoom.RoomPositionX..":"..ARoom.RoomPositionY..":"..ARoom.RoomPositionZ] = ARoom
            ARoom.Region = ARegion
            ARoom.Sector = ASector
                                                                                                                                                
         end                          
      end      
      if UI_DebugMapRooms then
         if ARoom then UILog("UIMapBuffer.RoomGet","Got RoomID = "..ARoom.RoomID,0)
         else UILog("UIMapBuffer.RoomGet","Failed to get RoomID = "..RoomID,1) end
      end      
      return ARoom  
   end
   
   -----------------------------------------------------------------------------
    --get region room at exact (integer) coordinates
   function self.RoomGetXYZ(ARegion, APositionX, APositionY, APositionZ)    
      local ARoom = nil
                  
      if ARegion == nil then return nil end                        
      ARoom = ARegion.RegionRoomsXYZ[APositionX..":"..APositionY..":"..APositionZ] --Query buffer to see if we already have this room      
      if not ARoom then --if not query the database and try to load this room                                        
         ARoom = UIMapDBRoomRead(ARegion.RegionID, APositionX, APositionY, APositionZ)          
         if ARoom ~= nil then
            self.Rooms[ARoom.RoomID] = ARoom --Add to the main buffer          
            self.RoomGetStreets(ARoom)

                                                                                                             
            ARegion.RegionRoomsXYZ[APositionX..":"..APositionY..":"..APositionZ] = ARoom                             
            local ASector = self.SectorGet(ARoom.SectorID)  --self.Sectors[ARoom.SectorID]
            ASector.SectorRoomsXYZ[APositionX..":"..APositionY..":"..APositionZ] = ARoom
            ARoom.Region = ARegion
            ARoom.Sector = ASector                                                                                         
         end                      
      end          
      if UI_DebugMapRooms then
         if ASector then UILog("UIMapBuffer.RoomGetXYZ","Got RoomID = "..ARoom.RoomID,0)
         else UILog("UIMapBuffer.RoomGetXYZ","Failed to get RoomXYZ ["..APositionX..","..APositionY..","..APositionZ.."]",1) end
      end     
      return ARoom --return room (or not)                
   end
     
   function self.RoomGetXYZNearestRecurse(ARegion, AParentScale, AParentPositionX, AParentPositionY, AParentPositionZ, APositionX, APositionY, APositionZ)
      
      if not APositionZ then APositionZ = 0 end
      local ARoom = nil
      local ARoomDistance = 999999999      
      local BRoom = nil
      local BRoomDistance = 999999999      
      local ANewDistance = 0                             
      
                             
     --[[      
      TODO : This need optimizing with a maximum radius which then itterates through only sectors
      that that fall within that radius      
      --]]
      
      AParentPositionX = (AParentPositionX) + (ARegion.RegionParentPositionX*AParentScale)
      AParentPositionY = (AParentPositionY) + (ARegion.RegionParentPositionY*AParentScale)                               
      AParentPositionZ = (AParentPositionZ) + (ARegion.RegionParentPositionZ*AParentScale)
      AParentScale = AParentScale * ARegion.RegionParentScale
       
      for I,Room in pairs(ARegion.RegionRoomsXYZ) do                 
         ANewDistance = Vec2LengthSquared(         
         APositionX - (AParentPositionX+(Room.RoomPositionX*AParentScale)),          
         APositionY - (AParentPositionY+(Room.RoomPositionY*AParentScale)))
                  
         if (ANewDistance) < ARoomDistance then
            ARoom = Room
            ARoomDistance = ANewDistance
         end                      
      end
                  
      for _,CRegion in pairs(ARegion.RegionChildren) do
         BRoom, BRoomDistance = self.RoomGetXYZNearestRecurse(CRegion, AParentScale, AParentPositionX, AParentPositionY, AParentPositionZ, APositionX, APositionY, APositionZ)         
         if BRoom then                     
            if BRoomDistance < ARoomDistance then
               ARoom = BRoom
               ARoomDistance = BRoomDistance
            end                                      
         end                     
      end         
       
      return ARoom, ARoomDistance              
   end
     
   -----------------------------------------------------------------------------
   -- get region room nearest to coordinates
   function self.RoomGetXYZNearest(ARegion, APositionX, APositionY, APositionZ)      
      if ARegion == nil then return nil end
      
      if not APositionZ then APositionZ = 0 end
            
      local ARoom = nil
      local ARoomDistance = 0      
      ARoom, ARoomDistance = self.RoomGetXYZNearestRecurse(self.RootRegion, 1, 0,0,0, APositionX, APositionY, APositionZ)
      
      return ARoom             
   end
   
   -----------------------------------------------------------------------------
   function self.RoomGetStreets(ARoom)            
      local Result = 0
      local ARoomStreetIDs = {}
      local AStreet = {}      
      local RowValues = {}           
      if ARoom.RoomID == 0 then return false end --Room not in DB so there can't be any street rooms               
      ARoom.RoomStreets = {} --clear any previous streets                                                              
      UIMapDBReadArrayValue(ARoomStreetIDs, "RoomStreets", "StreetID", "RoomID", ARoom.RoomID)      
      for _,ARoomStreetID in pairs(ARoomStreetIDs) do                                           
         AStreet = self.StreetGet(ARoomStreetID)                 
         if AStreet then 
            table_insert(ARoom.RoomStreets, AStreet)            
            AStreet.StreetRooms[ARoom.RoomID] = ARoom            
            Result = Result + 1
         end                       
      end
      return Result    
   end
   

   
   ---------------------------------------------------------------------------------------------------------------------------------------------------------------
   --//Portal                                                                                                                                               Portal
   ---------------------------------------------------------------------------------------------------------------------------------------------------------------
   
   -----------------------------------------------------------------------------
   function self.PortalCreate(ARegion, APortalName)   
      local APortal = {}     
      UIMapPortalReset(APortal)                    
      APortal.RegionID = ARegion.RegionID            
      APortal.PortalName = string_sub(APortalName,1)                   
      UIMapDBPortalWrite(APortal) --will create a new DB record for a reset Portal                              
      ARegion.RegionPortals[APortalName] = APortal --add the Portal to region portal cache                        
      self.Portals[APortal.PortalID] = APortal --add the Portal to the main portal cache                            
      return APortal   
   end

   ---------------------------------------------------------------------------------------------------------------------------------------------------------------
   --//Place                                                                                                                                                 Place
   ---------------------------------------------------------------------------------------------------------------------------------------------------------------
   
   -----------------------------------------------------------------------------
   function self.PlaceCreate(ARegion, APlaceName)  
      local APlace = {}     
      UIMapPlaceReset(APlace)                    
      APlace.RegionID = ARegion.RegionID            
      APlace.PlaceName = string_sub(APlaceName,1)                   
      UIMapDBPlaceWrite(APlace) --will create a new DB record for a reset place                        
      ARegion.RegionPlaces[APlaceName] = APlace                        
      self.Places[APlace.PlaceID] = APlace --Add to the main cache 
                           
      return APlace   
   end
   
   -----------------------------------------------------------------------------
   function self.PlaceGet(PlaceID)
      if PlaceID <= 0 then return nil end
      local APlace = nil                     
      APlace = self.Places[PlaceID] --Query buffer to see if we already have this place                        
      if APlace == nil then         
         APlace = UIMapDBPlaceIDRead(PlaceID)                           
         if APlace ~= nil then                  
            self.Places[PlaceID] = APlace --Add to the main cache
         end                 
      end 
   end

   ---------------------------------------------------------------------------------------------------------------------------------------------------------------
   --//Street                                                                                                                                               Street
   ---------------------------------------------------------------------------------------------------------------------------------------------------------------
       
   -----------------------------------------------------------------------------
   function self.StreetCreate(ARegion, AStreetName)   
      local AStreet = {}     
      UIMapStreetReset(AStreet)                    
      AStreet.RegionID = ARegion.RegionID            
      AStreet.StreetName = string_sub(AStreetName,1)                 
      UIMapDBStreetWrite(AStreet) --will create a new DB record for a reset Street                              
      ARegion.RegionStreets[AStreet.StreetName] = AStreet --Add to the main cache                        
      self.Streets[AStreet.StreetID] = AStreet --Add to the main cache                           
      return AStreet -- return the new Street or not   
   end
   
   -----------------------------------------------------------------------------
   function self.StreetGet(StreetID)
      if StreetID <= 0 then return nil end
      local AStreet = nil      
      AStreet = self.Streets[StreetID] --Query buffer to see if we already have this Street                        
      if AStreet == nil then --if not query the database and try to load this street         
         AStreet = UIMapDBStreetIDRead(StreetID)                          
         if AStreet ~= nil then                              
            --self.StreetGetRooms(AStreet) --this would cause an infinite loop                                                                                                                           
            self.Streets[StreetID] = AStreet --Add to the main cache
         end                 
      end      
      return AStreet       
   end
   
   -----------------------------------------------------------------------------
   function self.StreetAddRoom(AStreet, ARoom)      
      if not UIEnableDBWrite then return end   
      local DBResult = 0
      local AlreadyWritten = false      
      for I, Street in pairs(ARoom.RoomStreets) do
         if Street == AStreet then AlreadyWritten = true end
      end                                                                      
      if not AlreadyWritten then
         table_insert(ARoom.RoomStreets, AStreet)
         AStreet.StreetRooms[ARoom.RoomID] = ARoom      
         --not yet in database
         DBResult = DatabaseExec(UIDatabaseMap, string_format("INSERT INTO RoomStreets (RoomID, StreetID, RegionID) VALUES (%i, %i, %i)",
            ARoom.RoomID, AStreet.StreetID, AStreet.RegionID))         
         if UIDatabaseResultCheck(DBResult) then                          
            --ID = DatabaseLastInsertRowid(UIDatabaseMap)                                   
         else 
            if UI_DebugMapStreet then
               UILog("UIMapBuffer.StreetAddRoom", "Street DB Insert Failed", 0)
            end                                                           
         end                             
      end          
   end
   
   -----------------------------------------------------------------------------
   function self.StreetGetRooms(AStreet)           
      local Result = 0
      local AStreetRoomIDs = {}
      local ARoom = {}      
      local RowValues = {}            
      if AStreet.StreetID == 0 then return false end --Street not in DB so no Street Rooms               
      AStreet.StreetRooms = {} --clear any previous rooms
      
      UIMapDBReadArrayValue(AStreetRoomIDs, "RoomStreets", "RoomID", "StreetID", AStreet.StreetID)
                                                                 
      for _,AStreetRoomID in pairs(AStreetRoomIDs) do                                    
         ARoom = self.RoomGet(AStreetRoomID)         
         if ARoom then                                                  
            table_insert(AStreet.StreetRooms, ARoom) --insert this room into the street
            Result = Result + 1
         end                       
      end                                       
      return Result 
   end

   ---------------------------------------------------------------------------------------------------------------------------------------------------------------
   --//Map Buffer Public Functions                                                                                                     Map Buffer Public Functions
   ---------------------------------------------------------------------------------------------------------------------------------------------------------------    
    
   -----------------------------------------------------------------------------
   function self.MoveDirectionAttempt(ADirection)         
      local DirectionAttempt = {}
      DirectionAttempt.Direction = string_sub(UIMapDirectionMin[ADirection],1)     
      DirectionAttempt.DirectionOpposite = string_sub(UIMapDirectionOpposite[DirectionAttempt.Direction],1)
      local AVector = UIMapDirectionToVector[DirectionAttempt.Direction]  
      DirectionAttempt.VectorX = AVector.x * self.CurrentRegion.RegionStride  
      DirectionAttempt.VectorY = AVector.y * self.CurrentRegion.RegionStride
      DirectionAttempt.VectorZ = AVector.z * self.CurrentRegion.RegionStride                                
      table.insert(FDirectionAttemptQueue,DirectionAttempt)
      --if UI_DebugMapBuffer then
         UILog("UIMapBuffer.MoveDirectionAttempt",  "'" .. DirectionAttempt.Direction .. "' [" .. DirectionAttempt.VectorX .. "," .. DirectionAttempt.VectorY .. "," .. DirectionAttempt.VectorZ .."]", 0)
      --end                                          
   end
   
   -----------------------------------------------------------------------------
   function self.MoveDirectionAttemptFail()
      if #FDirectionAttemptQueue > 0 then
      
         local DirectionAttempt = FDirectionAttemptQueue[1]
         
         table.remove(FDirectionAttemptQueue,1)
      end 
   end
   
   -----------------------------------------------------------------------------
   function self.MoveDirectionAttemptConfirm()
      
    
    
      if #FDirectionAttemptQueue > 0 then      
         --Get direction attempt from queue      
         local DirectionAttempt = FDirectionAttemptQueue[1]         
         table.remove(FDirectionAttemptQueue,1)
         
         UILog("UIMapBuffer.MoveDirectionAttemptConfirm",  "'" .. DirectionAttempt.Direction .. "' [" .. DirectionAttempt.VectorX .. "," .. DirectionAttempt.VectorY .. "," .. DirectionAttempt.VectorZ .."]", 0)
         
         self.PreviousDirection = DirectionAttempt.Direction  
         self.PreviousDirectionVectorX = DirectionAttempt.VectorX / self.CurrentRegion.RegionStride 
         self.PreviousDirectionVectorY = DirectionAttempt.VectorY / self.CurrentRegion.RegionStride 
         self.PreviousDirectionVectorZ = DirectionAttempt.VectorZ / self.CurrentRegion.RegionStride 
         
         local NewRoomID = 0
         local NewRoom = nil
         local NewSector = nil 
         local ASectorX = 0
         local ASectorY = 0                        
         local ASectorZ = 0        
         
         
         local QueryResult = 0                        
         
         if self.TrackingMode then
            --Location Unknown, Tracking Mode                
            self.TrackingModeAddCurrentRoom()                          
            
            QueryResult = self.TrackingModeQuery()
            
            
            --if UI_DebugMapBuffer then
               UILog("UIMapBuffer.MoveDirectionAttemptConfirm","TRACKING Mode Query - "..QueryResult.." Matches")
            --end
                
            if (QueryResult == 1) then
               
               --Location Known, normal lookup
               NewRoom = self.CurrentRoom
               NewRoomID = self.CurrentRoom.RoomID
            else
               
            end
            
            return
         end
      
         if self.CurrentRoom then                                             
            --Get potential new roomID
            NewRoomID = self.CurrentRoom[UIMapDirectionToExit[DirectionAttempt.Direction]]
            --Try to get potential new room                  
            NewRoom = self.RoomGet(NewRoomID)
         end
                
         -----------------------------------------------------------------------------
         --Switch to New Region
         -----------------------------------------------------------------------------                                                                                     
         --if the room exists, check if new room is in another region
         if NewRoom then
            if UI_DebugMapBuffer then
               UILog("UIMapBuffer.MoveDirectionAttemptConfirm","NewRoom Exists '"..NewRoom.RoomName.."'")
            end
            if (NewRoom.RegionID ~= self.CurrentRoom.RegionID) then               
               --If so, set new current region
               self.PreviousRegion = self.CurrentRegion
               self.CurrentRegion = self.RegionGet(NewRoom.RegionID)
               if UI_DebugMapBuffer then
                  UILog("UIMapBuffer.MoveDirectionAttemptConfirm","Switched to New Region '"..self.CurrentRegion.RegionName.."'")
               end               
               --set player position inside region
               self.PlayerPositionX = NewRoom.RoomPositionX
               self.PlayerPositionY = NewRoom.RoomPositionY
               self.PlayerPositionZ = NewRoom.RoomPositionZ
               ASectorX = math_floor((self.PlayerPositionX) / UIMapSectorSize)
               ASectorY = math_floor((self.PlayerPositionY) / UIMapSectorSize)                        
               ASectorZ = math_floor((self.PlayerPositionZ) / UIMapSectorSize)            
               self.CurrentSector = self.SectorGetXYZ(self.CurrentRegion, ASectorX, ASectorY, ASectorZ)               
               self.PreviousRoom = self.CurrentRoom
               self.CurrentRoom = NewRoom    
               
               
              local FWorldX, FWorldY, FWorldZ = self.RegionGetWorldPos(self.CurrentRegion,NewRoom.RoomPositionX,NewRoom.RoomPositionY,NewRoom.RoomPositionZ)    
    
               --Move the camera to track the players position  
               UIWindowMap.CameraPositionX = FWorldX
               UIWindowMap.CameraPositionY = FWorldY
                                 
               local CellWidth = math_floor(UIWindowMap.ViewPort.Width / (UIWindowMapUnitSize*UIWindowMap.CameraScale))
               local CellHeight = math_floor(UIWindowMap.ViewPort.Height / (UIWindowMapUnitSize*UIWindowMap.CameraScale))   
               local CellLeft = math_floor(UIWindowMap.CameraPositionX - (CellWidth / 2))
               local CellTop = math_floor(UIWindowMap.CameraPositionY - (CellHeight / 2))
               local CellRight = CellLeft + CellWidth
               local CellBottom = CellTop + CellHeight         
               
               self.SetView(CellLeft, CellTop, CellLeft+CellWidth, CellTop+CellHeight)            
                                                                                                 
               return
            end
         end 
         

         -----------------------------------------------------------------------------
         --Move within Current Region
         -----------------------------------------------------------------------------                                   
         --get potential new sector         
         ASectorX = math_floor((self.PlayerPositionX + DirectionAttempt.VectorX) / UIMapSectorSize)
         ASectorY = math_floor((self.PlayerPositionY + DirectionAttempt.VectorY) / UIMapSectorSize)                        
         ASectorZ = math_floor((self.PlayerPositionZ + DirectionAttempt.VectorZ) / UIMapSectorSize)          
         NewSector = self.SectorGetXYZ(self.CurrentRegion, ASectorX, ASectorY, ASectorZ)          
         --if sector doesn't exist, create it      
         if not NewSector then
            NewSector = self.SectorCreate(self.CurrentRegion, ASectorX, ASectorY, ASectorZ)
         end     
         
         if UI_DebugMapBuffer then
            if NewSector == nil then         
               UILog("UIMapBuffer.MoveDirectionAttemptConfirm","NewSector == nil (should not happen)",1)
               return            
            end
         end
                       
         if (NewRoomID == 0) then --there is an exit but the room hasn't been created / linked                                
            --check position to see if it already exists            
            NewRoom = self.RoomGetXYZ(self.CurrentRegion,self.PlayerPositionX + DirectionAttempt.VectorX,self.PlayerPositionY + DirectionAttempt.VectorY, self.PlayerPositionZ + DirectionAttempt.VectorZ)                                               
            if NewRoom == nil then --if not, create the new room
               if UIEnableMapMergeRoom then                                                                            
               NewRoom = self.RoomCreate(self.CurrentRegion, NewSector, self.PlayerPositionX + DirectionAttempt.VectorX, self.PlayerPositionY + DirectionAttempt.VectorY, self.PlayerPositionZ + DirectionAttempt.VectorZ)
               end                                            
            end                                                                                 
         else
            --this room exists            
            NewRoom = self.RoomGet(NewRoomID)                  
            if not NewRoom then --this shouldn't be happening
               if UI_DebugMapBuffer then
                  if NewSector == nil then         
                     UILog("UIMapBuffer.MoveDirectionAttemptConfirm","RoomGet == nil (should not happen)",1)
                     return            
                  end
               end                              
            end         
         end 
                                               
                                                                                                                                                       
         if (NewRoom ~= nil) and (NewRoom ~= self.CurrentRoom) and (self.CurrentRoom) then                         
            --link current/previous rooms and flush data
            
            --Flush old Room and Sector to get DB ID
            UIMapDBSectorWrite(self.CurrentSector)         
            self.CurrentRoom.RegionID = self.CurrentRegion.RegionID
            self.CurrentRoom.SectorID = self.CurrentSector.SectorID                                           
            UIMapDBRoomWrite(self.CurrentRoom)            
            --Set Exit in NewRoom to CurrentRoom            
            NewRoom[UIMapDirectionToExitRoom[DirectionAttempt.DirectionOpposite]] = self.CurrentRoom
            NewRoom[UIMapDirectionToExit[DirectionAttempt.DirectionOpposite]] = tonumber(self.CurrentRoom.RoomID)                           
            --Flush new Room and Sector
            UIMapDBSectorWrite(NewSector)         
            --NewRoom.RegionID = NewRegion.RegionID
            NewRoom.SectorID = NewSector.SectorID                                           
            UIMapDBRoomWrite(NewRoom)                           
            --SetExit in CurrentRoom to ExitRoom             
            self.CurrentRoom[UIMapDirectionToExitRoom[DirectionAttempt.Direction]] = NewRoom                              
            self.CurrentRoom[UIMapDirectionToExit[DirectionAttempt.Direction]] = tonumber(NewRoom.RoomID)            
            --flush new exit            
            UIMapDBRoomWrite(self.CurrentRoom)
                                                                                 
                         
            --switch to new room                                                       
            self.PreviousRoom = self.CurrentRoom         
            self.PreviousSector = self.CurrentSector
            self.CurrentRoom = NewRoom
            self.CurrentSector = NewSector                                                       
         else --no rooms created / found
            --self.CurrentRoom = nil
            self.CurrentSector = NewSector
         end
         
         self.PlayerPositionX = self.PlayerPositionX + DirectionAttempt.VectorX        
         self.PlayerPositionY = self.PlayerPositionY + DirectionAttempt.VectorY
         self.PlayerPositionZ = self.PlayerPositionZ + DirectionAttempt.VectorZ     
                         
         
         local FWorldScale = self.RegionGetWorldScale(self.CurrentRegion, 1)                                                                                           
         --Move the camera to track the players position  
         UIWindowMap.CameraPositionX = UIWindowMap.CameraPositionX + (DirectionAttempt.VectorX / FWorldScale)
         UIWindowMap.CameraPositionY = UIWindowMap.CameraPositionY + (DirectionAttempt.VectorY / FWorldScale)
                           
         local CellWidth = math_floor(UIWindowMap.ViewPort.Width / (UIWindowMapUnitSize*UIWindowMap.CameraScale))
         local CellHeight = math_floor(UIWindowMap.ViewPort.Height / (UIWindowMapUnitSize*UIWindowMap.CameraScale))   
         local CellLeft = math_floor(UIWindowMap.CameraPositionX - (CellWidth / 2))
         local CellTop = math_floor(UIWindowMap.CameraPositionY - (CellHeight / 2))
         local CellRight = CellLeft + CellWidth
         local CellBottom = CellTop + CellHeight         
         
         self.SetView(CellLeft, CellTop, CellLeft+CellWidth, CellTop+CellHeight)                 
      end   
              
   end
   
   -----------------------------------------------------------------------------
   --calculate the capture data position using current position
   function self.CalculateCaptureLocation()                                        
      FCaptureCellLeft = (self.PlayerPositionX)-(UIMapCapturePlayerPositionX-1) 
      FCaptureCellTop = (self.PlayerPositionY)-(UIMapCapturePlayerPositionY-1)
      FCaptureCellRight = FCaptureCellLeft+(UIMapCaptureCellWidth-1)
      FCaptureCellBottom = FCaptureCellTop+(UIMapCaptureCellHeight-1)
               
      FCaptureSectorLeft = math_floor(FCaptureCellLeft / UIMapSectorSize)
      FCaptureSectorTop = math_floor(FCaptureCellTop / UIMapSectorSize)
      FCaptureSectorRight = math_floor(FCaptureCellRight / UIMapSectorSize)
      FCaptureSectorBottom = math_floor(FCaptureCellBottom / UIMapSectorSize)
           
      if UI_DebugMapCapture then
         UILog("UIMapBuffer.CalculateCaptureLocation", "CaptureCellWidthHeight = " .. UIMapCaptureCellWidth .. ":".. UIMapCaptureCellHeight, 0)
         UILog("UIMapBuffer.CalculateCaptureLocation", "CapturePlayerPosition = " .. UIMapCapturePlayerPositionX .. ":".. UIMapCapturePlayerPositionY, 0)
         UILog("UIMapBuffer.CalculateCaptureLocation", "CaptureCellLeftTop = " .. FCaptureCellLeft .. ":".. FCaptureCellTop, 0)
         UILog("UIMapBuffer.CalculateCaptureLocation", "CaptureCellRightBottom = " .. FCaptureCellRight .. ":".. FCaptureCellBottom, 0)      
      end                                                                                    
   end
   
   -----------------------------------------------------------------------------
   function self.UpdateFromCapture()
      if self.CurrentRoom then
          
         self.CurrentRoom.RoomName = UIMapCaptureRoomName
         self.CurrentRoom.RoomDescription = UIMapCaptureRoomDescription    
                            
         local AExitField = ""
         local AExitTypeField = ""
         local AExitRoom = ""
         local AOppExit = ""
         local AOppExitField = ""
         local AOppExitRoom = ""                   
         local AStride = self.CurrentRegion.RegionStride
         local AVector = nil
         local ARoom = nil
                           
         --update exits. -1 no exit, 0 exit but not yet linked, >0 Target RoomID                         
         for I,exit in ipairs(UIMapCaptureDataRoomExits) do
            
            AExitField = UIMapDirectionToExit[exit]
            AVector = UIMapDirectionToVector[exit]            
            AExitTypeField = UIMapDirectionToExitType[exit]
            AExitRoom = UIMapDirectionToExitRoom[exit]
               
            if (self.CurrentRoom[AExitField] < 1) then                                               
               
               ARoom = self.RoomGetXYZ(self.CurrentRegion,
                  self.CurrentRoom.RoomPositionX+(AVector.x*AStride),
                  self.CurrentRoom.RoomPositionY+(AVector.y*AStride),
                  self.CurrentRoom.RoomPositionZ+(AVector.z*AStride))
               
               if ARoom then
                  AOppExit = UIMapDirectionOpposite[exit]
                  AOppExitField = UIMapDirectionToExit[AOppExit]
                  AOppExitRoom = UIMapDirectionToExitRoom[AOppExit]
                  if ARoom[AOppExitField] == 0 then
                     ARoom[AOppExitRoom] = self.CurrentRoom
                     ARoom[AOppExitField] = tonumber(self.CurrentRoom.RoomID)
                     self.CurrentRoom[AExitRoom] = ARoom
                     self.CurrentRoom[AExitField] = tonumber(ARoom.RoomID)                              
                  end                 
                  UIMapDBRoomWrite(ARoom)          
               end            
            end
            
            if self.CurrentRoom[AExitField] == -1 then
               self.CurrentRoom[AExitField] = 0
            end
                                     
            AChar = UIMapCaptureGetChar(UIMapCapturePlayerPositionX+AVector.x, UIMapCapturePlayerPositionY+AVector.y)            
            self.CurrentRoom[AExitTypeField] = UIMapGetCharExitType(AChar)                          
         end
   
         --Update currents incase write was just enabled                             
      end
       
      UIMapDBRegionWrite(self.CurrentRegion)   
      UIMapDBSectorWrite(self.CurrentSector)
      
      if self.CurrentRoom then
         self.CurrentRoom.RegionID = self.CurrentRegion.RegionID
         self.CurrentRoom.SectorID = self.CurrentSector.SectorID                                           
         UIMapDBRoomWrite(self.CurrentRoom)
      end                                                           
   end
   
   
    
   -----------------------------------------------------------------------------      
   function self.MergeMapCapture()   
      local CellX = 0
      local CellY = 0
      local ASector = {}
      local ASectorX = 0
      local ASectorY = 0
      local ASectorZ = 0
               
      local ASectorPosX = 0
      local ASectorPosY = 0
      local ASourceChar = ""
      local ASourceCharColour = ""
      local ADestChar = ""
      local ADestData = ""
      local ADestDataColour = ""
      local AColourID = 1
      
      local AWrittenSectors = {}
      
      --merge MapCapture data into current buffers            
      for AX = 1, UIMapCaptureCellWidth do   
         CellX = FCaptureCellLeft+(AX-1)
         for AY = 1, UIMapCaptureCellHeight do                    
            CellY = FCaptureCellTop+(AY-1)              
            
            --get target sector for this cell
            ASectorX = math_floor(CellX / UIMapSectorSize)
            ASectorY = math_floor(CellY / UIMapSectorSize)                                                
            ASector = self.CurrentRegion.RegionSectorsXYZ[ASectorX..":"..ASectorY..":"..ASectorZ]                             
            if not ASector then               
               ASector = self.SectorCreate(self.CurrentRegion,ASectorX, ASectorY, ASectorZ)               
            end
            
            --add to written cache
            AWrittenSectors[ASector.SectorID] = ASector
                        
                                                          
            --Internal sector char coords for this cell                        
            ASectorPosX = (CellX - ASector.CellLeft)+1
            ASectorPosY = (CellY - ASector.CellTop)+1
                                                                              
            ASourceChar = string_sub(UIMapCaptureDataText[AY],AX,AX)
                        
            --Only write non blank chars
            if ASourceChar ~= " " then     
               if ASectorPosY > #ASector.SectorData then
                  Note("ERROR SECTORID : " .. ASector.SectorID)
               end                                                                                                                  
               ADestData = string_sub(ASector.SectorData[ASectorPosY],1) --get destination data string from buffer                                                        
               ADestChar = string_sub(ADestData,ASectorPosX,ASectorPosX) --get destination char from data string
                                                                          
               if ((ADestChar == "x") and ((ASourceChar == "\\") or (ASourceChar == "/"))) then --Don't merge character
                  --handles 'x' turning into '/' or '\' due to visibility (and the place for any other such quirks)                                                                                    
               else --Merge character                                                                         
                  ASourceCharColour = string_sub(UIMapCaptureDataColour[AY],AX,AX)                                                      
                  ADestDataColour = string_sub(ASector.SectorDataColour[ASectorPosY],1)                  
                  --replace misc active chars and colours
                  if ASourceChar == "@" then
                     ASourceChar = "*"              
                  elseif (self.CurrentRegion.RegionType == 1) and ((ASourceChar == "&") or (ASourceChar == "$") or (ASourceChar == "^") or (ASourceChar == "v")) then            
                     ASourceChar = "*" 
                  end                  
                  
                  if ((self.CurrentRegion.RegionType == 1) or (self.CurrentRegion.RegionType == 2)) and (ASourceChar == "*") then
                     --override colours
                     AColourID = UIMapColoursID.cyan 
                     ASourceCharColour = string_char(AColourID+47) --to avoid various sql sensitive chars, starts at '0'                                                                                                    
                  end
                                                                                                                                                                                                                                                                                                                                  
                  --merge source char into destination string                                    
                  ASector.SectorData[ASectorPosY] = string_sub(ADestData,1,ASectorPosX-1) .. ASourceChar .. string_sub(ADestData,ASectorPosX+1)                                                                                                                                                                                                    
                  --merge source colour char into destination string                                    
                  ASector.SectorDataColour[ASectorPosY] = string_sub(ADestDataColour,1,ASectorPosX-1) .. ASourceCharColour .. string_sub(ADestDataColour,ASectorPosX+1)                                                                        
               end
            end                                  
         end
      end
        
      --write any changed sectors                                 
      for _,BSector in pairs(AWrittenSectors) do        
         UIMapDBSectorWrite(BSector)                              
      end
   end  

   -----------------------------------------------------------------------------
   function self.PathFind(ARoomStart, ARoomEnd)
      if UI_DebugMapPath then  
         UILog("UIMapBuffer.PathFind", "Start Pathfind ["..ARoomStart.RoomName.." > " ..ARoomEnd.RoomName.."]", 0)             
      end   
      self.PathRoomStart = ARoomStart
      self.PathRoomEnd = ARoomEnd             
      self.Path = PathFind(ARoomStart, ARoomEnd, self.Rooms, true)      
      if UI_DebugMapPath then      
         if not self.Path then
            UILog("UIMapBuffer.PathFind", "No Path Found",1)
         end        
      end      
      if UI_DebugMapPath then  
         UILog("UIMapBuffer.PathFind", "End Pathfind ["..ARoomStart.RoomName.." > " ..ARoomEnd.RoomName.."]", 0)             
      end                 
   end      
   if UI_DebugMapBuffer then    
      UILog("UIMapBufferCreate", "Creating Map Buffer", 0)
   end
   
      -----------------------------------------------------------------------------
   --the viewport upon this buffer in cell coordinates
   function self.SetView(ALeft, ATop, ARight, ABottom)
      
      --Store view
      self.CellLeft = ALeft
      self.CellTop = ATop
      self.CellRight = ARight
      self.CellBottom = ABottom
      self.CellWidth = ARight-ALeft
      self.CellHeight = ABottom-ATop
                 
      --Calculate sectors
      self.SectorLeft = math_floor(self.CellLeft / UIMapSectorSize)
      self.SectorTop = math_floor(self.CellTop / UIMapSectorSize)
      self.SectorRight = math_ceil(self.CellRight / UIMapSectorSize)
      self.SectorBottom = math_ceil(self.CellBottom / UIMapSectorSize)
          
      --[[
      --TODO improve      
      --get top level bounds
      local ARegion = self.CurrentRegion
      local BRegion = self.CurrentRegion
      while ARegion.RegionParent do   
         BRegion = ARegion   
         ARegion = ARegion.RegionParent
      end
      
      --clip to region sector boundry
      local ASectorLeft = math.max(self.SectorLeft, BRegion.RegionSectorLeft)   
      local ASectorTop = math.max(self.SectorTop, BRegion.RegionSectorTop)       
      local ASectorRight = math.min(self.SectorRight, BRegion.RegionSectorRight)
      local ASectorBottom = math.min(self.SectorBottom, BRegion.RegionSectorBottom)
      --]]
                          
      --for AX = ASectorLeft, ASectorRight do
      --   for AY = ASectorTop, ASectorBottom do            
      --      --cache any visible sector            
      --      self.SectorGetXYZ(self.CurrentRegion,AX,AY,0)                              
      --   end      
      --end            
   end
        
   -----------------------------------------------------------------------------
   --Constructor                                                     Constructor
   -----------------------------------------------------------------------------
      
   --initialize map buffer         
   
   self.RootRegion = self.RegionGet(1) -- 1 = Ankh-Morpork
   
   --self.RootRegion = self.RegionGet(2) -- 1 = DiscRegion
       
   
   
   --Empty database - start new
   --[[
   if self.CurrentRegion == nil then
      self.CurrentRegion = self.RegionCreate()
      self.RootRegion = self.CurrentRegion
      self.PreviousRegion = self.CurrentRegion      
   else
   end
                
   self.CurrentSector = self.SectorGetXYZ(self.CurrentRegion,0,0,0)               
   if self.CurrentSector == nil then      
      self.CurrentSector = self.SectorCreate(self.CurrentRegion,0,0,0)
      self.PreviousSector = self.CurrentSector   
   else
   end
                
   self.CurrentRoom = self.RoomGetXYZ(self.CurrentRegion,0,0,0) --temp high altar      
   if self.CurrentRoom == nil then
      self.CurrentRoom = self.RoomCreate(self.CurrentRegion,self.CurrentSector,0,0,0)
      self.PreviousRoom = self.CurrentRoom  
   else
   end
   --]]   
   
   
   --Temp local high altar of sek, change to load last previous stored location
   self.CurrentRegion = self.RegionGet(3) --temple of sek
   self.CurrentRoom = self.RoomGet(1586) --high altar of sek                               
   self.PlayerPositionX = self.CurrentRoom.RoomPositionX
   self.PlayerPositionY = self.CurrentRoom.RoomPositionY
   self.PlayerPositionZ = self.CurrentRoom.RoomPositionZ
   local ASectorX = math_floor((self.PlayerPositionX) / UIMapSectorSize)
   local ASectorY = math_floor((self.PlayerPositionY) / UIMapSectorSize)                        
   local ASectorZ = math_floor((self.PlayerPositionZ) / UIMapSectorSize)            
   self.CurrentSector = self.SectorGetXYZ(self.CurrentRegion, ASectorX, ASectorY, ASectorZ)               
   self.PreviousRoom = self.CurrentRoom
   
   --Move the camera to track the players position  
   --UIWindowMap.CameraPositionX = (self.CurrentRegion.RegionParentPositionX + self.CurrentRoom.RoomPositionX)
   --UIWindowMap.CameraPositionY = (self.CurrentRegion.RegionParentPositionY + self.CurrentRoom.RoomPositionY)
   
   return self
end
