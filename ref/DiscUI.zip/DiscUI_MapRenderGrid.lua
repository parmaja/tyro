--------------------------------------------------------------------------------
--//DiscUI Surface Buffer
--------------------------------------------------------------------------------
local UIMapRenderGridCounter = 0
local UIMapRenderGrids = {} 

local FWindowDrawImage = WindowDrawImage
local FWindowBlendImage = WindowBlendImage    

function UIMapRenderGridCreate(AWindow, ACellWidth)
   --create self instance
   local self = {}
   self.id = UIMapRenderGridCounter
   UIMapRenderGridCounter = UIMapRenderGridCounter + 1
   
   -----------------------------------------------------------------------------
   --Private                                                             Private
   -----------------------------------------------------------------------------
   local FWindow = AWindow
   local FCellWidth = ACellWidth --the grid X and Y dimensions
   
   local FSurfaces = {} --collection of surfaces in this Map render buffer        
   local FSurfacesCount = FCellWidth*FCellWidth --total surface count
   local FSurfaceResolution = 256

   -----------------------------------------------------------------------------
   --Public                                                               Public
   -----------------------------------------------------------------------------
     
   --Render to target
   function self.RenderTo(AWindow,ALeft,ATop,ARight,ABottom)      
      --FWindowDrawImage(AWindow.MushWindow, self.Image, ALeft, ATop, ARight, ABottom, 2) --slower but scaling            
      FWindowBlendImage(AWindow.MushWindow, self.Image, ALeft, ATop, ARight, ABottom, 1, 1) --faster but no scaling     
   end
      
   --construct surface cache  
   local FSurface = nil
   
   local Ax = 0
   local Ay = 0
   
   for Ax = 1, FCellWidth do
      for Ay = 1, FCellWidth do
      
         FSurface = UISurfaceCreate(AWindow, FSurfaceResolution, FSurfaceResolution)
         
         --add local references
         FSurface.MapRenderGridX = Ax
         FSurface.MapRenderGridY = Ay
         FSurface.SurfaceIndex = #FSurfaces
           
         table.insert(FSurfaces, FSurface)
      end
   end

   --insert reference into Surface buffer collection
   table.insert(UIMapRenderGrids,self)   
   return self        
end   