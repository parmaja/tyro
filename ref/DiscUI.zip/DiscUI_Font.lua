--//DiscUI Font 

--------------------------------------------------------------------------------
--//DiscUI Font Variables
--------------------------------------------------------------------------------


--------------------------------------------------------------------------------
--//DiscUI Font Functions
--------------------------------------------------------------------------------

function UIFontCreate(AWindow, AFontID, AFontName, AFontSize, ABold)

   if ABold == nil then
      WindowFont(AWindow, AFontID, AFontName, AFontSize, false, false, false, false, 0, 49)  -- Normal   
   elseif ABold == true then
      WindowFont(AWindow, AFontID, AFontName, AFontSize, true, false, false, false, 0, 49)  -- Bold         
   else
      WindowFont(AWindow, AFontID, AFontName, AFontSize, true, false, false, false, 0, 49)  -- Normal
   end      
end