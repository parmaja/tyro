--------------------------------------------------------------------------------
--//DiscUI Map Capturing
--------------------------------------------------------------------------------

--local references for optimization
local string_gmatch = string.gmatch
local string_match = string.match
local string_find = string.find
local string_sub = string.sub

UIMapCaptureMapDataGMCP = {} --GMCP with MXP colours
UIMapCaptureMapData = {} --MUSHClient Style runs
UIMapCaptureRoomName = "" --Captured Room Name 
UIMapCaptureRoomDescription = {} --Captured Description / room statusd 
UIMapCaptureRoomExits = "" --Captured Exits String 

UIMapCaptureRoomObjectsFlag = false
UIMapCaptureRoomObjectsLiving = {}
UIMapCaptureRoomObjectsFloor = {}

UIMapCaptureDataText = {} --Converted MapBuffer Text Data
UIMapCaptureDataColour = {} --Converted MapBuffer Colours
UIMapCaptureDataRoomExits = {} --Converted Room Exit Array 

--dimensions of capture data
UIMapCaptureCellWidth = 0
UIMapCaptureCellHeight = 0

--internal player position inside capture data
UIMapCapturePlayerPositionX = 0
UIMapCapturePlayerPositionY = 0


--local vars
local OutputMapFlag = true
local OutputMapTimeStamp = 0
local OutputMapLines = {}

local CurrentAchievement = ""

   
function UICaptureChat(sName, sLine, wildcards)
   EnableTrigger("TriggerCaptureChat", false)
   UIWindowTalkerInput(sLine)           
end

function UICaptureAchievementStart(sName, sLine, wildcards)   
   CurrentAchievement = string.sub(sLine, 26)
   
   --testing
   --Note("UICaptureAchievementStart = '" .. CurrentAchievement .. "'")
                      
   EnableTrigger("TriggerAchievementCaptureStart", false)
   EnableTrigger("TriggerAchievementCaptureProgress", true)     
end

function UICaptureAchievementProgress(sName, sLine, wildcards)                
   local PercentString = string.gsub(string.sub(sLine, 26), " percent","")
   
   --testing   
   Note(CurrentAchievement .. " = '" .. PercentString .. "'") 
                 
   if (CurrentAchievement == "Overprotective") then
     UICharacter.SetValueFromMUD(CurrentAchievement, PercentString)
     
   end
                     
   EnableTrigger("TriggerAchievementCaptureStart", true)
   EnableTrigger("TriggerAchievementCaptureProgress", false)     
end



--------------------------------------------------------------------------------
function UIMapCaptureGetChar(APosX, APosY)
   if (APosX < 1) or (APosX > UIMapCaptureCellWidth) then return " " end
   if (APosY < 1) or (APosY > UIMapCaptureCellHeight) then return " " end                    
   return string.sub(UIMapCaptureDataText[APosY],APosX,APosX)   
end

--function UIMapCapture
--------------------------------------------------------------------------------
function UIMapCapturePrepareExitsString(AString)  

   --skip 'there are xxxx : '
   local AFindPos = string.find(AString, ": ")

   --no exits in string
   if AFindPos == nil then 
      return ""
   end
       
   -- Remove everything up to ": "
   --local AResult = string.gsub(AString, ".*: ","")
   
   --get the exits string
   local AResult = string.sub(AString,AFindPos+2, #AString-1)
   
   --replace ' and '
   AResult = string.gsub(AResult, " and ",",")
   --replace ', '
   AResult = string.gsub(AResult, ", ",",")
   
   -----------------
   --TESTING remove journey
   AResult = string.gsub(AResult, "journey ","")
                     
   return AResult        
end
        
--------------------------------------------------------------------------------
--//Trigger Functions
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
function UICaptureMapDescription(sName, sLine, wildcards)
   UIMapCaptureRoomDescription[#UIMapCaptureRoomDescription+1] = sLine  
end 

--------------------------------------------------------------------------------
function UICaptureRoomName(sName, sLine, wildcards)
   UIMapCaptureRoomName = wildcards[1]   
   --Note("UICaptureRoomName = "..UIMapCaptureRoomName)
   UIMapCaptureRoomDescription = {} 
   EnableTrigger ("TriggerMapDescription", true) -- start capturing desciption     
end
 
--------------------------------------------------------------------------------
function UICaptureMapExits(sName, sLine, wildcards)
   
   -- end capturing desciption    
   EnableTrigger ("TriggerMapDescription", false)
   -- disable room name trigger
   EnableTrigger ("TriggerMapRoomName", false) -- start capturing room name
   --store exists string
   UIMapCaptureRoomExits = sLine      
                                                                                                             
   UIMapColoursWrite()
   
   --Merge the map capture before we continue
   --do so first incase we've switched to a new region for the current data                   
   UIMapBuffer.CalculateCaptureLocation()                  
   UIMapBuffer.MergeMapCapture()   
   
   --move to new room/region/sector if valid move (ie not 'look')
   UIMapBuffer.MoveDirectionAttemptConfirm()
   
   --Convert new data into map buffer format  
   UIMapCaptureConvertOutputLookGMCP()
   UIMapCaptureConvertOutputLookExits()   
            
   --reset Current Room Objects
   UIMapCaptureRoomObjectsLiving = {}
   UIMapCaptureRoomObjectsFloor = {}
   UIMapCaptureRoomObjectsFlag = true
   
            
   --TODO this is writing before we move, restucture and do first
   UIMapBuffer.UpdateFromCapture()             
                             
   -- Re-Render Map
   UIWindowMap.TitleBarText = UIMapCaptureRoomName
   
   UIWindowMap.Render()
   
   UIWindowMapInfo.Render()
   UIWindowMapEdit.Render()
   
   UIWindowMapLocal.Render()   
   UIWindowMapSearch.Render()
   UIWindowOptions.Render()
   
   UIWindowStats.Render()
   UIWindowTalker.Render()   
                  
end

--------------------------------------------------------------------------------
function UICaptureMapFail(sName, sLine, wildcards)
   UILog("UICaptureMapFail",sLine)
   UIMapBuffer.MoveDirectionAttemptFail()                       
end

--------------------------------------------------------------------------------
function UIMapCaptureConvertOutputLookExits()
--Convert exits string into exits list
   UIMapCaptureDataRoomExits = {}   
   local ExistsString = UIMapCapturePrepareExitsString(UIMapCaptureRoomExits)
   
   local AExits = split(ExistsString,",")
   local AExit = ""     
   for I =  1, #AExits do
      AExit = UIMapDirectionMin[string.lower(AExits[I])]
      if AExit then
         table.insert(UIMapCaptureDataRoomExits, string.sub(AExit,1))
      else
         UILog("UIMapCaptureConvertOutputLookExits", "Unhandled exit : "..AExits[I])
      end                     
   end
      
   if UI_DebugMapCapture then         
      for I = 1, #UIMapCaptureDataRoomExits do
         UILog("UIMapCaptureConvertOutputLookExits", "Exits : "..UIMapCaptureDataRoomExits[I]) 
      end
   end                    
end

--------------------------------------------------------------------------------
function UIMapCaptureEntities(sName, sLine, wildcards)



   --local AEntityString = sLine
   --local AStanding = ""
   --local AFighting = ""
   
   --AEntityString = string.gsub(AEntityString, " are ",", ")
   --AEntityString = string.gsub(AEntityString, " is ",", ")
   --AEntityString = string.gsub(AEntityString, " and a ",", ")
   --AEntityString = string.gsub(AEntityString, " and a ",", ")
   
   --A mean mercenary and two cockroaches are standing here.
   --A mean mercenary and two cockroaches
   --standing here.
   --A mean mercenary,two cockroaches,standing here. 
   
   --A quick errand boy, a boring troll and a drunken sailor are standing here.
   --A quick errand boy
   --a boring troll
   --drunken sailor
   --standing here.
   --A quick errand boy,a boring troll,drunken sailor,standing here.
   
   --An enormous whirlwind of pure faith is whirling, a colossal whirlwind of pure faith is twirling and a jovial priestess and a pious priestess are standing here.
   --An enormous whirlwind of pure faith
   --whirling
   --a colossal whirlwind of pure faith
   --twirling
   --jovial priestess
   --pious priestess
   --standing here.
   
   --A paperboy is fighting here, an enormous whirlwind of pure faith is whirling, a colossal whirlwind of pure faith is twirling and Dogbottler is standing here.
   --A paperboy
   --fighting here
   --an enormous whirlwind of pure faith
   --whirling
   --a colossal whirlwind of pure faith
   --twirling and Dogbottler
   --standing here.
   
   --A colossal whirlwind of pure faith, an enormous whirlwind of pure faith and a paperboy are fighting here and Dogbottler is standing here.
   --A colossal whirlwind of pure faith
   --an enormous whirlwind of pure faith
   --paperboy
   --fighting here and Dogbottler
   --standing here.
   
   --A dwarf bodyguard, a creepy banker, a colossal whirlwind of pure faith and an enormous whirlwind of pure faith are fighting here and a rough real cat and Dogbottler are standing here.
   --A dwarf bodyguard
   --a creepy banker
   --a colossal whirlwind of pure faith and an enormous whirlwind of pure faith
   --fighting here
   --rough real cat and Dogbottler
   --standing here.   
               
   --world.Note(AEntityString)
   
   --local AEntities = split(AEntityString,", ")   
   --for I = 1,#AEntities do
   --   world.Note(AEntities[I])
   --end
   
   --[[ 
   AEntityString = string.gsub(AEntityString, " are standing here."," [S1]")
   AEntityString = string.gsub(AEntityString, " is standing here."," [S1]")
   AEntityString = string.gsub(AEntityString, " are standing here."," [S1]")
   AEntityString = string.gsub(AEntityString, " is standing here."," [S1]")
   AEntityString = string.gsub(AEntityString, " are fighting here and "," [F0]")
   AEntityString = string.gsub(AEntityString, " is fighting here and "," [F0]")
   --]]
           
   --replace ' and '
   --AEntityString = string.gsub(AEntityString, " and ",",")
   --replace ', '
   --AEntityString = string.gsub(AEntityString, ", ",",")
    
   --A mean mercenary is fighting here, a large black cloud is buzzing noisily and a believing man is standing here.
                        
   --Split multiple states   
   --local ASplitPos = 0   
   --ASplitPos = string_find(AEntityString, "[F0]")
   
   --if ASplitPos then      
   --   world.Note("EntityString SplitPos : " ..ASplitPos)
   --   AFighting = string_sub(AEntityString,1, ASplitPos)
   --   AStanding = string_sub(AEntityString,1, ASplitPos)            
   --end
         
   
end

--------------------------------------------------------------------------------
function UIMapCaptureConvertOutputLookGMCP()

   local DefaultColour = 0x444444  
   local CurrentColour = 0x000000 
   local FTag = ""
   local FTagFlag = false
   
    
   local AX = 0
   local AY = 0
   local AMaxX = 0
   local AMaxY = 0
   
   local ALineText = ""
   local ALineColour = ""
      
   local AColourID = 1
   local AColourNewID = 1
   
   --Reset Char capture arrays
   if UIMapCaptureDataText ~= nil then
      for k in pairs(UIMapCaptureDataText) do
         UIMapCaptureDataText[k] = nil
      end      
   end   
   if UIMapCaptureDataColour ~= nil then   
      for k in pairs(UIMapCaptureDataColour) do
         UIMapCaptureDataColour[k] = nil
      end      
   end
   
   UIMapCaptureDataText = {}
   UIMapCaptureDataColour = {}
   
   --[[
   if UI_DebugMapCapture then 
      for I,Line in ipairs(UIMapCaptureMapDataGMCP) do                  
         UILog("GMCP_MAP",Line,1)
      end
   end    
   --]]
               
   AY = 1              
   for I,Line in ipairs(UIMapCaptureMapDataGMCP) do
      AX = 1            
         
      --[3z reset = close all open tags.  Set mode to Open.  Set text color and properties to default.
      --[4z temp secure mode = set secure mode for the next tag only.  Must be immediately followed by a < character to start a tag.  Remember to set secure mode when closing the tag also.
                 

      --strip that which is required not      
      Line = string.gsub(Line, "\\u001b", "") --strip ANSI CLS escape code        
      Line = string.gsub(Line, "MXP", "") --Strip 'MXP' from Line                
      Line = string.gsub(Line, "%[3z", "<�>") --Strip MXP Reset escape code (replace with a char for resetting colours)             
      Line = string.gsub(Line, "%[4z", "") --Strip MXP temp secure mode escape code                  

      --[[      
      \a bell
      \b back space
      \f form feed
      \n newline
      \r carriage return
      \t horizontal tab
      \v vertical tab
      \\ backslash
      \" double quote
      \' single quote
      \[ left square bracket
      \] right square bracket
      --]]
      Line = string.gsub(Line, "\\\/", "\/") --Replace string escape codes
      Line = string.gsub(Line, "\\\\", "\\")
      Line = string.gsub(Line, "\\\"", "\"")
      
      if UI_DebugMapCapture then  
         UILog("MAPStrip",Line,0)
      end
      
      --loop chars in this line      
      if #Line > 0 then 
              
         for AChar in string.gmatch(Line,".") do
            --determine Maximum X
                                      
            if (AChar == "<") and not FTagFlag then
               FTagFlag = true            
            elseif (AChar == ">") and FTagFlag then
               --Process Tag
               
               if FTag == "�" then --Refactored MXP reset tag - reset colour to default
                  AColourID = 1
               else              
                  --check if this is a new valid colour tag               
                  AColourNewID = UIMapColoursID[string.lower(FTag)]               
                  if AColourNewID then                   
                     AColourID = AColourNewID                                    
                     if UI_DebugMapCapture then
                        UILog("UIMapCaptureConvertOutputLookGMCP","Valid Colour '"..FTag.."'",0)
                     end
                  end                  
                  if UI_DebugMapCapture then
                     if not AColourNewID then                  
                        UILog("UIMapCaptureConvertOutputLookGMCP","Unhandled Tag '"..FTag.."'",1)                  
                     end
                  end                            
               end
                                                                                                 
               FTagFlag = false
               FTag = ""            
            elseif FTagFlag then  --We're inside a tag                                                             
               FTag = FTag .. AChar
            elseif not FTagFlag then
               --Not inside Tag - Map character               
               if AX > AMaxX then 
                  AMaxX = AX
               end
                                                   
               ALineText = ALineText .. AChar --Add Map Char
                             
               if AChar ~= " " then                  
                  ALineColour = ALineColour .. string.char(AColourID+47) -- starts at '0' avoid various control chars, may as well.
                  --UILog("UIMapCaptureConvertOutputLookGMCP","CharColour '"..AColourID.."'",0)
               else              
                  ALineColour = ALineColour .. " " --no char? no colour.  
               end
                                                                         
               --Is this the players positon inside the capture data?
               if (AChar == "@") and (AColourID == UIMapColoursID['yellow']) then
                  UIMapCapturePlayerPositionX = AX
                  UIMapCapturePlayerPositionY = AY
               end
              
               AX = AX + 1                        
            end                                         
         end  -- for AChar in string.gmatch(pair.text,".") do           
      table.insert(UIMapCaptureDataText, string.sub(ALineText,1))
      table.insert(UIMapCaptureDataColour, string.sub(ALineColour,1))
            
      ALineText = ""
      ALineColour = ""  
      AMaxY = AY   
      AY = AY + 1      
      end                           
   end --for I,Line in ipairs(UIMapCaptureMapDataGMCP) do
   UIMapCaptureCellWidth = AMaxX
   UIMapCaptureCellHeight = AMaxY   
   
   if UI_DebugMapCapture then       
      for I,line in ipairs(UIMapCaptureDataText) do   
         UILog("GMCP","\["..line.."\]",0)
      end
   end  
   
   if UI_DebugMapCapture then
      UILog("PLAYER X","\["..UIMapCapturePlayerPositionX.."\]",0)
      UILog("PLAYER Y","\["..UIMapCapturePlayerPositionY.."\]",0)
      UILog("MAP WIDTH","\["..UIMapCaptureCellWidth.."\]",0)
      UILog("MAP HEIGHT","\["..UIMapCaptureCellHeight.."\]",0)
      for I,line in pairs(UIMapCaptureDataText) do   
            UILog("MAP","\["..line.."\]",0)
         end         
      for I,line in pairs(UIMapCaptureDataColour) do   
            UILog("MAPc","\["..line.."\]",0)
      end
   end          
end  

--------------------------------------------------------------------------------
function UIMapCaptureConvertOutputMapDo()  

   --Convert captured map data into internal map format
    
   --Reset Char capture arrays
   if UIMapCaptureDataText ~= nil then
      for k in pairs(UIMapCaptureDataText) do
         UIMapCaptureDataText[k] = nil
      end
   end  
   if UIMapCaptureDataColour ~= nil then   
      for k in pairs(UIMapCaptureDataColour) do
         UIMapCaptureDataColour[k] = nil
      end
   end
  
   UIMapCaptureDataText = {}
   UIMapCaptureDataColour = {} 
             
   local AX = 0
   local AY = 0
   local AMinX = 999999999
   local AMaxX = 0
   local AMaxY = 0
   local ALineText = ""
   local ALineColour = ""
   local AColourID = 0
          
   AY = 1
   for line, styles in ipairs(OutputMapLines) do     
      AX = 1   
      for _, Style in ipairs(styles) do                                      
                                
         --lookup the ID of this Colour
         
         
         AColourID = UIMapColoursRGBToID[Style.textcolour]
         
         if not AColourID then 
            UILog("UIMapCaptureConvertOutputMapDo","UNKNOWN COLOUR = " .. num2hex(Style.textcolour),1)
            AColourID = 1 
            
            end 
                          
         --Loop chars in this style set
         for AChar in string.gmatch(Style.text,".") do            
            --determine Maximum X
            if AX > AMaxX then 
               AMaxX = AX
            end                
            ALineText = ALineText .. AChar            
            if AChar ~= " " then
               ALineColour = ALineColour .. string.char(AColourID+47) --to avoid ' and " in sql statements, starts at '0'
            else
               --if there's no char, don't write the colour
               ALineColour = ALineColour .. " " --to avoid ' and " in sql statements, starts at '0'
            end                                                       
            --determine player position                                                        
            AX = AX + 1            
         end                                                                  
      end      
      --add lines to capture buffers
      table.insert(UIMapCaptureDataText, string.sub(ALineText,1))
      table.insert(UIMapCaptureDataColour, string.sub(ALineColour,1))                                
      ALineText = ""
      ALineColour = ""
      if AX < AMinX then AMinX = AX end                  
      AMaxY = AY   
      AY = AY + 1                  
   end
          
   --Remove Map Key, Try to detect column     
   local APos = 0
   local Pos1 = 0
   local Pos2 = 0
   local Pos3 = 0
   local BLine = 0   
   for I,ALine in ipairs(UIMapCaptureDataText) do
      BLine = UIMapCaptureDataColour[I] 
      --space space space space space char space char char
      APos = string.find(ALine, "  [\/%a%c%d%l%p%u%w%z] %a%a.+$")                  
      if APos then
         if Pos1 == 0 then Pos1 = APos
         elseif Pos2 == 0 then Pos2 = APos
         elseif Pos3 == 0 then Pos3 = APos end                                  
      end             
   end
     
   --choose the column position to use      
   if (Pos1 == 0) and (Pos2 == 0) and (Pos3 == 0) then
      APos = AMinX      
   elseif (Pos1 > 0) and (Pos2 == 0) and (Pos3 == 0) then
      APos = Pos1         
   elseif (Pos1 == Pos2) then
      APos = Pos1
   elseif (Pos2 == Pos3) then 
      APos = Pos2
   end              
   
   if not APos then
      if AMinX == 0 then
         UILog("UIMapCaptureConvertOutputMapDo", "APos and AMinX not found")
         return
      end 
      APos = AMinX   
   end
   
   --clip against minimum line length if it exists
   if (AMinX > 1) and (AMinX < APos) then APos = AMinX end 
   
   --Remove key from map      
   for I,ALine in ipairs(UIMapCaptureDataText) do
      BLine = UIMapCaptureDataColour[I] 
      UIMapCaptureDataColour[I] = string.sub(BLine,1,APos-1)
      UIMapCaptureDataText[I] = string.sub(ALine,1,APos-1)                                          
   end

   --detect data dimensions / player position
   UIMapCaptureCellWidth = 0
   UIMapCaptureCellHeight = 0
   UIMapCapturePlayerPositionX = 0
   UIMapCapturePlayerPositionY = 0
   AY = 1
   AMaxX = 1
   local ACharColour = 0
   local ACharColourID = 0   
   for _,Line in pairs(UIMapCaptureDataText) do  
      AMaxY = AY
      AX = 1   
      for AChar in string.gmatch(UIMapCaptureDataText[AY],".") do
         if AX > AMaxX then 
            AMaxX = AX
         end   
         ACharColour = string.sub(UIMapCaptureDataColour[AY],AX,AX)
         ACharColourID = string.byte(ACharColour)-47                                                   
                                    
         if AChar == "@" and (ACharColourID == UIMapColoursID.yellow) then
            UIMapCapturePlayerPositionX = AX
            UIMapCapturePlayerPositionY = AY
         end
         AX = AX + 1              
      end       
      AY = AY + 1                                           
   end      
   
   UIMapCaptureCellWidth = AMaxX
   UIMapCaptureCellHeight = AMaxY   
   
   if UI_DebugMapCapture then            
      UILog("PLAYER X","\["..UIMapCapturePlayerPositionX.."\]",0)
      UILog("PLAYER Y","\["..UIMapCapturePlayerPositionY.."\]",0)
      UILog("MAP WIDTH","\["..UIMapCaptureCellWidth.."\]",0)
      UILog("MAP HEIGHT","\["..UIMapCaptureCellHeight.."\]",0)
      for I,line in ipairs(UIMapCaptureDataText) do   
            UILog("MAP","\["..line.."\]",0)
         end         
      for I,line in ipairs(UIMapCaptureDataColour) do   
            UILog("MAPc","\["..line.."\]",0)
      end
   end       
end

--------------------------------------------------------------------------------
function UIMapCaptureConvertOutputMap(sName, sLine, wildcards, styles)
   
   if OutputMapFlag then
      OutputMapTimeStamp = UIMushGetTime()
      OutputMapFlag = false 
   end
   
   --assumes alias 'm' as 'map;yawn'
   if (sLine == "You yawn.") or (sLine == "Queued command: yawn") then
   
      UIMapCaptureConvertOutputMapDo()
      
      UIMapBuffer.CalculateCaptureLocation()   
      UIMapBuffer.MergeMapCapture() 
      
      OutputMapLines = {}
      OutputMapFlag = true --reset for next time            
      EnableTrigger("TriggerMapCaptureOutputMap", false)
   else
   
      if #OutputMapLines == 0 then
         if string.sub(sLine,1,1) == " " then
            table.insert(OutputMapLines, styles)
         end
      else
         table.insert(OutputMapLines, styles)
      end    
           
   end     
end

--------------------------------------------------------------------------------
function UIMapCaptureConvertOutputGlance()

end
