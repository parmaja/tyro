--------------------------------------------------------------------------------
--//DiscUI Widget 
--------------------------------------------------------------------------------

-- Global private
   local UIWidgetCounter = 0 
   
--Global
   UIWidgets = {}
   
   --Widget types
   UIWidget_Widget = 0
   UIWidget_Label = 1
   UIWidget_Button = 2
   UIWidget_Editbox = 3
   UIWidget_Dropdown = 4
   UIWidget_Listview = 5
   UIWidget_Treeview = 6
   UIWidget_Memo = 7
   UIWidget_Bar = 8
   UIWidget_Graph = 9
   UIWidget_Scrollbar = 10
   
   
   
   --recieves keyboard events
   UIWidgtFocused = nil


function UIWidgetCreate(AWindow, AWidgetLeft, AWidgetTop, AWidgetRight, AWidgetBottom)
   --create self instance
   local self = {}
   self.id = UIWidgetCounter
   UIWidgetCounter = UIWidgetCounter + 1
   
   -- Private variables   
   local FFontName = "Consolas"
   local FFontHeight = 10
                
   -- Private methods
             
   -- Public variables
   self.WidgetType = UIWidget_Widget
   self.WidgetTypeName = "Widget"
   self.Window = AWindow              
   self.Left = AWidgetLeft
   self.Top = AWidgetTop
   self.Right = AWidgetRight
   self.Bottom = AWidgetBottom
   self.Width = AWidgetRight-AWidgetLeft
   self.Height = AWidgetBottom-AWidgetTop
   self.WidthDiv2 = self.Width / 2
   self.HeightDiv2 = self.Height / 2
   
   self.Anchor = {}
   self.Anchor.Left = true
   self.Anchor.Top = true
   self.Anchor.Right = false
   self.Anchor.Bottom = false
   
   self.Caption = ""
   self.CaptionWidth = 0
   self.CaptionHeight = 0
   self.CaptionWidthDiv2 = 0
   self.CaptionHeightDiv2 = 0
   self.Font = AWindow.Font          
   
   self.ColourBackgroundHovering = 0x555555
   self.ColourBackground = 0x000000
   self.ColourFont = 0xFFFFFF
      
   -- Callbacks
   self.OnRender = nil   
   self.OnMouseMove = nil
   self.OnMouseButton = nil
   self.OnMouseWheel = nil
   self.OnKeyboard = nil
   
   
   self.Hotspot = ""
   self.IsHovering = false
      
   
   
   function self.SetLeft(ALeft)
      self.Left = ALeft                
      self.Width = self.Right-self.Left  
      self.WidthDiv2 = self.Width / 2      
   end
   
   function self.SetTop(ATop)
      self.Top = ATop               
      self.Height = self.Bottom-self.Top
      self.HeightDiv2 = self.Height / 2      
   end
   
   function self.SetRight(ARight)
      self.Right = ARight
      self.Width = self.Right-self.Left
      self.WidthDiv2 = self.Width / 2                          
   end
   
   function self.SetBottom(ABottom)
      self.Bottom = ABottom
      self.Height = self.Bottom-self.Top
      self.HeightDiv2 = self.Height / 2                     
   end
   
   function self.SetLeftTop(ALeft, ATop)
      self.Left = ALeft
      self.Top = ATop      
      self.Width = self.Right-self.Left
      self.Height = self.Bottom-self.Top
      self.WidthDiv2 = self.Width / 2
      self.HeightDiv2 = self.Height / 2                   
   end
   
   function self.SetRightBottom(ARight, ABottom)
      self.Right = ARight
      self.Bottom = ABottom       
      self.Width = self.Right-self.Left
      self.Height = self.Bottom-self.Top
      self.WidthDiv2 = self.Width / 2
      self.HeightDiv2 = self.Height / 2
   end
      
   function self.SetWidth(AWidth)      
      self.Width = AWidth
      self.Right = self.Left + self.Width
      self.WidthDiv2 = self.Width / 2   
   end
   
   function self.SetHeight(AHeight)      
      self.Height = AHeight
      self.Bottom = self.Top + self.Height
      self.HeightDiv2 = self.Height / 2            
   end
      
   function self.SetWidthHeight(AWidth,AHeight)      
      self.Width = AWidth
      self.Height = AHeight
      self.Right = self.Left + self.Width
      self.Bottom = self.Top + self.Height
      self.WidthDiv2 = self.Width / 2
      self.HeightDiv2 = self.Height / 2      
   end
   
   function self.SetCaption(ACaption)
      self.Caption = ACaption
      
      self.CaptionWidth = WindowTextWidth(self.Window.MushWindow, self.Font, self.Caption)  -- width of text  (270)
      self.CaptionHeight = WindowFontInfo(self.Window.MushWindow, self.Font, 1)   -- height of the font  (46)
      self.CaptionWidthDiv2 = self.CaptionWidth / 2
      self.CaptionHeightDiv2 = self.CaptionHeight / 2
      
      self.Render()                 
   end  
       
   function self.MouseMove(AMouseX, AMouseY)
      
      --world.Note(self.Caption .. "MouseMoveXY = "..AMouseX..":"..AMouseY)
      
      if self.OnMouseMove ~= nil then
         self.OnMouseMove(AMouseX, AMouseY)
      end
   
   end
      
   function self.MouseButton(AMouseX, AMouseY, Button, State)
   
           
     
           
      --world.Note(self.Caption .. "MouseDownXY = "..AMouseX..":"..AMouseY)
      UIWidgetFocused = self
            
      if self.OnMouseButton ~= nil then
         self.OnMouseButton(AMouseX, AMouseY, Button, State)
      end
   end
   
   function self.MouseWheel(AMouseX, AMouseY, AWheelDelta)
   
   end
   
   function self.Keyboard(AChar, State)
   
   end   
   
   function self.Render()
              
      self.Window.RectColour(self.ColourBackground)       
      self.Window.Rect(self.Left,self.Top,self.Right,self.Bottom)  
        
   end     
          
          
   -----------------------------------------------------------------------------
   --Constructor                                                     Constructor
   -----------------------------------------------------------------------------
                       
   self.Hotspot = "WidgetHotSpot" .. AWindow.id ..":"..self.id           
   result = WindowAddHotspot(AWindow.MushWindow, self.Hotspot, 
   self.Left, self.Top, self.Right, self.Bottom,   
   "WidgetHotspotMouseOver", "WidgetHotspotCancelMouseOver", "WidgetHotspotMouseDown", "WidgetHotspotCancelMouseDown", "WidgetHotspotMouseUp", "", 0, 0)   
   --result = WindowDragHandler(AWindow.MushWindow, self.HotSpot, "UIWindowMapMouseDragMove", "UIWindowMapMouseDragEnd", 0)    
   --result = WindowScrollwheelHandler(AWindow.MushWindow, self.HotSpot, "UIWindowMapMouseWheel")
   
   UIWidgets[self.Hotspot] = self
                     
   return self   
end

function WidgetHotspotMouseOver(flags, hotspot_id)
   
   local AWidget = UIWidgets[hotspot_id]
   
   local MouseX = (WindowInfo(AWidget.Window.MushWindow, 14)+AWidget.Window.Left)-- - AWidget.Left  -- where mouse is relative to output window (X)
   local MouseY = (WindowInfo(AWidget.Window.MushWindow, 15)+AWidget.Window.Top)-- - AWidget.Top -- where mouse is relative to output window (Y)
   
   AWidget.IsHovering = true
   
   AWidget.MouseMove(MouseX, MouseY)
   
   AWidget.Render()
   Redraw()
   
   return 0 -- needed for some languages   
end -- mouseover

function WidgetHotspotCancelMouseOver(flags, hotspot_id)
   
   local AWidget = UIWidgets[hotspot_id]   
   AWidget.IsHovering = false
      
   AWidget.Render()
   Redraw()
              
   return 0 -- needed for some languages   
end -- mouseover

function WidgetHotspotMouseDown(flags, hotspot_id)
   
   local AWidget = UIWidgets[hotspot_id]
    
   local MouseX = (WindowInfo(AWidget.Window.MushWindow, 14)+AWidget.Window.Left)-- - AWidget.Left  -- where mouse is relative to output window (X)
   local MouseY = (WindowInfo(AWidget.Window.MushWindow, 15)+AWidget.Window.Top)-- - AWidget.Top -- where mouse is relative to output window (Y)
    
   AWidget.IsHovering = true
      
   AWidget.MouseButton(MouseX,MouseY,1,1)
      
   AWidget.Render()
   Redraw()
         

   return 0 -- needed for some languages   
end -- mouseover


function WidgetHotspotCancelMouseDown(flags, hotspot_id)
      

   return 0 -- needed for some languages   
end -- mouseover


function WidgetHotspotMouseUp(flags, hotspot_id)
      

   return 0 -- needed for some languages   
end -- mouseover


