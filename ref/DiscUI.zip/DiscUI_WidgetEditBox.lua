--------------------------------------------------------------------------------
--//DiscUI Widget Editbox 
--------------------------------------------------------------------------------

function UIWidgetEditboxCreate(AWindow, AWidgetLeft, AWidgetTop, AWidgetRight, AWidgetBottom)
   
    local self = UIWidgetCreate(AWindow, AWidgetLeft, AWidgetTop, AWidgetRight, AWidgetBottom)
          
   --overrides
   self.WidgetType = UIWidget_Editbox
   self.WidgetTypeName = "WidgetEditbox"
   self.SetCaption("")   
   self.RenderParent = self.Render
   self.ColourBackground = 0x363636
   self.Font = self.Window.FontSmall   
   --additions
   self.BorderWidth = 2
   self.CursorPosition = 1
   --callbacks         

      
   --additions    
   
   self.ParentKeyboard = self.Keyboard   
   function self.Keyboard(AChar, AState)
      local CLeft = string.sub(self.Caption,1,self.CursorPosition-1)
      local CRight = string.sub(self.Caption,self.CursorPosition)
                        
      if AChar == "BKSPACE" then                           
         if self.Caption ~= "" then            
            CLeft = string.sub(CLeft,1,#CLeft-1)            
            self.CursorPosition = self.CursorPosition - 1
            if self.CursorPosition < 1 then self.CursorPosition = 1 end            
            self.SetCaption(CLeft..CRight)
         end                         
      elseif AChar == "DELETE" then
            CRight = string.sub(CRight,2,#CRight)                                    
            self.SetCaption(CLeft..CRight)
      elseif AChar == "LEFT" then
         if self.CursorPosition > 1 then
            self.CursorPosition = self.CursorPosition - 1         
         end
      elseif AChar == "RIGHT" then
         if self.CursorPosition <= #self.Caption then
            self.CursorPosition = self.CursorPosition + 1         
         end
      elseif AChar == "HOME" then
         self.CursorPosition = 1
      elseif AChar == "END" then
         self.CursorPosition = #self.Caption+1            
      else --Insert Char
            
         
         self.CursorPosition = self.CursorPosition + 1
         self.SetCaption(CLeft .. AChar ..CRight)
         
                
      end 
		        
      --Note("EditboxKey : "..AChar)
      
      
      self.Render()
      Repaint()
   end
      
   self.ParentMouseButton = self.MouseButton
   function self.MouseButton(AMouseX, AMouseY, Button, State)   
      self.ParentMouseButton(AMouseX, AMouseY, Button, State)
      UIMushCaptureKeyboard(true)
      
   end
      
   function self.Render()   
               
      --don't render default widget rect
      --self.RenderParent()  

      --Render Background
      --if self.IsHovering == true then
      --   self.Window.RectColour(self.ColourBackgroundHovering)
      --else
         self.Window.RectColour(self.ColourBackground)
      --end            
      self.Window.Rect(self.Left,self.Top,self.Right,self.Bottom)
                       
      local APosX = self.Left  + self.BorderWidth -- (self.WidthDiv2 - self.CaptionWidthDiv2)
      local APosY = self.Top + (self.HeightDiv2 - self.CaptionHeightDiv2)
            
      --Render Text
      self.Window.TextColour(self.ColourFont)
      self.Window.Text(self.Caption, self.Font, APosX, APosY, APosX + self.CaptionWidth, APosY + self.CaptionHeight)
      
      --Render Cursor   
      local TextLeft = ""
      local TextLeftWidth = 0
      TextLeft = string.sub(self.Caption,1,self.CursorPosition-1)            
      TextLeftWidth = WindowTextWidth(self.Window.MushWindow,  self.Font, TextLeft)+self.BorderWidth  -- width of text  (270)
      self.Window.LineColour(0xffffff)
      self.Window.Line(self.Left+TextLeftWidth,self.Top,self.Left+TextLeftWidth,self.Bottom)
                        
      --Render outline
      self.Window.RectColour(0x939393)
      self.Window.RectOutline(self.Left,self.Top,self.Right,self.Bottom)                      
   end
   
   
   --Setup Editbox
   
   
               
   return self      
end