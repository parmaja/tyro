--------------------------------------------------------------------------------
--//DiscUI Widget Memo 
--------------------------------------------------------------------------------

function UIWidgetMemoCreate(AWindow, AWidgetLeft, AWidgetTop, AWidgetRight, AWidgetBottom)
   
    local self = UIWidgetCreate(AWindow, AWidgetLeft, AWidgetTop, AWidgetRight, AWidgetBottom)
          
   --overrides
   self.WidgetType = UIWidget_Memo
   self.WidgetTypeName = "WidgetMemo"
         
   self.ColourBackground = 0x101010
   self.Font = AWindow.FontSmall
   
                     
   self.ScrollX = 0
   self.ScrollY = 0
   self.BorderWidth = 2   
   self.LineHeight = 15   
   self.Lines = {}
   
      
   
   function self.LineAdd(ALine)
      self.Lines[#self.Lines+1] = ALine  
      if (#self.Lines * self.LineHeight) > self.Height then
         self.ScrollX = self.ScrollX + self.LineHeight
      end      
   end
      
   function self.LinesClear()
      self.Lines = {}
   end
   
   
   self.RenderParent = self.Render  ----override   
   function self.Render()                 
      self.RenderParent()  

      --Render Background      
      self.Window.RectColour(self.ColourBackground)                 
      self.Window.Rect(self.Left,self.Top,self.Right,self.Bottom)
                                        
      --Render Lines
      self.Window.TextColour(self.ColourFont)
      for I,Line in ipairs(self.Lines) do      
         self.Window.Text(Line, self.Font, self.Left+self.BorderWidth, self.Top+self.BorderWidth+((I-1)*self.LineHeight), self.Right-self.BorderWidth, self.Top+self.BorderWidth+((I-1)*self.LineHeight)+self.LineHeight)
      end      
      --Render outline
      self.Window.RectColour(0x939393)
      self.Window.RectOutline(self.Left,self.Top,self.Right,self.Bottom)                      
   end
   
   
   --Setup Memo
   
   
               
   return self      
end