--------------------------------------------------------------------------------
--//DiscUI Image
--------------------------------------------------------------------------------
local UIImageCounter = 0
local UIImages = {} 

local FWindowDrawImage = WindowDrawImage
local FWindowBlendImage = WindowBlendImage    
         
function UIImageCreate(AOwner)
   --create self instance
   local self = {}
   self.id = UIImageCounter
   UIImageCounter = UIImageCounter + 1
          
   -----------------------------------------------------------------------------
   --Private                                                             Private
   -----------------------------------------------------------------------------
           
   local FImageColour = 0x222222
   
   -----------------------------------------------------------------------------
   --Public                                                               Public
   -----------------------------------------------------------------------------   
   --               
   self.MushImage = "UIImage"..self.id
   self.ImageOwner = AImageOwner   
   self.Width = AImageSource.Width
   self.Height = AImageSource.Height
   self.Scale = 1.0   
   self.RegionPositionX = 0
   self.RegionPositionY = 0
   
   -----------------------------------------------------------------------------
   --Constructor                                                     Constructor
   -----------------------------------------------------------------------------  
     
   --insert reference into Image collection   
   table.insert(UIImages,self)   
   return self      
end