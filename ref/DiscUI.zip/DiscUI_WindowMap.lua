--------------------------------------------------------------------------------
--//DiscUI Map Window Variables
--------------------------------------------------------------------------------

----local references for optimization
local math_floor = math.floor
local math_max = math.max
local string_byte = string.byte

UIWindowMapBorderWidth = 5

UIWindowMap = nil

UIWindowMapUnitSize = 15

UIWindowMapDragFlag = false
UIWindowMapMouseDownX = 0
UIWindowMapMouseDownY = 0
UIWindowMapDragStartX = 0
UIWindowMapDragStartY = 0
UiWindowMapDragCameraStartX = 0
UiWindowMapDragCameraStartY = 0
   

local AViewportCenterH = 0
local AViewportCenterV = 0
local AViewportLeft = 0
local AViewportTop = 0
local AViewportRight = 0
local AViewportBottom = 0

local FRoomRenderTarget = nil
local FRoomRenderMushWindow = ""
local FRoomRenderColourRoom = 0x000000
local FRoomRenderColourLineChar = 0x000000
local FRoomRenderColourLine = 0
local FRoomRenderLineWidth = 5
local FRoomRenderPlayerMinRadius = 4  
local FRoomRenderPlayerRadius = 4
local FRoomRenderPlayerOutlineRadius = 4
local FRoomRenderRoomOutlineRadius = 4
local FRoomRenderLeft = 0
local FRoomRenderTop = 0
local FRoomRenderRight = 0
local FRoomRenderBottom = 0


local APosLeft = 0
local APosTop = 0
local APosRight = 0
local APosBottom = 0



local AX = 0
local AY = 0
 
local ASectorX = 0
local ASectorY = 0


local ASector = {}
local ASectorPosX = 0
local ASectorPosY = 0
local AStr = ""
local AStrColour = ""
local AChar = ""
local ACharColour = ""

--------------------------------------------------------------------------------
--//DiscUI Map Window Functions
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
function UIWindowMapViewToCell(AViewX,AViewY)
   local CellWidthReal = 0
   local CellHeightReal = 0
      
   if UIWindowMap.SurfaceMode then   
      CellWidthReal = UIWindowMap.Surface.Width / (UIWindowMap.CellSize)
      CellHeightReal = UIWindowMap.Surface.Height / (UIWindowMap.CellSize)   
   else
      CellWidthReal = UIWindowMap.ViewPort.Width / (UIWindowMap.CellSize)
      CellHeightReal = UIWindowMap.ViewPort.Height / (UIWindowMap.CellSize)   
   end  
   local CellLeftReal = UIWindowMap.CameraPositionX - (CellWidthReal / 2)
   local CellTopReal = UIWindowMap.CameraPositionY - (CellHeightReal / 2)
   
   local MouseX = AViewX --WindowInfo(UIWindowMap.MushWindow, 14) - UIWindowMap.ViewPort.Left  -- where mouse is relative to output window (X)
   local MouseY = AViewY --WindowInfo(UIWindowMap.MushWindow, 15) - UIWindowMap.ViewPort.Top -- where mouse is relative to output window (Y)
   
   --translate into cell space
   if UIWindowMap.SurfaceMode then  
   MouseX = (MouseX / UIWindowMap.CellSize)  / UIWindowMap.SurfaceRatio 
   MouseY = (MouseY / UIWindowMap.CellSize)  / UIWindowMap.SurfaceRatio
   else
      MouseX = (MouseX / UIWindowMap.CellSize) 
      MouseY = (MouseY / UIWindowMap.CellSize)   
   end
   
   MouseX = CellLeftReal + MouseX
   MouseY = CellTopReal + MouseY
   
   return MouseX, MouseY    
end

--------------------------------------------------------------------------------
function UIWindowMapCellToView(ACellX,ACellY)
   local APosX = ((ACellX-UIWindowMap.CameraPositionX) * UIWindowMap.CellSize) + UIWindowMap.ViewPort.CenterH
   local APosY = ((ACellY-UIWindowMap.CameraPositionY) * UIWindowMap.CellSize) + UIWindowMap.ViewPort.CenterV
  return APosX, APosY
end

--------------------------------------------------------------------------------
function UIWindowMapCreate(AMapBuffer)                                           
   --Create Window
   UIWindowMap = UIWindowCreate("Map", 0, 0, UI_BarLeftWidth, 450, 4)   
   --UIWindowMap.SetHeight(450)
   
      
   UIWindowMap.PopupMenu = UIWindowPopupCreate("Map Popup")   
   UIWindowMap.PopupMenuEdit = UIWindowPopupCreate("Map Edit Popup")
   
   
   --Setup Viewport
   UIWindowMap.ViewPort = {}
   UIWindowMap.ViewPort.Left = UIWindowMapBorderWidth
   UIWindowMap.ViewPort.Top = UIWindowMap.TitleBarHeight + UIWindowMapBorderWidth
   UIWindowMap.ViewPort.Right = UIWindowMap.Width - UIWindowMapBorderWidth
   UIWindowMap.ViewPort.Bottom = UIWindowMap.Height - UIWindowMapBorderWidth
   UIWindowMap.ViewPort.Width = UIWindowMap.ViewPort.Right - UIWindowMap.ViewPort.Left 
   UIWindowMap.ViewPort.Height = UIWindowMap.ViewPort.Bottom - UIWindowMap.ViewPort.Top        
   UIWindowMap.ViewPort.CenterH = UIWindowMap.ViewPort.Left + (UIWindowMap.ViewPort.Width / 2)
   UIWindowMap.ViewPort.CenterV = UIWindowMap.ViewPort.Top + (UIWindowMap.ViewPort.Height / 2)
   
   UIWindowMap.ColourMapBackground = 0x000000
   
   --Create Map Buffer
   UIWindowMap.MapBuffer = AMapBuffer
   
   --Create Map Render Buffer
   UIWindowMap.MapRenderGrid = UIMapRenderGridCreate(UIWindowMap, 4)
   
   --Create Rendering Surface
   UIWindowMap.SurfaceRatio = 1.0
   UIWindowMap.Surface = UISurfaceCreate(UIWindowMap,UIWindowMap.ViewPort.Width/UIWindowMap.SurfaceRatio,UIWindowMap.ViewPort.Height/UIWindowMap.SurfaceRatio)
   UIWindowMap.SurfaceBuffer = UISurfaceCreate(UIWindowMap,256,256)
      
   --Set surface or direct rendermode   
   UIWindowMap.SurfaceMode = true          
                       
   UIWindowMap.CellSize = UIWindowMapUnitSize 
   UIWindowMap.CellSizeDiv2 = UIWindowMap.CellSize / 2
   UIWindowMap.CellSizeDiv4 = UIWindowMap.CellSize / 4
   UIWindowMap.CellSizeDiv5 = UIWindowMap.CellSize / 5
   
   UIWindowMap.CameraPositionX = UIWindowMap.MapBuffer.PlayerPositionX --+ 160
   UIWindowMap.CameraPositionY = UIWindowMap.MapBuffer.PlayerPositionY
   if UIWindowMap.SurfaceMode then
      UIWindowMap.CameraScale = 0.3 / UIWindowMap.SurfaceRatio
   else
      UIWindowMap.CameraScale = 1--0.125
   end
   
   
   UIWindowMap.CameraPositionX, UIWindowMap.CameraPositionY = AMapBuffer.RegionGetWorldPos(AMapBuffer.CurrentRegion, AMapBuffer.CurrentRoom.RoomPositionX, AMapBuffer.CurrentRoom.RoomPositionY, AMapBuffer.CurrentRoom.RoomPositionZ)
   UIWindowMap.CameraScale = AMapBuffer.RegionGetWorldScale(AMapBuffer.CurrentRegion, UIWindowMap.CameraScale)
   
   
   UIWindowMap.HoveringCellX = 0
   UIWindowMap.HoveringCellY = 0
   UIWindowMap.SelectedCellX = 0
   UIWindowMap.SelectedCellY = 0
   
   UIWindowMap.HoveringRoom = nil
   UIWindowMap.SelectedRoom = nil   
   UIWindowMap.SelectedRoom = nil
   
   UIWindowMap.DragFlag = false
   
   local CellWidth = 0
   local CellHeight = 0   
      
   if UIWindowMap.SurfaceMode then
      CellWidth = math_floor(UIWindowMap.Surface.Width / (UIWindowMap.CellSize*UIWindowMap.CameraScale))
      CellHeight = math_floor(UIWindowMap.Surface.Height / (UIWindowMap.CellSize*UIWindowMap.CameraScale))   
      
   else
      CellWidth = math_floor(UIWindowMap.ViewPort.Width / (UIWindowMap.CellSize*UIWindowMap.CameraScale))
      CellHeight = math_floor(UIWindowMap.ViewPort.Height / (UIWindowMap.CellSize*UIWindowMap.CameraScale))   
   end
            
   local CellLeft = math_floor(UIWindowMap.CameraPositionX - (CellWidth / 2))
   local CellTop = math_floor(UIWindowMap.CameraPositionY - (CellHeight / 2))   
   
   
   --long WindowAddHotspot(BSTR WindowName, BSTR HotspotId, long Left, long Top, long Right, long Bottom, BSTR MouseOver, BSTR CancelMouseOver, BSTR MouseDown, BSTR CancelMouseDown, BSTR MouseUp, BSTR TooltipText, long Cursor, long Flags);
   
   UIWindowMap.HotSpotMap = "HotSpotMap"
   result = WindowAddHotspot(UIWindowMap.MushWindow, UIWindowMap.HotSpotMap, 
      UIWindowMap.ViewPort.Left,UIWindowMap.ViewPort.Top,UIWindowMap.ViewPort.Right,UIWindowMap.ViewPort.Bottom,   
      "UIWindowMapMouseOver", "", "UIWindowMapMouseDown", "UIWindowMapMouseCancelDown", "UIWindowMapMouseUp", "", 3, 0x01)   
   result = WindowDragHandler(UIWindowMap.MushWindow, UIWindowMap.HotSpotMap, "UIWindowMapMouseDragMove", "UIWindowMapMouseDragEnd", 0)    
   result = WindowScrollwheelHandler(UIWindowMap.MushWindow, UIWindowMap.HotSpotMap, "UIWindowMapMouseWheel")
        
   UIWindowMap.CellSize = (UIWindowMapUnitSize*UIWindowMap.CameraScale) 
   UIWindowMap.CellSizeDiv2 = UIWindowMap.CellSize / 2
   UIWindowMap.CellSizeDiv4 = UIWindowMap.CellSize / 4
   UIWindowMap.CellSizeDiv5 = UIWindowMap.CellSize / 5
             
   UIWindowMap.MapBuffer.SetView(CellLeft, CellTop, CellLeft+CellWidth, CellTop+CellHeight)
   
   
   --Camera Animation
   UIWindowMap.CameraAnimateFlag = false
   UIWindowMap.CameraAnimateStartPositionX = 0
   UIWindowMap.CameraAnimateStartPositionY = 0
   UIWindowMap.CameraAnimateEndPositionX = 0
   UIWindowMap.CameraAnimateEndPositionY = 0
   UIWindowMap.CameraAnimateLength = 2.0
   UIWindowMap.CameraAnimateStartTimeStamp = 0
      
   function UIWindowMap.CameraAnimateTo(APositionX, APositionY, AAnimateLength)
      UIWindowMap.CameraAnimateFlag = true      
      UIWindowMap.CameraAnimateStartPositionX = UIWindowMap.CameraPositionX
      UIWindowMap.CameraAnimateStartPositionY = UIWindowMap.CameraPositionY   
      UIWindowMap.CameraAnimateEndPositionX = APositionX
      UIWindowMap.CameraAnimateEndPositionY = APositionY  
      UIWindowMap.CameraAnimateLength = AAnimateLength
      UIWindowMap.CameraAnimateStartTimeStamp = UIMushGetTime()     
      --UIWindowMap.Render()     
   end
           

   -- Assign Callbacks (or is it a copy of the function? who cares?)
   UIWindowMap.OnRender = UIWindowMapRender      
   UIWindowMap.Render()            
   
       
   UIWindowMap.Show()
   
   --Repaint() --force repaint
   Redraw() --schedule redraw              
end


--------------------------------------------------------------------------------

--[[
0x01 - Shift key down
0x02 - Control key down
0x04 - Alt key down
0x10 - LH mouse
0x20 - RH mouse
0x40 - double-click
0x80 - mouse-over not first time
0x100 - scroll wheel scrolled (towards you)
0x200 - middle mouse
--]]


function UIWindowMapMouseDown(flags, hotspot_id)
   --
   
   local MouseX = WindowInfo(UIWindowMap.MushWindow, 14) -- where mouse is relative to output window (X)
   local MouseY = WindowInfo(UIWindowMap.MushWindow, 15) -- where mouse is relative to output window (Y)   
   
   if UIWindowMap.SurfaceMode then  
      MouseX = MouseX / UIWindowMap.SurfaceRatio  
      MouseY = MouseY / UIWindowMap.SurfaceRatio   
   end
   
   UIWindowMapMouseDownX = MouseX
   UIWindowMapMouseDownY = MouseY  
   
   local MouseViewX = MouseX - UIWindowMap.ViewPort.Left
   local MouseViewY = MouseY - UIWindowMap.ViewPort.Top
   
   local MouseCellX = MouseViewX
   local MouseCellY = MouseViewY
   
   local CellWidthReal = 0
   local CellHeightReal = 0     
   if UIWindowMap.SurfaceMode then
      CellWidthReal = UIWindowMap.Surface.Width / (UIWindowMap.CellSize)
      CellHeightReal = UIWindowMap.Surface.Height / (UIWindowMap.CellSize)
   else
      CellWidthReal = UIWindowMap.ViewPort.Width / (UIWindowMap.CellSize)
      CellHeightReal = UIWindowMap.ViewPort.Height / (UIWindowMap.CellSize)   
   end   
   
   local CellLeftReal = UIWindowMap.CameraPositionX - (CellWidthReal / 2)
   local CellTopReal = UIWindowMap.CameraPositionY - (CellHeightReal / 2)
   
   UIWindowMap.ViewMouseX = MouseViewX
   UIWindowMap.ViewMouseY = MouseViewY
   
   --translate into cell space
    if UIWindowMap.SurfaceMode then  
      MouseCellX = (MouseCellX / UIWindowMap.CellSize) / UIWindowMap.SurfaceRatio  
      MouseCellY = (MouseCellY / UIWindowMap.CellSize) / UIWindowMap.SurfaceRatio
   else
      MouseCellX = (MouseCellX / UIWindowMap.CellSize)  
      MouseCellY = (MouseCellY / UIWindowMap.CellSize)   
   end 
   
   MouseCellX = CellLeftReal + MouseCellX
   MouseCellY = CellTopReal + MouseCellY
   

   UIWindowMap.CellMouseX = MouseCellX
   UIWindowMap.CellMouseY = MouseCellY
   
   UIWindowMap.HoveringCellX = round(MouseCellX) 
   UIWindowMap.HoveringCellY = round(MouseCellY) 
   
   
      
   UIWindowMap.MapBuffer.HoveringRoom = UIWindowMap.MapBuffer.RoomGetXYZNearest(UIWindowMap.MapBuffer.CurrentRegion, MouseCellX, MouseCellY, 0)
   
   
   --if bit.band(flags, 0x10) ~= 0 then
      UIWindowMap.MapBuffer.SelectedRoom = UIWindowMap.MapBuffer.HoveringRoom
   --end     
   
    
   UIWindowMap.Render()              
   Repaint() --force repaint
   --Redraw() --schedule redraw
end

--------------------------------------------------------------------------------
function UIWindowMapMouseCancelDown(flags, hotspot_id)
   --world.Note("MouseDownCancel")
end

--------------------------------------------------------------------------------
function UIWindowMapMouseUp(flags, hotspot_id)
      
   if not UIWindowMapDragFlag then
         
      local MouseX = WindowInfo(UIWindowMap.MushWindow, 14) -- where mouse is relative to output window (X)
      local MouseY = WindowInfo(UIWindowMap.MushWindow, 15) -- where mouse is relative to output window (Y)
    
      local MouseViewX = MouseX - UIWindowMap.ViewPort.Left
      local MouseViewY = MouseY - UIWindowMap.ViewPort.Top
      
      local MouseCellX = MouseViewX
      local MouseCellY = MouseViewY
      
      local CellWidthReal = 0
      local CellHeightReal = 0            
      if UIWindowMap.SurfaceMode then
         CellWidthReal = UIWindowMap.Surface.Width / (UIWindowMap.CellSize)
         CellHeightReal = UIWindowMap.Surface.Height / (UIWindowMap.CellSize)   
      else
         CellWidthReal = UIWindowMap.ViewPort.Width / (UIWindowMap.CellSize)
         CellHeightReal = UIWindowMap.ViewPort.Height / (UIWindowMap.CellSize)   
      end              
      local CellLeftReal = UIWindowMap.CameraPositionX - (CellWidthReal / 2)
      local CellTopReal = UIWindowMap.CameraPositionY - (CellHeightReal / 2)
      
      UIWindowMap.ViewMouseX = MouseViewX
      UIWindowMap.ViewMouseY = MouseViewY
      
      --translate into cell space
      if UIWindowMap.SurfaceMode then
         MouseCellX = (MouseCellX / UIWindowMap.CellSize)/ UIWindowMap.SurfaceRatio  
         MouseCellY = (MouseCellY / UIWindowMap.CellSize)/ UIWindowMap.SurfaceRatio
      else
         MouseCellX = (MouseCellX / UIWindowMap.CellSize)  
         MouseCellY = (MouseCellY / UIWindowMap.CellSize)
      end 
       
      
      MouseCellX = CellLeftReal + MouseCellX
      MouseCellY = CellTopReal + MouseCellY
      
   
      UIWindowMap.CellMouseX = MouseCellX  
      UIWindowMap.CellMouseY = MouseCellY 
      
      UIWindowMap.HoveringCellX = round(MouseCellX) 
      UIWindowMap.HoveringCellY = round(MouseCellY) 
      
      --world.Note("MouseUp")
      
      
      UIWindowMap.Render()              
      Repaint() --force repaint
      --Redraw() --schedule redraw
      
   
      if (UIWindowMapMouseDownX == MouseX) and (UIWindowMapMouseDownY == MouseY) then   
         if bit.band(flags, 0x20) ~= 0 then
            -- Right MouseUp        
            --UIWindowMap.PopupMenu.Popup(MouseX,MouseY)          
            menustring = "Set Path Start|Set Path End|Path To Here|Set Position"  
            local SResult = WindowMenu (UIWindowMap.MushWindow,
               MouseX,
               MouseY,
               menustring) -- content
           
            if SResult == "Set Path Start" then
               UIWindowMap.MapBuffer.PathRoomStart = UIWindowMap.MapBuffer.SelectedRoom
               if UIWindowMap.MapBuffer.PathRoomStart and UIWindowMap.MapBuffer.PathRoomEnd then
                  UIWindowMap.MapBuffer.PathFind(UIWindowMap.MapBuffer.PathRoomStart,UIWindowMap.MapBuffer.PathRoomEnd)
               end                 
            --UIWindowMap.MapBuffer.PathRoomStart = UIWindowMap.MapBuffer.RoomGetXYZ(UIWindowMap.MapBuffer.CurrentRegion,0,0,0)
           
            elseif SResult == "Set Path End" then
               UIWindowMap.MapBuffer.PathRoomEnd = UIWindowMap.MapBuffer.SelectedRoom
               if UIWindowMap.MapBuffer.PathRoomStart and UIWindowMap.MapBuffer.PathRoomEnd then
                  UIWindowMap.MapBuffer.PathFind(UIWindowMap.MapBuffer.PathRoomStart,UIWindowMap.MapBuffer.PathRoomEnd)
               end
            elseif SResult == "Path To Here" then
               UIWindowMap.MapBuffer.PathRoomStart = UIWindowMap.MapBuffer.CurrentRoom
               UIWindowMap.MapBuffer.PathRoomEnd = UIWindowMap.MapBuffer.SelectedRoom
               if UIWindowMap.MapBuffer.PathRoomStart and UIWindowMap.MapBuffer.PathRoomEnd then
                  UIWindowMap.MapBuffer.PathFind(UIWindowMap.MapBuffer.PathRoomStart,UIWindowMap.MapBuffer.PathRoomEnd)
               end
            elseif SResult == "Set Position" then
            
            
               if UIWindowMap.MapBuffer.SelectedRoom then
                  if (UIWindowMap.MapBuffer.SelectedRoom.RoomPositionX == UIWindowMap.HoveringCellX) and
                  (UIWindowMap.MapBuffer.SelectedRoom.RoomPositionY == UIWindowMap.HoveringCellY) then
                     Note("SETTING POSITION TO SELECTED ROOM")
                     UIWindowMap.MapBuffer.CurrentRoom = UIWindowMap.MapBuffer.SelectedRoom   
                     UIWindowMap.MapBuffer.PreviousRoom = UIWindowMap.MapBuffer.SelectedRoom
                     UIWindowMap.MapBuffer.PlayerPositionX = UIWindowMap.MapBuffer.SelectedRoom.RoomPositionX
                     UIWindowMap.MapBuffer.PlayerPositionY = UIWindowMap.MapBuffer.SelectedRoom.RoomPositionY                  
                     UIWindowMap.MapBuffer.CurrentSector = UIWindowMap.MapBuffer.SelectedRoom.Sector
                  end                                                        
               end
              
               if UIWindowMap.MapBuffer.SelectedRoom then
                  if (UIWindowMap.MapBuffer.SelectedRoom.RoomPositionX ~= UIWindowMap.HoveringCellX) and
                  (UIWindowMap.MapBuffer.SelectedRoom.RoomPositionY ~= UIWindowMap.HoveringCellY) then
                     Note("CREATING NEW ROOM AND SETTING POSITION")                  
                      --get potential new sector         
                     local ASectorX = math_floor((UIWindowMap.HoveringCellX) / UIMapSectorSize)
                     local ASectorY = math_floor((UIWindowMap.HoveringCellY) / UIMapSectorSize)                        
                     local ASectorZ = 0          
                     NewSector = UIWindowMap.MapBuffer.SectorGetXYZ(UIWindowMap.MapBuffer.CurrentRegion, ASectorX, ASectorY, ASectorZ)          
                     --if sector doesn't exist, create it      
                     if not NewSector then
                        NewSector = UIWindowMap.MapBuffer.SectorCreate(UIWindowMap.MapBuffer.CurrentRegion, ASectorX, ASectorY, ASectorZ)
                     end     
                     UIWindowMap.MapBuffer.CurrentSector = NewSector
                                                   
                     UIWindowMap.MapBuffer.CurrentRoom = UIWindowMap.MapBuffer.RoomCreate(UIWindowMap.MapBuffer.CurrentRegion,UIWindowMap.MapBuffer.CurrentSector,UIWindowMap.HoveringCellX, UIWindowMap.HoveringCellY)                     
                     UIWindowMap.MapBuffer.PreviousRoom = UIWindowMap.MapBuffer.CurrentRoom
                     UIWindowMap.MapBuffer.PlayerPositionX = UIWindowMap.HoveringCellX --  UIWindowMap.MapBuffer.CurrentRoom.RoomPositionX
                     UIWindowMap.MapBuffer.PlayerPositionY = UIWindowMap.HoveringCellY --  UIWindowMap.MapBuffer.CurrentRoom.RoomPositionY
                  end                  
               end
            end                   
         end
      end
       
   end   
   
   UIWindowMapDragFlag = false                                
end

--------------------------------------------------------------------------------
function UIWindowMapMouseOver(flags, hotspot_id)
   if not UIWindowMap then return end
   
   local CellWidthReal = 0
   local CellHeightReal = 0            
   if UIWindowMap.SurfaceMode then
      CellWidthReal = UIWindowMap.Surface.Width / (UIWindowMap.CellSize)
      CellHeightReal = UIWindowMap.Surface.Height / (UIWindowMap.CellSize)   
   else
      CellWidthReal = UIWindowMap.ViewPort.Width / (UIWindowMap.CellSize)
      CellHeightReal = UIWindowMap.ViewPort.Height / (UIWindowMap.CellSize)   
   end                    
   local CellLeftReal = UIWindowMap.CameraPositionX - (CellWidthReal / 2)
   local CellTopReal = UIWindowMap.CameraPositionY - (CellHeightReal / 2)
   
   local MouseX = WindowInfo(UIWindowMap.MushWindow, 14) - UIWindowMap.ViewPort.Left  -- where mouse is relative to output window (X)
   local MouseY = WindowInfo(UIWindowMap.MushWindow, 15) - UIWindowMap.ViewPort.Top -- where mouse is relative to output window (Y)
   
   UIWindowMap.ViewMouseX = MouseX
   UIWindowMap.ViewMouseY = MouseY
   
   --translate into cell space
   if UIWindowMap.SurfaceMode then
      MouseX = (MouseX / UIWindowMap.CellSize)/ UIWindowMap.SurfaceRatio 
      MouseY = (MouseY / UIWindowMap.CellSize)/ UIWindowMap.SurfaceRatio
   else
      MouseX = (MouseX / UIWindowMap.CellSize) 
      MouseY = (MouseY / UIWindowMap.CellSize)   
   end
   
   MouseX = CellLeftReal + MouseX
   MouseY = CellTopReal + MouseY
   
   UIWindowMap.CellMouseX = MouseX   
   UIWindowMap.CellMouseY = MouseY 
   
   UIWindowMap.HoveringCellX = round(MouseX) 
   UIWindowMap.HoveringCellY = round(MouseY) 
      
   UIWindowMap.MapBuffer.HoveringRoom = UIWindowMap.MapBuffer.RoomGetXYZNearest(UIWindowMap.MapBuffer.CurrentRegion, MouseX, MouseY, 0)
   --UIWindowMap.MapBuffer.HoveringRoom = UIWindowMap.MapBuffer.RoomGetXY(UIWindowMap.MapBuffer.CurrentRegion, UIWindowMap.HoveringCellX, UIWindowMap.HoveringCellY) 
   if UIWindowMap.MapBuffer.HoveringRoom then
      if #UIWindowMap.MapBuffer.HoveringRoom.RoomStreets > 0 then
         
         UIWindowMap.MapBuffer.HoveringStreet = UIWindowMap.MapBuffer.HoveringRoom.RoomStreets[1]
         
      else
         UIWindowMap.MapBuffer.HoveringStreet = nil
      end
   end
                        
   
   UIWindowMap.Render()   
   
   if UIWindowMapInfo.Render then
      UIWindowMapInfo.Render()
   end
               
   Repaint() --force repaint
   --Redraw() --schedule redraw
               
end

--------------------------------------------------------------------------------
function UIWindowMapMouseDragMove(flags, hotspot_id)

   --local MouseX, MouseY = UIWindowMapViewToCell(WindowInfo(UIWindowMap.MushWindow, 17),WindowInfo (UIWindowMap.MushWindow, 18))    

   local MouseX, MouseY = WindowInfo (UIWindowMap.MushWindow, 17), WindowInfo (UIWindowMap.MushWindow, 18)
   
   if UIWindowMap.SurfaceMode then  
      MouseX = MouseX / UIWindowMap.SurfaceRatio  
      MouseY = MouseY / UIWindowMap.SurfaceRatio   
   end
   
   if bit.band(flags, 0x20) ~= 0 then
   
    
                        
      if UIWindowMapDragFlag == false then
         UIWindowMapDragStartX = MouseX   
         UIWindowMapDragStartY = MouseY   
         UiWindowMapDragCameraStartX = UIWindowMap.CameraPositionX 
         UiWindowMapDragCameraStartY = UIWindowMap.CameraPositionY   
         UIWindowMapDragFlag = true   
      end
      
      
      UIWindowMap.CameraPositionX = (UiWindowMapDragCameraStartX - (MouseX-UIWindowMapDragStartX)/UIWindowMap.CellSize)
      UIWindowMap.CameraPositionY = (UiWindowMapDragCameraStartY - (MouseY-UIWindowMapDragStartY)/UIWindowMap.CellSize)
      
       
      local CellWidth = 0
      local CellHeight = 0            
      if UIWindowMap.SurfaceMode then
         CellWidth = math_floor(UIWindowMap.Surface.Width / (UIWindowMapUnitSize*UIWindowMap.CameraScale))
         CellHeight = math_floor(UIWindowMap.Surface.Height / (UIWindowMapUnitSize*UIWindowMap.CameraScale)) 
      else
         CellWidth = math_floor(UIWindowMap.ViewPort.Width / (UIWindowMapUnitSize*UIWindowMap.CameraScale))
         CellHeight = math_floor(UIWindowMap.ViewPort.Height / (UIWindowMapUnitSize*UIWindowMap.CameraScale))   
      end              
                           
      local CellLeft = math_floor(UIWindowMap.CameraPositionX - (CellWidth / 2))
      local CellTop = math_floor(UIWindowMap.CameraPositionY - (CellHeight / 2))
      local CellRight = CellLeft + CellWidth
      local CellBottom = CellTop + CellHeight  
         
      UIWindowMap.MapBuffer.SetView(CellLeft, CellTop, CellLeft+CellWidth, CellTop+CellHeight)    
        
      UIWindowMap.CellSize = (UIWindowMapUnitSize*UIWindowMap.CameraScale) 
      UIWindowMap.CellSizeDiv2 = UIWindowMap.CellSize / 2
      UIWindowMap.CellSizeDiv4 = UIWindowMap.CellSize / 4
      UIWindowMap.CellSizeDiv5 = UIWindowMap.CellSize / 5      
      
     
      UIWindowMap.Render()  
                
      Repaint() --force repaint
      --Redraw() --schedule redraw
   end
end

--------------------------------------------------------------------------------
function UIWindowMapMouseDragEnd(flags, hotspot_id)
   --world.Note("Drag END!")
   
   UIWindowMapDragFlag = false
  --print ("mouse drag release for " .. hotspot_id)
  --print ("released at position", WindowInfo (win, 17), WindowInfo (win, 18))
end -- dragrelease

--------------------------------------------------------------------------------
function UIWindowMapMouseWheel(flags, hotspot_id)
          
   --Get Cell Position Before Scale          
   local MouseCellX, MouseCellY = UIWindowMapViewToCell(UIWindowMap.ViewMouseX,UIWindowMap.ViewMouseY)           

   --The flags parameter is a bit mask as follows:
   --0x01 - Shift key down --0x02 - Control key down
   --0x04 - Alt key down --0x100
   if bit.band (flags, 0x100) ~= 0 then
   -- wheel scrolled down 
      UIWindowMap.CameraScale = UIWindowMap.CameraScale - (0.12*UIWindowMap.CameraScale) 
   else
   -- wheel scrolled up 
      UIWindowMap.CameraScale = UIWindowMap.CameraScale + (0.12*UIWindowMap.CameraScale) 
   end

   UIWindowMap.CellSize = (UIWindowMapUnitSize*UIWindowMap.CameraScale)
   UIWindowMap.CellSizeDiv2 = UIWindowMap.CellSize / 2
   UIWindowMap.CellSizeDiv4 = UIWindowMap.CellSize / 4
   UIWindowMap.CellSizeDiv5 = UIWindowMap.CellSize / 5
      
   
   --only shift camera position on zoom in 
   --if bit.band (flags, 0x100) == 0 then   
      --Get CellPosition After Scale
      local NewMouseCellX, NewMouseCellY = UIWindowMapViewToCell(UIWindowMap.ViewMouseX, UIWindowMap.ViewMouseY)   
      --Compute Vector between before and after                  
      local AX = ((NewMouseCellX) - (MouseCellX)) 
      local AY = ((NewMouseCellY) - (MouseCellY))             
      --offset camera positon to remain centered on cursor position     
      UIWindowMap.CameraPositionX = UIWindowMap.CameraPositionX - AX
      UIWindowMap.CameraPositionY = UIWindowMap.CameraPositionY - AY     
   --end
      
   local CellWidth = 0
   local CellHeight = 0            
   if UIWindowMap.SurfaceMode then
      CellWidth = math_floor(UIWindowMap.ViewPort.Width / (UIWindowMapUnitSize*UIWindowMap.CameraScale))
      CellHeight = math_floor(UIWindowMap.ViewPort.Height / (UIWindowMapUnitSize*UIWindowMap.CameraScale)) 
   else  
      CellWidth = math_floor(UIWindowMap.ViewPort.Width / (UIWindowMapUnitSize*UIWindowMap.CameraScale))
      CellHeight = math_floor(UIWindowMap.ViewPort.Height / (UIWindowMapUnitSize*UIWindowMap.CameraScale))   
   end           
   local CellLeft = math_floor(UIWindowMap.CameraPositionX - (CellWidth / 2))
   local CellTop = math_floor(UIWindowMap.CameraPositionY - (CellHeight / 2))
   local CellRight = CellLeft + CellWidth
   local CellBottom = CellTop + CellHeight  
      
   UIWindowMap.MapBuffer.SetView(CellLeft, CellTop, CellLeft+CellWidth, CellTop+CellHeight)    
   
        
   UIWindowMap.Render()
               
   Repaint() --force repaint
   --Redraw() --schedule redraw
return 0 -- needed for some languages
end

AnimNow = 0

--------------------------------------------------------------------------------
function UIWindowMapRender(ADelta)
   
   local TimeStamp = UIMushGetTime()
         
   if UIWindowMap.CameraAnimateFlag then         
      
         
         local AnimStamp = 0
         local FrameStamp = AnimStamp
          
      --while (AnimStamp-FrameStamp) < (0.01) do --OnPluginTick called 25 times a second so animate in between ticks
      
         --UIWindowMap.AnimNow = UIWindowMap.AnimNow + 0.02
         
         AnimStamp = UIMushGetTime() 
         
                             
         local Elapsed = AnimStamp-UIWindowMap.CameraAnimateStartTimeStamp      
         local Ratio = Elapsed/UIWindowMap.CameraAnimateLength   
              
         UIWindowMap.CameraPositionX = UIWindowMap.CameraAnimateStartPositionX + ((UIWindowMap.CameraAnimateEndPositionX-UIWindowMap.CameraAnimateStartPositionX)*Ratio)
         UIWindowMap.CameraPositionY = UIWindowMap.CameraAnimateStartPositionY + ((UIWindowMap.CameraAnimateEndPositionY-UIWindowMap.CameraAnimateStartPositionY)*Ratio)
         
         local CellWidth = 0
         local CellHeight = 0            
         if UIWindowMap.SurfaceMode then
            CellWidth = math_floor(UIWindowMap.Surface.Width / (UIWindowMapUnitSize*UIWindowMap.CameraScale))
            CellHeight = math_floor(UIWindowMap.Surface.Height / (UIWindowMapUnitSize*UIWindowMap.CameraScale)) 
         else
            CellWidth = math_floor(UIWindowMap.ViewPort.Width / (UIWindowMapUnitSize*UIWindowMap.CameraScale))
            CellHeight = math_floor(UIWindowMap.ViewPort.Height / (UIWindowMapUnitSize*UIWindowMap.CameraScale))   
         end              
                                    
         local CellLeft = math_floor(UIWindowMap.CameraPositionX - (CellWidth / 2))
         local CellTop = math_floor(UIWindowMap.CameraPositionY - (CellHeight / 2))
         local CellRight = CellLeft + CellWidth
         local CellBottom = CellTop + CellHeight           
         UIWindowMap.MapBuffer.SetView(CellLeft, CellTop, CellLeft+CellWidth, CellTop+CellHeight)            
         UIWindowMap.CellSize = (UIWindowMapUnitSize*UIWindowMap.CameraScale) 
         UIWindowMap.CellSizeDiv2 = UIWindowMap.CellSize / 2
         UIWindowMap.CellSizeDiv4 = UIWindowMap.CellSize / 4
         UIWindowMap.CellSizeDiv5 = UIWindowMap.CellSize / 5      
         
         
         if Elapsed > UIWindowMap.CameraAnimateLength then
            UIWindowMap.CameraAnimateFlag = false
         end
                           
   end
      
   
   if UIWindowMap.SurfaceMode then
      --Surface Render Mode
      AViewportCenterH = UIWindowMap.Surface.Width / 2
      AViewportCenterV = UIWindowMap.Surface.Height / 2        
      AViewportLeft = 0 -- - UIWindowMap.CellSize+1 --UIWindowMap.ViewPort.Left + UIWindowMap.CellSizeDiv2
      AViewportTop = 0 -- - UIWindowMap.CellSize+1 --UIWindowMap.ViewPort.Top + UIWindowMap.CellSizeDiv2
      AViewportRight = UIWindowMap.Surface.Width -- +UIWindowMap.CellSize+1 -- UIWindowMap.ViewPort.Right - UIWindowMap.CellSizeDiv2
      AViewportBottom = UIWindowMap.Surface.Height -- +UIWindowMap.CellSize+1  --UIWindowMap.ViewPort.Bottom - UIWindowMap.CellSizeDiv2  
      
       --Map Background   
      UIWindowMap.Surface.RectColour(0x202020)
      UIWindowMap.Surface.Rect(AViewportLeft, AViewportTop, AViewportRight, AViewportBottom)
         
      UIMapRenderToTarget(
         UIWindowMap.Surface,
         UIWindowMap.SurfaceBuffer, 
         UIWindowMap.MapBuffer,          
         UIMapBuffer.RootRegion, 
         ADelta, 
         AViewportCenterH, 
         AViewportCenterV, 
         AViewportLeft, 
         AViewportTop, 
         AViewportRight, 
         AViewportBottom)
            
      UIMapRenderRegionOverlay(
         UIWindowMap.MapBuffer, 
         UIWindowMap.Surface, 
         UIMapBuffer.RootRegion, 
         ADelta, 
         AViewportCenterH, 
         AViewportCenterV, 
         AViewportLeft, 
         AViewportTop, 
         AViewportRight, 
         AViewportBottom)               
      
      --Apply Window Filters
      --WindowFilter(UIWindowMap.Surface.MushWindow, 0, 0, UIWindowMap.Surface.Width, UIWindowMap.Surface.Height, 2, 10) --add mono noise
      --WindowFilter(UIWindowMap.Surface.MushWindow, 0, 0, UIWindowMap.Surface.Width, UIWindowMap.Surface.Height, 26, 0) --blur the image                     
      
      WindowImageFromWindow(UIWindowMap.MushWindow, UIWindowMap.Surface.Image, UIWindowMap.Surface.MushWindow)  
                
      UIWindowMap.Surface.RenderTo(UIWindowMap,UIWindowMap.ViewPort.Left,UIWindowMap.ViewPort.Top,UIWindowMap.ViewPort.Right,UIWindowMap.ViewPort.Bottom)
                   
   else 
      --Direct Render Mode     
      AViewportCenterH = UIWindowMap.ViewPort.CenterH - UIWindowMap.CellSizeDiv2 --add offset to centre room
      AViewportCenterV = UIWindowMap.ViewPort.CenterV - UIWindowMap.CellSizeDiv2 --add offset to centre room
      AViewportLeft = UIWindowMap.ViewPort.Left + UIWindowMap.CellSizeDiv2
      AViewportTop = UIWindowMap.ViewPort.Top + UIWindowMap.CellSizeDiv2
      AViewportRight = UIWindowMap.ViewPort.Right - UIWindowMap.CellSizeDiv2
      AViewportBottom = UIWindowMap.ViewPort.Bottom - UIWindowMap.CellSizeDiv2
   
      --UIMapRenderToTarget(UIWindowMap, UIWindowMap.MapBuffer, UIWindowMap, UIMapBuffer.RootRegion, ADelta, AViewportCenterH, AViewportCenterV, AViewportLeft, AViewportTop, AViewportRight, AViewportBottom, ADelta)         
   end   
   
   local AText = "FrameRenderMS : " .. (UIMushGetTime()-TimeStamp)*1000   
   local ATextWidth = UIWindowMap.TextWidth(AText,UIWindowMap.FontSmall)
   local ATextHeight = UIWindowMap.TextHeight(AText,UIWindowMap.FontSmall)    
   UIWindowMap.RectColour(0x222222)
   UIWindowMap.Rect(UIWindowMap.ViewPort.Left+3, UIWindowMap.ViewPort.Top+3, UIWindowMap.ViewPort.Left+3+ATextWidth, UIWindowMap.ViewPort.Top+3+ATextHeight)          
   UIWindowMap.TextColour(0xFFFFFF)
   UIWindowMap.Text(AText, UIWindowMap.FontSmall, UIWindowMap.ViewPort.Left+3, UIWindowMap.ViewPort.Top+3, UIWindowMap.ViewPort.Left+3+ATextWidth, UIWindowMap.ViewPort.Top+3+ATextHeight)
   
   local APathLength = "Path Length : " .. #UIMapBuffer.Path
   
   UIWindowMap.TextColour(0xFFFFFF)
   UIWindowMap.Text(APathLength, UIWindowMap.FontSmall, UIWindowMap.ViewPort.Left+3, UIWindowMap.ViewPort.Top+23, UIWindowMap.ViewPort.Left+3+ATextWidth, UIWindowMap.ViewPort.Top+23+ATextHeight)
     
end
