--------------------------------------------------------------------------------
--//DiscUI Map Info Window Variables
--------------------------------------------------------------------------------

UIWindowMapInfoBorderWidth = 5
UIWindowMapInfo = {}

local FBorderWidth = 5
local FButtonWidth = 70
local FButtonHeight = 25

local FColumn1Left = 5
local FColumn1Right = 290
local FColumn2Left = 295
local FColumn2Right = 580

local FRowPad = 3
local FRowTop = 20
local FRowHeight = 10
local FRowStep = FRowHeight+FBorderWidth

--------------------------------------------------------------------------------
--//DiscUI Map Info Window Functions
--------------------------------------------------------------------------------

function UIWindowMapInfoCreate()

   --Create Window
   UIWindowMapInfo = UIWindowCreate("MapInfo", 0, 460, UI_BarLeftWidth, 140, 4)   
   UIWindowMapInfo.SetTop(UIWindowMap.Bottom)
             
   UIWindowMapInfo.TitleBarText = "Map Info"
   
      
    
   FRowTop = UIWindowMapInfo.TitleBarHeight+FRowPad
   FRowHeight = 12
   FRowStep = FRowHeight+FRowPad
    
   
   UIWindowMapInfo.UpdateInfo = false
   
   
   UIWindowMapInfo.SetHeight(95)
   UIWindowMapInfo.SetTop(UIWindowMap.Bottom)
   
   UIWindowMapInfo.ButtonUpdateInfo = UIWindowMapInfo.WidgetCreate(UIWidget_Button, (UIWindowMapInfo.Width-FButtonWidth)-FBorderWidth, UIWindowMapInfo.Height-(FBorderWidth+FButtonHeight),  UIWindowMapInfo.Width-FBorderWidth, UIWindowMapInfo.Height-(FBorderWidth))
   UIWindowMapInfo.ButtonUpdateInfo.SetCaption("UpdateInfo")
   UIWindowMapInfo.ButtonUpdateInfo.OnMouseButton = ButtonUpdateInfoMouseButton  
 
   
                   
   --Add Properties   
   
   
   --UIWindowMapInfo.HotSpotMap = "HotSpotMap"
   --result = WindowAddHotspot(UIWindowMapInfo.MushWindow, UIWindowMapInfo.HotSpotMap, 
   --UIWindowMapInfo.ViewPort.Left,UIWindowMapInfo.ViewPort.Top,UIWindowMapInfo.ViewPort.Right,UIWindowMapInfo.ViewPort.Bottom,   
   --"", "", "", "", "", "", 3, 0)
      
   --result = WindowDragHandler(UIWindowMapInfo.MushWindow, UIWindowMapInfo.HotSpotMap, "UIWindowMapMouseDragMove", "UIWindowMapMouseDragEnd", 0)    
   --result = WindowScrollwheelHandler(UIWindowMapInfo.MushWindow, UIWindowMapInfo.HotSpotMap, "UIWindowMapMouseWheel")
   
   
   
   -- Assign Callbacks (or is it a copy of the function? who cares?)
   UIWindowMapInfo.OnRender = UIWindowMapInfoRender         
   UIWindowMapInfo.Render()         

   UIWindowMapInfo.Show()   
end

function UIWindowMapInfoRender(ADelta)

   
   
   if (UIWindowMap.MapBuffer ~= nil) then
       
      --Region Coordinates
      UIWindowMapInfo.TextColour(0xFFFFFF)
      UIWindowMapInfo.Text(
         "X:" .. UIWindowMap.MapBuffer.PlayerPositionX .. " Y:" .. UIWindowMap.MapBuffer.PlayerPositionY .. " Z:" .. UIWindowMap.MapBuffer.PlayerPositionZ, 
         UIWindowMapInfo.FontSmall, 
         FColumn1Left, FRowTop, FColumn1Right, (FRowTop + FRowHeight)*1)    
         
      
      --Region Name            
      if  UIWindowMap.MapBuffer.CurrentRegion then                 
         UIWindowMapInfo.Text(
            "Region:" .. UIWindowMap.MapBuffer.CurrentRegion.RegionName, 
            UIWindowMapInfo.FontSmall, 
            FColumn1Left, FRowTop+(FRowStep)*1, FColumn1Right, FRowTop+((FRowStep)*1) + FRowHeight)
     end              
      
      --Place Name
      if  UIWindowMap.MapBuffer.CurrentPlace then
      UIWindowMapInfo.Text(
         "Place:" .. UIWindowMap.MapBuffer.CurrentPlace.PlaceName, 
         UIWindowMapInfo.FontSmall, 
         FColumn1Left, FRowTop+(FRowStep)*2, FColumn1Right, FRowTop+((FRowStep)*2) + FRowHeight)                  
      end     
      --Street Name
      if UIWindowMap.MapBuffer.CurrentRoom then
         if #UIWindowMap.MapBuffer.CurrentRoom.RoomStreets > 0 then
            UIWindowMapInfo.Text(
               "Street:" .. UIWindowMap.MapBuffer.CurrentRoom.RoomStreets[1].StreetName, 
               UIWindowMapInfo.FontSmall, 
               FColumn1Left, FRowTop+(FRowStep)*3, FColumn1Right, FRowTop+((FRowStep)*3) + FRowHeight)                    
         else
            UIWindowMapInfo.Text(
               "Street:", 
               UIWindowMapInfo.FontSmall, 
               FColumn1Left, FRowTop+(FRowStep)*3, FColumn1Right, FRowTop+((FRowStep)*3) + FRowHeight)         
         end
            
         UIWindowMapInfo.Text(
            "Room:" .. UIWindowMap.MapBuffer.CurrentRoom.RoomName, 
            UIWindowMapInfo.FontSmall, 
            FColumn1Left, FRowTop+(FRowStep)*4, FColumn1Right, FRowTop+((FRowStep)*4) + FRowHeight)
      end
                           
      --Hovering
      if UIWindowMap.MapBuffer.HoveringRoom then
                
         --Region Coordinates
         UIWindowMapInfo.TextColour(0xFFFFFF)
         UIWindowMapInfo.Text(
            "X:" .. UIWindowMap.MapBuffer.HoveringRoom.RoomPositionX .. " Y:" .. UIWindowMap.MapBuffer.HoveringRoom.RoomPositionY .. " Z:" .. UIWindowMap.MapBuffer.HoveringRoom.RoomPositionZ, 
            UIWindowMapInfo.FontSmall, 
            FColumn2Left, FRowTop, FColumn2Right, (FRowTop + FRowHeight)*1)    
            
         --Region Name         
         --UIWindowMapInfo.Text(
         --   "Region:" .. UIWindowMap.MapBuffer.CurrentRegion.RegionName, 
         --   UIWindowMapInfo.FontSmall, 
         --   FColumn2Left, FRowTop+(FRowStep)*1, FColumn2Right, FRowTop+((FRowStep)*1) + FRowHeight)              
         
         --Place Name         
         --UIWindowMapInfo.Text(
         --   "Place:" .. UIWindowMap.MapBuffer.CurrentPlace.PlaceName, 
         --   UIWindowMapInfo.FontSmall, 
         --   FColumn2Left, FRowTop+(FRowStep)*2, FColumn2Right, FRowTop+((FRowStep)*2) + FRowHeight)                  
        
         --Street Name         
         if #UIWindowMap.MapBuffer.HoveringRoom.RoomStreets > 0 then
            UIWindowMapInfo.Text(
               "Street:" .. UIWindowMap.MapBuffer.HoveringRoom.RoomStreets[1].StreetName, 
               UIWindowMapInfo.FontSmall, 
               FColumn2Left, FRowTop+(FRowStep)*3, FColumn2Right, FRowTop+((FRowStep)*3) + FRowHeight)                    
         else
            UIWindowMapInfo.Text(
               "Street:", 
               UIWindowMapInfo.FontSmall, 
               FColumn2Left, FRowTop+(FRowStep)*3, FColumn2Right, FRowTop+((FRowStep)*3) + FRowHeight)         
         end
         
         UIWindowMapInfo.Text(
         "Room:" .. UIWindowMap.MapBuffer.HoveringRoom.RoomName, 
         UIWindowMapInfo.FontSmall, 
         FColumn2Left, FRowTop+(FRowStep)*4, FColumn2Right, FRowTop+((FRowStep)*4) + FRowHeight)
         
      else
         --Region Coordinates
         UIWindowMapInfo.TextColour(0xFFFFFF)
         UIWindowMapInfo.Text(
            "X: Y: Z:", 
            UIWindowMapInfo.FontSmall, 
            FColumn2Left, FRowTop, FColumn2Right, (FRowTop + FRowHeight)*1)    
            
         --Region Name         
         UIWindowMapInfo.Text(
            "Region:", 
            UIWindowMapInfo.FontSmall, 
            FColumn2Left, FRowTop+(FRowStep)*1, FColumn2Right, FRowTop+((FRowStep)*1) + FRowHeight)              
         
         --Place Name
         
         UIWindowMapInfo.Text(
            "Place:", 
            UIWindowMapInfo.FontSmall, 
            FColumn2Left, FRowTop+(FRowStep)*2, FColumn2Right, FRowTop+((FRowStep)*2) + FRowHeight)                  
        
         --Street Name
         
         UIWindowMapInfo.Text(
            "Street:", 
            UIWindowMapInfo.FontSmall, 
            FColumn2Left, FRowTop+(FRowStep)*3, FColumn2Right, FRowTop+((FRowStep)*3) + FRowHeight)     
      end
                           
   end   

end

function ButtonUpdateInfoMouseButton(AMouseX, AMouseY, Button, State)
   
   if UIWindowMapInfo.UpdateInfo == false then
      UIWindowMapInfo.UpdateInfo = true
      UIWindowMapInfo.ButtonUpdateInfo.ColourBackground = UIWindowMapInfo.ButtonUpdateInfo.ColourBackground + 0x000044
      UIWindowMapInfo.ButtonUpdateInfo.ColourBackgroundHovering = UIWindowMapInfo.ButtonUpdateInfo.ColourBackgroundHovering + 0x000044      
   else
      UIWindowMapInfo.UpdateInfo = false
      UIWindowMapInfo.ButtonUpdateInfo.ColourBackground = UIWindowMapInfo.ButtonUpdateInfo.ColourBackground - 0x000044
      UIWindowMapInfo.ButtonUpdateInfo.ColourBackgroundHovering = UIWindowMapInfo.ButtonUpdateInfo.ColourBackgroundHovering - 0x000044    
   end
end

