--//DiscUI Console

--------------------------------------------------------------------------------
--//DiscUI Console Variables
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
--//DiscUI Console Functions
--------------------------------------------------------------------------------

function UIConsoleAutoToggle()
   local CBackground = "#121212"         
   local CMessage = "#AAFFAA"   
   local AState = AutoToggle()
   if AState then
      ColourNote(CMessage, CBackground, "DiscUI Auto Enabled")
   else
      ColourNote(CMessage, CBackground, "DiscUI Auto Disabled")
   end
end

function UIConsoleAutoIdle()
   local CBackground = "#121212"         
   local CMessage = "#AAFFAA"   
   ColourNote(CMessage, CBackground, "DiscUI Auto Idle Trigger")
   
   AutoDoIdleCommand()   
end

function UIConsoleReset()
  --Send  ("options output prompt=off")
end

function UIConsoleConfig()
  --Send  ("options output prompt=off")
end

function UIConsoleHelp()

   local CBackground = "#121212"         
   local CMessage = "#AAFFAA"      
   ColourNote(CMessage, CBackground, "   ")     
   ColourNote(CMessage, CBackground, "DiscUI Help")
   ColourNote(CMessage, CBackground, "-----------")
   ColourNote(CMessage, CBackground, "   ")
   
   ColourNote(CMessage, CBackground, "   UIReset - Reset DiscUI to defaults")
   ColourNote(CMessage, CBackground, "   UIConfig - List configuration options")
   ColourNote(CMessage, CBackground, "   UIHelp - Display this help screen")
   ColourNote(CMessage, CBackground, "   ")
   
end


