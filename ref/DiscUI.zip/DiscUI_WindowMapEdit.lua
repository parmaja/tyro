--------------------------------------------------------------------------------
--//DiscUI Map Edit Window
--------------------------------------------------------------------------------

UIWindowMapEditBorderWidth = 5
UIWindowMapEdit = {}

local ModeButtonDefaultColourBackground = 0
local ModeButtonDefaultColourBackgroundHover = 0


--------------------------------------------------------------------------------
function UIWindowMapEditCreate(AMapBuffer)   

   --Create Window
   UIWindowMapEdit = UIWindowCreate("MapEdit", 0, UIWindowMapInfo.Bottom, UI_BarLeftWidth, 150, 4)      
   UIWindowMapEdit.SetTop(UIWindowMapInfo.Bottom)
   UIWindowMapEdit.SetHeight(120)
   UIWindowMapEdit.MapBuffer = AMapBuffer  
             
   UIWindowMapEdit.TitleBarText = "Map Edit"
   
   local BorderWidth = 3
   local ButtonWidth = ((UIWindowMapEdit.Width-(BorderWidth*6))) / 7
   local ButtonHeight = 15
   local FRowTop = UIWindowMapEdit.TitleBarHeight+BorderWidth
   
   local FColumnLeft = BorderWidth
   local FColumnRight = FColumnLeft + ButtonWidth
   local FColumnWidth = FColumnRight - FColumnLeft
   local FColumnWidthDiv2 = FColumnWidth / 2
   
   UIWindowMapEdit.ButtonEditModeRegion = UIWindowMapEdit.WidgetCreate(UIWidget_Button, FColumnLeft, FRowTop, FColumnRight, FRowTop+ButtonHeight)
   UIWindowMapEdit.ButtonEditModeRegion.SetCaption("Region")  
   UIWindowMapEdit.ButtonEditModeRegion.OnMouseButton = DoEditModeRegion 
   
   UIWindowMapEdit.ButtonEditModeRoom = UIWindowMapEdit.WidgetCreate(UIWidget_Button, FColumnLeft, FRowTop+((ButtonHeight+BorderWidth)*1), FColumnRight, FRowTop+((ButtonHeight+BorderWidth)*1)+ButtonHeight)
   UIWindowMapEdit.ButtonEditModeRoom.SetCaption("Room")
   UIWindowMapEdit.ButtonEditModeRoom.OnMouseButton = DoEditModeRoom
   
   UIWindowMapEdit.ButtonEditModeCell = UIWindowMapEdit.WidgetCreate(UIWidget_Button, FColumnLeft, FRowTop+((ButtonHeight+BorderWidth)*2), FColumnRight, FRowTop+((ButtonHeight+BorderWidth)*2)+ButtonHeight)
   UIWindowMapEdit.ButtonEditModeCell.SetCaption("Cell")
   UIWindowMapEdit.ButtonEditModeCell.OnMouseButton = DoEditModeCell
   
   UIWindowMapEdit.ButtonEditStreet = UIWindowMapEdit.WidgetCreate(UIWidget_Button, FColumnLeft, FRowTop+((ButtonHeight+BorderWidth)*3), FColumnRight, FRowTop+((ButtonHeight+BorderWidth)*3)+ButtonHeight)
   UIWindowMapEdit.ButtonEditStreet.SetCaption("Street")
   UIWindowMapEdit.ButtonEditStreet.OnMouseButton = DoEditModeStreet
   
   ModeButtonDefaultColourBackground = UIWindowMapEdit.ButtonEditModeRegion.ColourBackground
   ModeButtonDefaultColourBackgroundHover = UIWindowMapEdit.ButtonEditModeRegion.ColourBackgroundHovering
   
    
   FColumnLeft = FColumnRight + BorderWidth
   FColumnRight = FColumnLeft + ButtonWidth*2
   FColumnWidth = FColumnRight - FColumnLeft
   FColumnWidthDiv2 = FColumnWidth / 2   
   
   UIWindowMapEdit.DropdownStreet = UIWindowMapEdit.WidgetCreate(UIWidget_Dropdown, FColumnLeft, FRowTop, FColumnRight, FRowTop+ButtonHeight)   

   UIWindowMapEdit.ButtonAddRoomToStreet = UIWindowMapEdit.WidgetCreate(UIWidget_Button, FColumnLeft, FRowTop+((ButtonHeight+BorderWidth)*1), FColumnRight, FRowTop+((ButtonHeight+BorderWidth)*1)+ButtonHeight)
   UIWindowMapEdit.ButtonAddRoomToStreet.SetCaption("+Room > Street")
   UIWindowMapEdit.ButtonAddRoomToStreet.OnMouseButton = ButtonAddRoomToStreetMouseButton
       
   UIWindowMapEdit.DropdownStreet.PopupList.ItemsClear()
      
   for I, Street in pairs(UIWindowMapEdit.MapBuffer.Streets) do
      UIWindowMapEdit.DropdownStreet.ItemAdd(Street.StreetName, Street)   
   end 
   
   UIWindowMapEdit.EditBoxStreet = UIWindowMapEdit.WidgetCreate(UIWidget_Editbox, FColumnLeft, FRowTop+((ButtonHeight+BorderWidth)*2), FColumnRight, FRowTop+((ButtonHeight+BorderWidth)*2)+ButtonHeight)   
   UIWindowMapEdit.ButtonCreateStreet = UIWindowMapEdit.WidgetCreate(UIWidget_Button, FColumnLeft, FRowTop+((ButtonHeight+BorderWidth)*3), FColumnRight, FRowTop+((ButtonHeight+BorderWidth)*3)+ButtonHeight)
   UIWindowMapEdit.ButtonCreateStreet.SetCaption("Create Street")      
   
   
   
    
   FColumnLeft = FColumnRight + BorderWidth + ButtonWidth*2
   FColumnRight = FColumnLeft + ButtonWidth*2 --UIWindowMapEdit.Width -BorderWidth --FColumnLeft + ButtonWidth*3
   FColumnWidth = FColumnRight - FColumnLeft
   FColumnWidthDiv2 = FColumnWidth / 2    
   UIWindowMapEdit.EditBoxRegionName = UIWindowMapEdit.WidgetCreate(UIWidget_Editbox, FColumnLeft, FRowTop, FColumnRight, FRowTop+ButtonHeight)
   
   UIWindowMapEdit.DropdownRegionType = UIWindowMapEdit.WidgetCreate(UIWidget_Dropdown, FColumnLeft, FRowTop+((ButtonHeight+BorderWidth)*1), FColumnLeft+FColumnWidthDiv2, FRowTop+((ButtonHeight+BorderWidth)*1)+ButtonHeight)
   UIWindowMapEdit.DropdownRegionType.ItemAdd("City", 1)
   UIWindowMapEdit.DropdownRegionType.ItemAdd("Building", 2)
   UIWindowMapEdit.DropdownRegionType.ItemAdd("Terrain", 3)      
                 
   UIWindowMapEdit.ButtonCreateRegionChild = UIWindowMapEdit.WidgetCreate(UIWidget_Button, FColumnLeft+FColumnWidthDiv2+BorderWidth, FRowTop+((ButtonHeight+BorderWidth)*1), FColumnRight, FRowTop+((ButtonHeight+BorderWidth)*1)+ButtonHeight)
   UIWindowMapEdit.ButtonCreateRegionChild.SetCaption("NewChildRegion")
   UIWindowMapEdit.ButtonCreateRegionChild.OnMouseButton = ButtonCreateRegionChildMouseButton     
   
   UIWindowMapEdit.ButtonDBWrite = UIWindowMapEdit.WidgetCreate(UIWidget_Button, FColumnLeft, FRowTop+((ButtonHeight+BorderWidth)*2), FColumnRight, FRowTop+((ButtonHeight+BorderWidth)*2)+ButtonHeight)
   UIWindowMapEdit.ButtonDBWrite.SetCaption("DB Write")
   UIWindowMapEdit.ButtonDBWrite.OnMouseButton = ButtonDBWriteMouseButton  
    
   UIWindowMapEdit.ButtonMergeRoom = UIWindowMapEdit.WidgetCreate(UIWidget_Button, FColumnLeft, FRowTop+((ButtonHeight+BorderWidth)*3), FColumnRight, FRowTop+((ButtonHeight+BorderWidth)*3)+ButtonHeight)
   UIWindowMapEdit.ButtonMergeRoom.SetCaption("Merge Room")
   UIWindowMapEdit.ButtonMergeRoom.OnMouseButton = ButtonMergeRoomMouseButton
   
   UIWindowMapEdit.ButtonMergeSector = UIWindowMapEdit.WidgetCreate(UIWidget_Button, FColumnLeft, FRowTop+((ButtonHeight+BorderWidth)*4), FColumnRight, FRowTop+((ButtonHeight+BorderWidth)*4)+ButtonHeight)
   UIWindowMapEdit.ButtonMergeSector.SetCaption("Merge Sector")
   UIWindowMapEdit.ButtonMergeSector.OnMouseButton = ButtonMergeSectorMouseButton
                           
   -- Assign Callbacks (or is it a copy of the function? who cares?)
   UIWindowMapEdit.OnRender = UIWindowMapEditRender         
   UIWindowMapEdit.Render()         
   UIWindowMapEdit.Show()   
end

--------------------------------------------------------------------------------
function UIWindowMapEditRender(ADelta)
                  
end

--------------------------------------------------------------------------------
function DoEditModeRegion(AMouseX, AMouseY, Button, State)   
   if UI_EditMode ~= 1 then
      UI_EditMode = 1
            
      UIWindowMapEdit.ButtonEditModeRegion.ColourBackground = 0xCC8888
      UIWindowMapEdit.ButtonEditModeRegion.ColourBackgroundHovering = 0xFFAAAA  
      UIWindowMapEdit.ButtonEditModeRoom.ColourBackground = ModeButtonDefaultColourBackground
      UIWindowMapEdit.ButtonEditModeRoom.ColourBackgroundHovering = ModeButtonDefaultColourBackgroundHover   
      UIWindowMapEdit.ButtonEditModeCell.ColourBackground = ModeButtonDefaultColourBackground
      UIWindowMapEdit.ButtonEditModeCell.ColourBackgroundHovering = ModeButtonDefaultColourBackgroundHover   
      UIWindowMapEdit.ButtonEditStreet.ColourBackground = ModeButtonDefaultColourBackground
      UIWindowMapEdit.ButtonEditStreet.ColourBackgroundHovering = ModeButtonDefaultColourBackgroundHover
      
      UIWindowMapEdit.ButtonEditModeRegion.Render()      
      UIWindowMapEdit.ButtonEditModeRoom.Render()          
      UIWindowMapEdit.ButtonEditModeCell.Render()  
      UIWindowMapEdit.ButtonEditStreet.Render()  
      
   end
end
--------------------------------------------------------------------------------
function DoEditModeRoom(AMouseX, AMouseY, Button, State)
   if UI_EditMode ~= 2 then  
      UI_EditMode = 2
      
      UIWindowMapEdit.ButtonEditModeRegion.ColourBackground = ModeButtonDefaultColourBackground
      UIWindowMapEdit.ButtonEditModeRegion.ColourBackgroundHovering = ModeButtonDefaultColourBackgroundHover  
      UIWindowMapEdit.ButtonEditModeRoom.ColourBackground = 0xCC8888
      UIWindowMapEdit.ButtonEditModeRoom.ColourBackgroundHovering = 0xFFAAAA   
      UIWindowMapEdit.ButtonEditModeCell.ColourBackground = ModeButtonDefaultColourBackground
      UIWindowMapEdit.ButtonEditModeCell.ColourBackgroundHovering = ModeButtonDefaultColourBackgroundHover   
      UIWindowMapEdit.ButtonEditStreet.ColourBackground = ModeButtonDefaultColourBackground
      UIWindowMapEdit.ButtonEditStreet.ColourBackgroundHovering = ModeButtonDefaultColourBackgroundHover
      
      UIWindowMapEdit.ButtonEditModeRegion.Render()      
      UIWindowMapEdit.ButtonEditModeRoom.Render()          
      UIWindowMapEdit.ButtonEditModeCell.Render()  
      UIWindowMapEdit.ButtonEditStreet.Render()  
   end
end
--------------------------------------------------------------------------------
function DoEditModeCell(AMouseX, AMouseY, Button, State)
   if UI_EditMode ~= 3 then      
      UI_EditMode = 3
      
      UIWindowMapEdit.ButtonEditModeRegion.ColourBackground = ModeButtonDefaultColourBackground
      UIWindowMapEdit.ButtonEditModeRegion.ColourBackgroundHovering = ModeButtonDefaultColourBackgroundHover  
      UIWindowMapEdit.ButtonEditModeRoom.ColourBackground = ModeButtonDefaultColourBackground
      UIWindowMapEdit.ButtonEditModeRoom.ColourBackgroundHovering = ModeButtonDefaultColourBackgroundHover   
      UIWindowMapEdit.ButtonEditModeCell.ColourBackground = 0xCC8888
      UIWindowMapEdit.ButtonEditModeCell.ColourBackgroundHovering = 0xFFAAAA   
      UIWindowMapEdit.ButtonEditStreet.ColourBackground = ModeButtonDefaultColourBackground
      UIWindowMapEdit.ButtonEditStreet.ColourBackgroundHovering = ModeButtonDefaultColourBackgroundHover
      
      UIWindowMapEdit.ButtonEditModeRegion.Render()      
      UIWindowMapEdit.ButtonEditModeRoom.Render()          
      UIWindowMapEdit.ButtonEditModeCell.Render()  
      UIWindowMapEdit.ButtonEditStreet.Render()  
   end
end
--------------------------------------------------------------------------------
function DoEditModeStreet(AMouseX, AMouseY, Button, State)
   if UI_EditMode ~= 4 then     
      UI_EditMode = 4
      
      UIWindowMapEdit.ButtonEditModeRegion.ColourBackground = ModeButtonDefaultColourBackground
      UIWindowMapEdit.ButtonEditModeRegion.ColourBackgroundHovering = ModeButtonDefaultColourBackgroundHover  
      UIWindowMapEdit.ButtonEditModeRoom.ColourBackground = ModeButtonDefaultColourBackground
      UIWindowMapEdit.ButtonEditModeRoom.ColourBackgroundHovering = ModeButtonDefaultColourBackgroundHover   
      UIWindowMapEdit.ButtonEditModeCell.ColourBackground = ModeButtonDefaultColourBackground
      UIWindowMapEdit.ButtonEditModeCell.ColourBackgroundHovering = ModeButtonDefaultColourBackgroundHover   
      UIWindowMapEdit.ButtonEditStreet.ColourBackground = 0xCC8888
      UIWindowMapEdit.ButtonEditStreet.ColourBackgroundHovering = 0xFFAAAA
      
      UIWindowMapEdit.ButtonEditModeRegion.Render()      
      UIWindowMapEdit.ButtonEditModeRoom.Render()          
      UIWindowMapEdit.ButtonEditModeCell.Render()  
      UIWindowMapEdit.ButtonEditStreet.Render()  
   end
end   
--------------------------------------------------------------------------------
function ButtonDBWriteMouseButton(AMouseX, AMouseY, Button, State)
   
   if UIEnableDBWrite == false then
      UIEnableDBWrite = true
      UIWindowMapEdit.ButtonDBWrite.ColourBackground = UIWindowMapEdit.ButtonDBWrite.ColourBackground + 0x000044
      UIWindowMapEdit.ButtonDBWrite.ColourBackgroundHovering = UIWindowMapEdit.ButtonDBWrite.ColourBackgroundHovering + 0x000044      
   else
      UIEnableDBWrite = false
      UIWindowMapEdit.ButtonDBWrite.ColourBackground = UIWindowMapEdit.ButtonDBWrite.ColourBackground - 0x000044
      UIWindowMapEdit.ButtonDBWrite.ColourBackgroundHovering = UIWindowMapEdit.ButtonDBWrite.ColourBackgroundHovering - 0x000044    
   end
end

--------------------------------------------------------------------------------
function ButtonMergeRoomMouseButton(AMouseX, AMouseY, Button, State)
   
   if UIEnableMapMergeRoom == false then
      UIEnableMapMergeRoom = true
      UIWindowMapEdit.ButtonMergeRoom.ColourBackground = UIWindowMapEdit.ButtonMergeRoom.ColourBackground + 0x000044
      UIWindowMapEdit.ButtonMergeRoom.ColourBackgroundHovering = UIWindowMapEdit.ButtonMergeRoom.ColourBackgroundHovering + 0x000044   
   else
      UIEnableMapMergeRoom = false
      UIWindowMapEdit.ButtonMergeRoom.ColourBackground = UIWindowMapEdit.ButtonMergeRoom.ColourBackground - 0x000044
      UIWindowMapEdit.ButtonMergeRoom.ColourBackgroundHovering = UIWindowMapEdit.ButtonMergeRoom.ColourBackgroundHovering - 0x000044
   end
end

--------------------------------------------------------------------------------
function ButtonMergeSectorMouseButton(AMouseX, AMouseY, Button, State)
   
   if UIEnableMapMergeSector == false then
      UIEnableMapMergeSector = true
      UIWindowMapEdit.ButtonMergeSector.ColourBackground = UIWindowMapEdit.ButtonMergeSector.ColourBackground + 0x000044
      UIWindowMapEdit.ButtonMergeSector.ColourBackgroundHovering = UIWindowMapEdit.ButtonMergeSector.ColourBackgroundHovering + 0x000044   
   else
      UIEnableMapMergeSector = false
      UIWindowMapEdit.ButtonMergeSector.ColourBackground = UIWindowMapEdit.ButtonMergeSector.ColourBackground - 0x000044
      UIWindowMapEdit.ButtonMergeSector.ColourBackgroundHovering = UIWindowMapEdit.ButtonMergeSector.ColourBackgroundHovering - 0x000044
   end
end

--------------------------------------------------------------------------------
function ButtonAddRoomToStreetMouseButton(AMouseX, AMouseY, Button, State)
   if UIWindowMapEdit.DropdownStreet.Item then
      if UIWindowMapEdit.MapBuffer.SelectedRoom then   
         UIWindowMapEdit.MapBuffer.StreetAddRoom(UIWindowMapEdit.DropdownStreet.PopupList.SelectedItem.Data, UIWindowMapEdit.MapBuffer.SelectedRoom)
      end   
   end   
end

--------------------------------------------------------------------------------
function ButtonCreateRegionChildMouseButton(AMouseX, AMouseY, Button, State)

   UIMushCaptureKeyboard(false)


   if UIWindowMapEdit.EditBoxRegionName.Caption == "" then return end
   if not UIWindowMapEdit.DropdownRegionType.SelectedItem then return end
   
   --Setup region properties   
   local ARegion = nil
   local ASector = nil
   local ARegionName = UIWindowMapEdit.EditBoxRegionName.Caption    
   local ARegionType = UIWindowMapEdit.DropdownRegionType.SelectedItem.Data             
   
   local ARegionStride = 1  
   local ARegionScale = 1    
   if ARegionType == 1 then 
      ARegionStride = 2
      ARegionScale = 0.25          
   elseif ARegionType == 2 then 
      ARegionStride = 2
      ARegionScale = 0.25
   elseif ARegionType == 3 then 
      ARegionStride = 1
      ARegionScale = 2 
   end
   
   world.Note("Create RegionChiold RegionType = " ..ARegionType)
   
   --Calculate initial region position        
   local VertexX = UIMapBuffer.PlayerPositionX - (ARegionStride-1)*((UIMapBuffer.PreviousDirectionVectorX)) --* ARegionScale--(ARegionStride / 2))
   local VertexY = UIMapBuffer.PlayerPositionY - (ARegionStride-1)*((UIMapBuffer.PreviousDirectionVectorY)) --* ARegionScale--(ARegionStride / 2))
   local VertexZ = UIMapBuffer.PlayerPositionZ - (ARegionStride-1)*((UIMapBuffer.PreviousDirectionVectorZ)) --* ARegionScale--(ARegionStride / 2))
   
   --Create new region                      
   ARegion = UIMapBuffer.RegionCreate(ARegionName, UIMapBuffer.CurrentRegion, ARegionType, ARegionStride, ARegionScale, VertexX, VertexY, VertexZ)
   
   --Set Child properties
   ARegion.RegionColour = 2
         
   UIMapDBRegionWrite(ARegion)
      
   --Create new sector in this region
   ASector = UIMapBuffer.SectorCreate(ARegion, 0, 0, 0)
                                 
   --remove room from its current region
   UIMapBuffer.CurrentRoom.Region.RegionRoomsXYZ[UIMapBuffer.CurrentRoom.RoomPositionX..":"..UIMapBuffer.CurrentRoom.RoomPositionY..":"..UIMapBuffer.CurrentRoom.RoomPositionZ] = nil      
   --remove room from its current sector
   UIMapBuffer.CurrentRoom.Sector.SectorRoomsXYZ[UIMapBuffer.CurrentRoom.RoomPositionX..":"..UIMapBuffer.CurrentRoom.RoomPositionY..":"..UIMapBuffer.CurrentRoom.RoomPositionZ] = nil
   
   --set CurrentRegion
   UIMapBuffer.PreviousRegion = UIMapBuffer.CurrentRegion
   UIMapBuffer.CurrentRegion = ARegion
   --set CurrentSector
   UIMapBuffer.PreviousSector = UIMapBuffer.CurrentSector
   UIMapBuffer.CurrentSector = ASector
   
   --Set player position to 0,0,0 in this new region
   UIMapBuffer.PlayerPositionX = 0
   UIMapBuffer.PlayerPositionY = 0
   UIMapBuffer.PlayerPositionZ = 0
                   
   --setup Current room      
   UIMapBuffer.CurrentRoom.RegionID = ARegion.RegionID
   UIMapBuffer.CurrentRoom.SectorID = ASector.SectorID         
   UIMapBuffer.CurrentRoom.RoomPositionX = UIMapBuffer.PlayerPositionX
   UIMapBuffer.CurrentRoom.RoomPositionY = UIMapBuffer.PlayerPositionY
   UIMapBuffer.CurrentRoom.RoomPositionZ = UIMapBuffer.PlayerPositionZ        
   UIMapDBRoomWrite(UIMapBuffer.CurrentRoom)                                 
   UIMapBuffer.CurrentRoom.Region = ARegion
   UIMapBuffer.CurrentRoom.Sector = ASector   
   
   --add the room into the new buffers
   ARegion.RegionRoomsXYZ[UIMapBuffer.CurrentRoom.RoomPositionX..":"..UIMapBuffer.CurrentRoom.RoomPositionY..":"..UIMapBuffer.CurrentRoom.RoomPositionZ] = UIMapBuffer.CurrentRoom      
   ASector.SectorRoomsXYZ[UIMapBuffer.CurrentRoom.RoomPositionX..":"..UIMapBuffer.CurrentRoom.RoomPositionY..":"..UIMapBuffer.CurrentRoom.RoomPositionZ] = UIMapBuffer.CurrentRoom
                  
   --??add portal linking current location to 0,0,0 in the new location
      
   --??link current room to new room if cardinal and new region not terrain             
end
