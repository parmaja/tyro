--------------------------------------------------------------------------------
--//DiscUI Widget Scrollbar 
--------------------------------------------------------------------------------

function UIWidgetScrollbarCreate(AWindow, AWidgetLeft, AWidgetTop, AWidgetRight, AWidgetBottom)
   
    local self = UIWidgetCreate(AWindow, AWidgetLeft, AWidgetTop, AWidgetRight, AWidgetBottom)
          
   --overrides
   self.WidgetType = UIWidget_Scrollbar
   self.WidgetTypeName = "WidgetScrollbar"
   self.SetCaption("Scrollbar")      
   self.ColourBackground = 0x101010
   self.Font = self.Window.FontSmall
                           
   self.ScrollY = 0
   self.BarHeight = 1
   self.ScrollHeight = 1
   self.PageHeight = 1
 
   function self.SetScrollY(AScrollY)      
      self.ScrollY = AScrollY
      self.Render()      
   end
   
   function self.SetScrollHeight(AScrollHeight)         
      self.ScrollHeight = AScrollHeight
      self.BarHeight = self.Height * (self.PageHeight/self.ScrollHeight)      
      --self.BarHeight = (self.Height/self.ScrollHeight)*self.PageHeight
      self.Render()            
   end
   
   function self.SetPageHeight(APageHeight)
      self.PageHeight = APageHeight      
      self.BarHeight = self.Height * (self.PageHeight/self.ScrollHeight)      
      --self.BarHeight = (self.Height/self.ScrollHeight)*self.PageHeight         
      self.Render()
   end
         
   self.RenderParent = self.Render  ----override
   function self.Render()                 
      self.RenderParent()  

      --Render Background      
      self.Window.RectColour(0x222222)                 
      self.Window.Rect(self.Left,self.Top,self.Right,self.Bottom)

      --Render Bar                        
      self.Window.RectColour(0x777777)  
            
      local ARangePixels = self.Height    
      --Note(self.ScrollHeight)
      --Note(self.ScrollY)                              
      local ScrollYPixels = (ARangePixels / (self.ScrollHeight/self.ScrollY))            
      
      self.Window.Rect(self.Left,
      self.Top + ScrollYPixels,
      self.Right,
      self.Top + ScrollYPixels + self.BarHeight)
      
      --Render Background Outline
      self.Window.RectColour(0x939393)
      self.Window.RectOutline(self.Left,self.Top,self.Right,self.Bottom)                      
   end
      
   --Setup Scrollbar
                    
   return self      
end