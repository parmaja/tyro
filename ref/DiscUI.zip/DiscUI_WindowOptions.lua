--------------------------------------------------------------------------------
--//DiscUI Map Edit Window Variables
--------------------------------------------------------------------------------

UIWindowOptionsBorderWidth = 5
UIWindowOptions = {}

--------------------------------------------------------------------------------
--//DiscUI Map Edit Window Functions
--------------------------------------------------------------------------------

function UIWindowOptionsCreate(AMapBuffer)   

   --Create Window
   UIWindowOptions = UIWindowCreate("Options", UI_BarLeftWidth, 0, 300, UI_BarTopHeight, 4)      
      
   UIWindowOptions.MapBuffer = AMapBuffer  
             
   UIWindowOptions.TitleBarText = "Options"
   
   local FBorderWidth = 4
   local FButtonWidth = ((UIWindowOptions.Width-(FBorderWidth*6))) / 6
   local FButtonHeight = 15
   local FRowTop = UIWindowOptions.TitleBarHeight+FBorderWidth
   local FRowBottom = UIWindowOptions.Height-FBorderWidth
   
   local FColumnLeft = FBorderWidth            
   local FColumnRight = UIWindowOptions.Width - FBorderWidth                         
        
   UIWindowOptions.TreeviewOptions = UIWindowOptions.WidgetCreate(UIWidget_Treeview, 
      FColumnLeft, 
      FRowTop, 
      FColumnRight, 
      FRowBottom)
  
 
   
   
   -- Assign Callbacks ()
   
   UIWindowOptions.Render()         
   UIWindowOptions.Show()   
end
