--------------------------------------------------------------------------------
--//DiscUI Map Cache Render
--------------------------------------------------------------------------------

--library local references
local math_floor = math.floor
local math_ceil = math.ceil
local math_max = math.max
local string_byte = string.byte
local string_sub = string.sub
local FUIMapExitTypeColour = UIMapExitTypeColour
local FUIMapSectorSize = UIMapSectorSize

--Surface/Map References
local FMapRenderSurface = nil
local FMapRenderSurfaceMushWindow = ""
local FMapRenderSurfaceBuffer = nil
local FMapRenderSurfaceBufferMushWindow = ""
local FMapRenderMapBuffer = nil

--Current Rendering Function References
local FMapRenderCurrentMushWindow = ""
local FMapRenderCurrentLineColour = nil
local FMapRenderCurrentRectColour = nil
local FMapRenderCurrentLine = nil            
local FMapRenderCurrentRect = nil

--Current Rendering Properties
local FMapRenderDelta = 0

local FViewportMiddleX = 0 
local FViewportMiddleY = 0 
local FViewportLeft = 0 
local FViewportTop = 0 
local FViewportRight = 0 
local FViewportBottom = 0
local FViewportWidth = 0
local FViewportHeight = 0

local FMapRenderCurrentCellSize = 0      
local FMapRenderCurrentCellSizeDiv2 = 0                        
local FMapRenderCurrentLineWidth = 5

local FRenderCellLeft = 0
local FRenderCellTop = 0
local FRenderCellRight = 0
local FRenderCellBottom = 0
local FRenderCellMiddleX = 0
local FRenderCellMiddleY = 0
local FRoomRenderPosLeft = 0
local FRoomRenderPosTop = 0
local FRoomRenderPosRight = 0
local FRoomRenderPosBottom = 0


local FRoomRenderColourRoom = 0x000000
local FRoomRenderColourStreet = 0
local FRenderColourCell = 0x000000

--local current sector references
local ASectors = nil 
local ASector = {}

--------------------------------------------------------------------------------
local function UIWindowMapRenderCacheRoomStreet(ARoom, APositionX, APositionY)
   
   local FColour = 0x000000
   local FRenderColour = 0   
   --local FR,FG,FB = 0   
   --FR,FG,FB = UIColourToRGB(UIMapColours[ARoom.Region.RegionColour])    
   --FR,FG,FB = UIRGBBlend(255,255,255, FR,FG,FB, 0.55)   
   --FColour = UIRGBToColour(FR,FG,FB)
   FColour = UIColourBlend(0xFFFFFF, UIMapColours[ARoom.Region.RegionColour],0.55)
        
   local HoverStreet = false
   --if #ARoom.RoomStreets > 0 then         
   --   if UIWindowMap.MapBuffer.HoveringStreet then            
   --      if ARoom.RoomStreets[1].StreetID == UIWindowMap.MapBuffer.HoveringStreet.StreetID then
   --         HoverStreet = true                        
   --      end
   --   end
   --end
   
   if ARoom.Selected then
      HoverStreet = true
   end
                  
   if (ARoom.ExitNorth > -1) and (ARoom.ExitSouth > -1) and (ARoom.ExitNorthType == ARoom.ExitSouthType) then
   
      if ARoom.ExitNorthType == 2 then -- door    
         FRenderColour = UIMapExitTypeColour[2]
      else
         FRenderColour = FColour 
      end    
      if HoverStreet then FRenderColour = 0xFFFFFF end         
      FMapRenderCurrentLineColour(FRenderColour)
      FMapRenderCurrentLine(APositionX, FRenderCellTop, APositionX, FRenderCellBottom)                                         
   else           
      if ARoom.ExitNorth > -1 then         
         if ARoom.ExitNorthType == 2 then -- door    
            FRenderColour = UIMapExitTypeColour[2]
         else
            FRenderColour = FColour 
         end    
         if HoverStreet then FRenderColour = 0xFFFFFF end         
         FMapRenderCurrentLineColour(FRenderColour)
         FMapRenderCurrentLine(APositionX, FRenderCellTop, APositionX, APositionY)                                                   
      end         
      if ARoom.ExitSouth > -1 then
         if ARoom.ExitSouthType == 2 then -- door    
            FRenderColour = UIMapExitTypeColour[2]
         else
            FRenderColour = FColour 
         end    
         if HoverStreet then FRenderColour = 0xFFFFFF end         
         FMapRenderCurrentLineColour(FRenderColour)
         FMapRenderCurrentLine(APositionX, APositionY, APositionX, FRenderCellBottom)                            
      end   
   end   
   if (ARoom.ExitEast > -1) and (ARoom.ExitWest > -1) and (ARoom.ExitEastType == ARoom.ExitWestType) then 
      if ARoom.ExitEastType == 2 then -- door    
            FRenderColour = UIMapExitTypeColour[2]
         else
            FRenderColour = FColour 
         end    
         if HoverStreet then FRenderColour = 0xFFFFFF end         
         FMapRenderCurrentLineColour(FRenderColour)
      FMapRenderCurrentLine(FRenderCellLeft, APositionY, FRenderCellRight, APositionY)                         
   else
      if ARoom.ExitEast > -1 then
         if ARoom.ExitEastType == 2 then -- door    
            FRenderColour = UIMapExitTypeColour[2]
         else
            FRenderColour = FColour 
         end    
         if HoverStreet then FRenderColour = 0xFFFFFF end         
         FMapRenderCurrentLineColour(FRenderColour)
         FMapRenderCurrentLine(APositionX, APositionY, FRenderCellRight, APositionY)                                    
      end
        if ARoom.ExitWest > -1 then
         if ARoom.ExitWestType == 2 then -- door    
            FRenderColour = UIMapExitTypeColour[2]
         else
            FRenderColour = FColour 
         end    
         if HoverStreet then FRenderColour = 0xFFFFFF end         
         FMapRenderCurrentLineColour(FRenderColour)
         FMapRenderCurrentLine(APositionX, APositionY, FRenderCellLeft, APositionY)             
      end   
   end          
   if (ARoom.ExitNorthEast > -1) and (ARoom.ExitSouthWest > -1) and (ARoom.ExitNorthEastType == ARoom.ExitSouthWestType) then 
      if ARoom.ExitNorthEastType == 2 then -- door    
            FRenderColour = UIMapExitTypeColour[2]
         else
            FRenderColour = FColour 
         end    
         if HoverStreet then FRenderColour = 0xFFFFFF end         
         FMapRenderCurrentLineColour(FRenderColour)
      FMapRenderCurrentLine(FRenderCellLeft, FRenderCellBottom, FRenderCellRight, FRenderCellTop)                              
   else
      if ARoom.ExitNorthEast > -1 then
         if ARoom.ExitNorthEastType == 2 then -- door    
            FRenderColour = UIMapExitTypeColour[2]
         else
            FRenderColour = FColour 
         end    
         if HoverStreet then FRenderColour = 0xFFFFFF end         
         FMapRenderCurrentLineColour(FRenderColour)
         FMapRenderCurrentLine(APositionX, APositionY, FRenderCellRight, FRenderCellTop)                                      
      end             
      if ARoom.ExitSouthWest > -1 then
         if ARoom.ExitSouthWestType == 2 then -- door    
            FRenderColour = UIMapExitTypeColour[2]
         else
            FRenderColour = FColour 
         end    
         if HoverStreet then FRenderColour = 0xFFFFFF end         
         FMapRenderCurrentLineColour(FRenderColour)
         FMapRenderCurrentLine(APositionX, APositionY, FRenderCellLeft, FRenderCellBottom)               
      end   
   end   
   if (ARoom.ExitNorthWest > -1) and (ARoom.ExitSouthEast > -1) and (ARoom.ExitNorthWestType == ARoom.ExitSouthEastType) then 
         if ARoom.ExitNorthWestType == 2 then -- door    
            FRenderColour = UIMapExitTypeColour[2]
         else
            FRenderColour = FColour 
         end    
         if HoverStreet then FRenderColour = 0xFFFFFF end         
         FMapRenderCurrentLineColour(FRenderColour)
      FMapRenderCurrentLine(FRenderCellRight, FRenderCellBottom, FRenderCellLeft, FRenderCellTop)                         
   else
      if ARoom.ExitNorthWest > -1 then
      if ARoom.ExitNorthWestType == 2 then -- door    
            FRenderColour = UIMapExitTypeColour[2]
         else
            FRenderColour = FColour 
         end    
         if HoverStreet then FRenderColour = 0xFFFFFF end         
         FMapRenderCurrentLineColour(FRenderColour)
         FMapRenderCurrentLine(APositionX, APositionY, FRenderCellLeft, FRenderCellTop)              
      end
      if ARoom.ExitSouthEast > -1 then
         if ARoom.ExitSouthEastType == 2 then -- door    
            FRenderColour = UIMapExitTypeColour[2]
         else
            FRenderColour = FColour 
         end    
         if HoverStreet then FRenderColour = 0xFFFFFF end         
         FMapRenderCurrentLineColour(FRenderColour)
         FMapRenderCurrentLine(APositionX, APositionY, FRenderCellRight, FRenderCellBottom)               
      end         
   end         
end

--------------------------------------------------------------------------------
local function UIWindowMapRenderCacheRoom(ARoom, APositionX, APositionY)   
   if (FMapRenderCurrentCellSize) > 5 then
      --dont render rooms if pixel size is less than N      
            
      FRoomRenderPosLeft = APositionX-(FMapRenderCurrentCellSizeDiv2)
      FRoomRenderPosTop = APositionY-(FMapRenderCurrentCellSizeDiv2)
      FRoomRenderPosRight = APositionX+(FMapRenderCurrentCellSizeDiv2)
      FRoomRenderPosBottom = APositionY+(FMapRenderCurrentCellSizeDiv2)
      if ((FRoomRenderPosRight-1) > FViewportLeft) and ((FRoomRenderPosBottom-1) > FViewportTop) and (FRoomRenderPosLeft < FViewportRight) and (FRoomRenderPosTop < FViewportBottom) then                                               
      WindowCircleOp(FMapRenderCurrentMushWindow,1, FRoomRenderPosLeft, FRoomRenderPosTop, FRoomRenderPosRight, FRoomRenderPosBottom, ColourRoomOutline, 0, 1, FRoomRenderColourRoom, 0) -- circle
      end
   end                  
end

--------------------------------------------------------------------------------
local function UIWindowMapRenderCacheCell(AChar, ACharColour, APositionX, APositionY)
   
   local AColourID = 0
   
   if ACharColour == nil then AColourID = 1 elseif ACharColour == "" then AColourID = 1
   else
      AColourID = string.byte(ACharColour)-47  --starts at '0' 1 used for split
   end
               
   FRenderColourCell = UIMapColours[AColourID]
   
   FMapRenderCurrentRectColour(FRenderColourCell)
   FMapRenderCurrentRect(APositionX-FMapRenderCurrentCellSizeDiv2, APositionY-FMapRenderCurrentCellSizeDiv2, APositionX+FMapRenderCurrentCellSizeDiv2, APositionY+FMapRenderCurrentCellSizeDiv2)      
end


--------------------------------------------------------------------------------  
function UIMapRenderCacheRooms(ARegion, ARenderScale, ARegionLeft, ARegionTop, ARegionRight, ARegionBottom, ARegionWidth, ARegionHeight)
   
   
   local ACellSize = 1
   local ACellSizeDiv2 = 0.5
   
   local AZ = 0
   local RoomRenderCount = 0
   
   local AScale = ARenderScale
   local APositionScale = 1   
   
   --rescale terrain regions
   if ARegion.RegionStride == 1 then
      AScale = AScale / 2
      APositionScale = 2
   end
      
   --setup rendering parameters
   FMapRenderCurrentCellSize = (ACellSize * AScale)  
   FMapRenderCurrentCellSizeDiv2 = (ACellSizeDiv2 * AScale)           
   ASectors = ARegion.RegionSectorsXYZ   
   ASector = {}   
   --A Linewidth of 0 is faster than a linewidth of 1
   FMapRenderCurrentLineWidth = FMapRenderCurrentCellSize / 3
   if FMapRenderCurrentLineWidth < 0 then FMapRenderCurrentLineWidth = 0 end
   FMapRenderSurface.LineWidth(FMapRenderCurrentLineWidth)   
   
   local ARegionOffsetX = (((ARegionLeft * UIMapSectorSize)*APositionScale) * FMapRenderCurrentCellSize)-FMapRenderCurrentCellSize
   local ARegionOffsetY = (((ARegionTop * UIMapSectorSize)*APositionScale) * FMapRenderCurrentCellSize)-FMapRenderCurrentCellSize 
   
   
                
   --Setup Colours for this Region
   FRoomRenderColourRoom = UIMapColours[ARegion.RegionColour]   
   FRoomRenderColourStreet = UIMapColours[ARegion.RegionColour]
   FRenderColourCell = 0xFFFFFF
                              
   if ASectors then                 
      for AX = ARegionLeft, ARegionRight do               
         for AY = ARegionTop, ARegionBottom do
                                                      
            ASector = ASectors[AX..":"..AY..":"..AZ]
                          
            if ASector == nil then               
            else                                 
               for _,ARoom in pairs(ASector.SectorRoomsXYZ) do             
                  if ARoom then                        
                                                                                                                              
                     FRenderCellMiddleX = ((ARoom.RoomPositionX*APositionScale) * FMapRenderCurrentCellSize) 
                     FRenderCellMiddleY = ((ARoom.RoomPositionY*APositionScale) * FMapRenderCurrentCellSize)                     
                     --center of image
                     --FRenderCellMiddleX = FRenderCellMiddleX + (FMapRenderSurfaceBuffer.Width / 2)
                     --FRenderCellMiddleY = FRenderCellMiddleY + (FMapRenderSurfaceBuffer.Height / 2)
                     
                     FRenderCellMiddleX = FRenderCellMiddleX - ARegionOffsetX
                     FRenderCellMiddleY = FRenderCellMiddleY - ARegionOffsetY
                     
                     --add the width of the lines so that thick lines don't 'pop' into view                       
                     FRoomRenderPosLeft = FRenderCellMiddleX-(FMapRenderCurrentCellSize+FMapRenderCurrentLineWidth)
                     FRoomRenderPosTop = FRenderCellMiddleY-(FMapRenderCurrentCellSize+FMapRenderCurrentLineWidth)
                     FRoomRenderPosRight = FRenderCellMiddleX+(FMapRenderCurrentCellSize+FMapRenderCurrentLineWidth)
                     FRoomRenderPosBottom = FRenderCellMiddleY+(FMapRenderCurrentCellSize+FMapRenderCurrentLineWidth)                       
                         
                     --if (FRoomRenderPosRight >= FViewportLeft) and (FRoomRenderPosBottom >= FViewportTop) and (FRoomRenderPosLeft <= FViewportRight) and (FRoomRenderPosTop <= FViewportBottom) then
                        
                        FRenderCellLeft = FRenderCellMiddleX-(FMapRenderCurrentCellSize+1)
                        FRenderCellTop = FRenderCellMiddleY-(FMapRenderCurrentCellSize+1)
                        FRenderCellRight = FRenderCellMiddleX+(FMapRenderCurrentCellSize+1)
                        FRenderCellBottom = FRenderCellMiddleY+(FMapRenderCurrentCellSize+1)
                                                                        
                        UIWindowMapRenderCacheRoomStreet(ARoom, FRenderCellMiddleX, FRenderCellMiddleY)                                                                          
                        UIWindowMapRenderCacheRoom(ARoom, FRenderCellMiddleX, FRenderCellMiddleY)
                                                
                        RoomRenderCount = RoomRenderCount + 1                                    
                     --end                           
                  end
               end                           
            end        
         end
      end      
   end  
end

--------------------------------------------------------------------------------  
function UIMapRenderCacheRoomsBuffer(ARegion, AParentScale, APositionX, APositionY)
     
      --Render Region to SurfaceBuffer
   if (ARegion.RegionImage==nil) then
   
      FMapRenderSurfaceBuffer.Clear() 
   
      --Setup Bounds/Scale
      local FRegionLeft = ARegion.RegionSectorLeft
      local FRegionTop = ARegion.RegionSectorTop
      local FRegionRight = ARegion.RegionSectorRight  
      local FRegionBottom = ARegion.RegionSectorBottom      
      local FRegionWidth = ((ARegion.RegionSectorRight - ARegion.RegionSectorLeft)+1) * UIMapSectorSize
      local FRegionHeight = ((ARegion.RegionSectorBottom - ARegion.RegionSectorTop)+1) * UIMapSectorSize
                 
      local FRegionScale = math.min(FMapRenderSurfaceBuffer.Height / FRegionHeight, FMapRenderSurfaceBuffer.Width / FRegionWidth)
         
      FMapRenderCurrentMushWindow = FMapRenderSurfaceBufferMushWindow      
      FMapRenderCurrentRectColour = FMapRenderSurfaceBuffer.RectColour
      FMapRenderCurrentLineColour = FMapRenderSurfaceBuffer.LineColour 
      FMapRenderCurrentLine = FMapRenderSurfaceBuffer.Line
      FMapRenderCurrentRect = FMapRenderSurfaceBuffer.Rect
            
      UIMapRenderCacheRooms(ARegion, FRegionScale, FRegionLeft, FRegionTop, FRegionRight, FRegionBottom, FRegionWidth, FRegionHeight)
      
      ARegion.RegionImage = 1      
      
      --Render Buffer to disk
      FMapRenderSurfaceBuffer.ImageSave("c:/dev/discui/cache/" .. ARegion.RegionName .. ".png")                                   
   end

   
   --Create RegionImage from SurfaceBuffer
   if (ARegion.RegionImage==nil) then
      --ARegion.RegionImage = UIImageCreate(FMapRenderSurface, FMapRenderSurfaceBuffer)
      ARegion.RegionImage.Scale = 1.0  
      ARegion.RegionImage.RegionPositionX = 0
      ARegion.RegionImage.RegionPositionY = 0       
   end
         
end


--------------------------------------------------------------------------------  
function UIMapRenderCacheCells(ARegion, ARenderScale, ARegionLeft, ARegionTop, ARegionRight, ARegionBottom, ARegionWidth, ARegionHeight)

   
   local ACellSize = 1
   local ACellSizeDiv2 = 0.5
   
   local FPositionOffsetX = 0
   local FPositionOffsetY = 0
   
   local AZ = 0
   local CellRenderCount = 0
   
   local AScale = ARenderScale
   local APositionScale = 1   
   
   --rescale terrain regions
   if ARegion.RegionParentScale == 2 and ARegion.RegionType == 3 then
      AScale = (ARenderScale*1)
      APositionScale = 2
   end
   
   
    --setup rendering parameters
   FMapRenderCurrentCellSize = (ACellSize * AScale)  
   FMapRenderCurrentCellSizeDiv2 = (ACellSizeDiv2 * AScale)           
             
   local ASectors = ARegion.RegionSectorsXYZ   
   local ASector = nil   

   --Setup Colours for this Region       
   local FRenderColourCell = 0xFFFFFF
                            
   local AStr = ""
   local AStrColour = ""
   local AChar = ""
   local ACharColour = ""
        
   if ASectors then           
      for AX = ARegionLeft, ARegionRight do               
         for AY = ARegionTop, ARegionBottom do  
            ASector = ASectors[AX..":"..AY..":"..AZ]
            if ASector then
               for ASectorPosY = 1, FUIMapSectorSize do                  
                  
                  --get source string for this cell
                  AStr = ASector.SectorData[ASectorPosY]
                  AStrColour = ASector.SectorDataColour[ASectorPosY]
                  if (AStrColour) and (trim(AStrColour) ~= "") then
                  
                  
                     FRenderCellMiddleY = FPositionOffsetY+((ASector.CellTop + ASectorPosY-1) * FMapRenderCurrentCellSize)
                     
                     --center of image
                     FRenderCellMiddleY = FRenderCellMiddleY + (FMapRenderSurfaceBuffer.Height / 2)
                                                 
                     FRoomRenderPosTop = FRenderCellMiddleY-FMapRenderCurrentCellSizeDiv2               
                     FRoomRenderPosBottom = FRoomRenderPosTop + FMapRenderCurrentCellSize
                     
                     --[[
                     --line can be drawn as one block                     
                     if StringIsRepeatedChar(string.sub(AStrColour,(#AStrColour/4)*1,(#AStrColour/4)*2)," ") then                     
                     elseif StringIsRepeatedChar(string.sub(AStrColour,(#AStrColour/4)*1,(#AStrColour/4)*2)) then                                                                                           
                        FRoomRenderPosLeft = FPositionOffsetX+((ASector.CellLeft+(#AStrColour/4)*1)*FMapRenderCurrentCellSize)                                                              
                        FRoomRenderPosRight = FPositionOffsetX+((ASector.CellLeft+(#AStrColour/4)*2)*FMapRenderCurrentCellSize)                               
                        ACharColour = string_sub(AStrColour,(#AStrColour/4)*1,(#AStrColour/4)*1) --get source char for this cell   
                        FRenderColourCell = UIMapColours[string_byte(ACharColour)-47] --starts at '0' 1 used for split                           
                        FMapRenderCurrentRectColour(FRenderColourCell)
                        FMapRenderCurrentRect(FRoomRenderPosLeft, FRoomRenderPosTop, FRoomRenderPosRight, FRoomRenderPosBottom)
                     end
                     --]]  
                            
                     if (FRoomRenderPosBottom > FViewportTop+1) and (FRoomRenderPosTop < FViewportBottom-1) then                        
                        for ASectorPosX = 1, FUIMapSectorSize do
                          
                           FRenderCellMiddleX = FPositionOffsetX+(
                           (ASector.CellLeft + ASectorPosX-1)--*ARegion.RegionStride) 
                           * FMapRenderCurrentCellSize)
                           
                           --center of image
                           FRenderCellMiddleX = FRenderCellMiddleX + (FMapRenderSurfaceBuffer.Width / 2)
                     
                            
                                                                          
                           FRoomRenderPosLeft = FRenderCellMiddleX-FMapRenderCurrentCellSizeDiv2                        
                           FRoomRenderPosRight = FRoomRenderPosLeft + FMapRenderCurrentCellSize 
                                                                    
                           if (FRoomRenderPosRight > FViewportLeft+1) and (FRoomRenderPosLeft < FViewportRight-1)                               
                           then                                                                                                                                                                                                                                                                                          
                              --AChar = string_sub(AStr,ASectorPosX,ASectorPosX) --get source char for this cell   
                              ACharColour = string_sub(AStrColour,ASectorPosX,ASectorPosX) --get source colour for this cell
                              --if (AChar ~= " ") then                                                         
                              if (ACharColour ~= " ") then                                                                                                                                                
                                 UIWindowMapRenderCacheCell(AChar,ACharColour,FRenderCellMiddleX,FRenderCellMiddleY) --render this cell
                                 CellRenderCount = CellRenderCount + 1            
                              end                              
                           end                        
                        end                                             
                     end                               
                  end                     
               end                                       
            end --if ASector then                   
         end --for AY = ASectorTop, ASectorBottom do    
      end --for AX = ASectorLeft, ASectorRight do                          
   end   
end





--------------------------------------------------------------------------------  
function UIMapRenderCacheCellsBuffer(ARegion, AParentScale, APositionX, APositionY)

      --Render Region to SurfaceBuffer
   if (ARegion.RegionImage==nil) then
   
      FMapRenderSurfaceBuffer.Clear() 
   
      --Setup Bounds/Scale
      local FRegionLeft = ARegion.RegionSectorLeft
      local FRegionTop = ARegion.RegionSectorTop
      local FRegionRight = ARegion.RegionSectorRight  
      local FRegionBottom = ARegion.RegionSectorBottom      
      local FRegionWidth = (ARegion.RegionSectorRight - ARegion.RegionSectorLeft) * UIMapSectorSize
      local FRegionHeight = (ARegion.RegionSectorBottom - ARegion.RegionSectorTop) * UIMapSectorSize           
      local FRegionScale = 1 --FMapRenderSurfaceBuffer.Height / FRegionHeight
         
      FMapRenderCurrentMushWindow = FMapRenderSurfaceBufferMushWindow      
      FMapRenderCurrentRectColour = FMapRenderSurfaceBuffer.RectColour
      FMapRenderCurrentLineColour = FMapRenderSurfaceBuffer.LineColour 
      FMapRenderCurrentLine = FMapRenderSurfaceBuffer.Line
      FMapRenderCurrentRect = FMapRenderSurfaceBuffer.Rect
            
      UIMapRenderCacheCells(ARegion, FRegionScale, FRegionLeft, FRegionTop, FRegionRight, FRegionBottom, FRegionWidth, FRegionHeight)
      
      ARegion.RegionImage = 1      
      
      --Render Buffer to disk
      FMapRenderSurfaceBuffer.ImageSave("c:/dev/discui/cache/" .. ARegion.RegionName .. ".png")                                   
   end

   
   --Create RegionImage from SurfaceBuffer
   if (ARegion.RegionImage==nil) then
      --ARegion.RegionImage = UIImageCreate(FMapRenderSurface, FMapRenderSurfaceBuffer)
      ARegion.RegionImage.Scale = 1.0  
      ARegion.RegionImage.RegionPositionX = 0
      ARegion.RegionImage.RegionPositionY = 0       
   end

end

--------------------------------------------------------------------------------
function UIMapRenderCacheSetup(
   ASurface,
   ASurfaceBuffer,   
   AMapBuffer,     
   ARegion, 
   ADelta, 
   AViewportMiddleX, 
   AViewportMiddleY, 
   AViewportLeft, 
   AViewportTop,
   AViewportRight,
   AViewportBottom)
   
      
   FMapRenderSurface = ASurface
   FMapRenderSurfaceMushWindow = ASurface.MushWindow
   
   FMapRenderSurfaceBuffer = ASurfaceBuffer
   FMapRenderSurfaceBufferMushWindow = ASurfaceBuffer.MushWindow
         
   FMapRenderMapBuffer = AMapBuffer
            
   
   FMapRenderCurrentMushWindow = FMapRenderSurfaceMushWindow   
   FMapRenderCurrentRectColour = FMapRenderSurface.RectColour
   FMapRenderCurrentLineColour = FMapRenderSurface.LineColour 
   FMapRenderCurrentLine = FMapRenderSurface.Line
   FMapRenderCurrentRect = FMapRenderSurface.Rect
   
   FMapRenderDelta = ADelta    
   FViewportMiddleX = AViewportMiddleX 
   FViewportMiddleY = AViewportMiddleY
   FViewportLeft = 0
   FViewportTop = 0 
   FViewportRight = FMapRenderSurfaceBuffer.Width
   FViewportBottom = FMapRenderSurfaceBuffer.Height
   FViewportWidth = FMapRenderSurfaceBuffer.Width
   FViewportHeight = FMapRenderSurfaceBuffer.Height
   
   
   if FRenderColourCell == nil then
      FRenderColourCell = 0x0000FF
   end
end

