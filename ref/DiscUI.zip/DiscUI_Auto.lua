--------------------------------------------------------------------------------
--//DiscUI Auto
--------------------------------------------------------------------------------

--Enable/Disable DiscUI Auto
local AutoEnabled = false

-- 0 = idle mode
-- 1 = XP command mode
-- 2 = XP followup mode
-- 3 = Simulate mode
-- 4 = Mission mode

local AutoMode = 0

local IdleCommandLastTick = 0
local IdleGPThreshold = 406
local IdleGPThresholdRoot = 405
local IdleCommands = {'i1','i2','pray','i3','i4','pray','i5','i1','pray','i2','i3','pray','i4','i5','pray'}
local IdleCommandCount = 0
local IdleCommandCurrent = 1


local IdleCommandFollowUpLastTick = 0
local IdleCommandFollowUpCommands = {'', '', ''}
local IdleCommandFollowUpCommandsCount = 0
local IdleCommandFollowUpCurrent = 1
local IdleCommandFollowUpCountMax = 3
local IdleCommandFollowUpFlagDelay = 26000
local IdleCommandFollowUpFlagDelayRoot = 10000


local IdleSimulateLastTick = 0
local IdleSimulateFlagDelay = (1000*10)
local IdleSimulateFlagDelayRoot = (1000 * 30)
local IdleSimulateActions = {	
	{'score'},
   {'score'},   
	{'score'},   
	{'score'},   	
	{'score stats'},
	{'gp'},	
	{'sk.pi', '[DELAY]', 'sk.fi'},   
	{'sk.ad'},
   {'sk.ma'},
	{'rituals'},	
	{'finger trow'},
	{'ex trow'},	
	{'ex beads'},
	{'i'},	
	{'l'},	
	{'l'},	
	{'l'},		
	{'m'},
	{'ab'},
	{'ab'},
	{'ab'},			
	--{'who'},
   --{'who'},
   --{'who'},
   --{'who'},
   {'who sek'},   
	{'who sek'},   
	{'who sek'},   
	{'who sek'},   	
	{'remove yellow ring', '[DELAY]', '[DELAY]', '[DELAY]', '[DELAY]', 'wear yellow ring'},    
   --{'gmp', 'mb', '[DELAY]', 'pmp'},
   {'open pack', 'ex pack', '[DELAY]', '[DELAY]', 'close pack'},
	--{'unhold beads', '[DELAY]', 'score stats', '[DELAY]', 'hold beads', '[DELAY]', 'score stats'},
	--A few spells for fun   
	--{'ls', '[DELAY]', 'l'},  	
	--{'da trow'},  	
	--{'pl'},
	--{'mas'},
	--{'ab'},
	--A few random CRs for fucks sake
	{''},
	{''},
	{''},
	{''},
	{''},
	{''},
	{''},
	}
local IdleSimulateActionCount = 0 
local IdleSimulateActionCurrent = 1

local IdleSimulateActionSubCount = 1
local IdleSimulateActionSubCurrent = 1

local IdleSimulateActionSubLastTick = 0
local IdleSimulateActionSubFlagDelay = (1000*2)
local IdleSimulateActionSubFlagDelayRoot = (1333)

--Mission Simulation
local IdleMissions = {	
	--{'west', 'east'},
   --{'west', 'north', 'south', 'east'},
	{'dh.bank', '[DELAY]', '[DELAY]', 'wf', 'balance', '[DELAY]', '[DELAY]', '[DELAY]', 'dh.sek2', '[DELAY]', 'wf', 'kneel at altar', 'l'},
	}

local IdleMissionLastTick=0 --last time we went on a mission
local IdleMissionCount=0
local IdleMissionCurrent=1
local IdleMissionDelayRoot = (1000 * 15)
local IdleMissionDelay = (666)


local IdleMissionObjectiveLastTick=0 --last time we tried to achieve an objective
local IdleMissionObjectiveCount=0
local IdleMissionObjectiveCurrent=1

local IdleMissionObjectiveDelayRoot=(3666)
local IdleMissionObjectiveDelay=(3666)

	
local CBackground = "#121212"         
local CMessage = "#FF4444"   
   
 
--------------------------------------------------------------------------------
 function tablelength(T)
  local count = 0
  for _ in pairs(T) do count = count + 1 end
  return count
end
--------------------------------------------------------------------------------
function AutoInit()

   AutoMode = 0
   
   IdleCommandCount = tablelength(IdleCommands) 
	IdleCommandCurrent = 1
	
	IdleCommandFollowUpCommandsCount = tablelength(IdleCommandFollowUpCommands)
	IdleCommandFollowUpCurrent = 1
	  
   IdleCommandLastTick = UIMushGetTimeMS()
   IdleGPThreshold = IdleGPThresholdRoot + (math.random(20))     
   
   IdleSimulateFlagDelay = IdleSimulateFlagDelayRoot + math.random((1000 * 30))      
   IdleSimulateLastTick = UIMushGetTimeMS() 
	
	--Add Jitter to Simulate Action Sub Delay         
   IdleSimulateActionSubFlagDelay = IdleSimulateActionSubFlagDelayRoot + math.random((1000))   
   IdleSimulateActionSubLastTick = UIMushGetTimeMS()
   
   IdleSimulateActionCount = tablelength(IdleSimulateActions)
	IdleSimulateActionCurrent = 1   
	IdleSimulateActionSubCount = tablelength(IdleSimulateActions[IdleSimulateActionCurrent])
	IdleSimulateActionSubCurrent = 1	
	
	IdleMissionLastTick = UIMushGetTimeMS() --last time we went on a mission
	IdleMissionCount = tablelength(IdleMissions)
	IdleMissionCurrent = 1
	
	--Add Jitter To Mission Delay
	IdleMissionDelay = IdleMissionDelayRoot + math.random((15000))   
	
	IdleMissionObjectiveLastTick = UIMushGetTimeMS() --last time we tried to achieve an objective
	IdleMissionObjectiveCount = tablelength(IdleMissions[IdleMissionCurrent])
	IdleMissionObjectiveCurrent = 1
	
	--Add Jitter To Objective Delay
	IdleMissionObjectiveDelay = IdleMissionObjectiveDelayRoot + math.random((1500))   
	
	end   
--------------------------------------------------------------------------------
function AutoToggle()

   if (AutoEnabled == false) then
      AutoEnabled = true
      AutoInit()
   else
      AutoEnabled = false
   end
   return AutoEnabled
end

--------------------------------------------------------------------------------
function AutoDoIdleCommand()     
	if (AutoMode == 1) then		  
		IdleCommandLastTick = UIMushGetTimeMS()
	   
	   --Add jitter to Command FollowUp
	   IdleCommandFollowUpLastTick = UIMushGetTimeMS()
	   IdleCommandFollowUpFlagDelay = IdleCommandFollowUpFlagDelayRoot + (13000-math.random(26000))
	   
	   -- randomize number of Command FollowUps
	   local ARnd = math.random(2)
	   if ARnd == 1 then
	      IdleCommandFollowUpCountMax = 3
	   else
	      IdleCommandFollowUpCountMax = 2
	   end
	    
	   -- issue the XP command   
	   ColourNote(CMessage, CBackground, "DiscUI Auto Command : '" .. IdleCommands[IdleCommandCurrent] .. "'")   
	   world.Send(IdleCommands[IdleCommandCurrent])
	   
		--Move the index to the next XP command               
	   IdleCommandCurrent = IdleCommandCurrent + 1
	   if (IdleCommandCurrent > IdleCommandCount) then IdleCommandCurrent = 1 end    
		
		--Add Jitter to XPCommand GP Threshold
		IdleGPThreshold = IdleGPThresholdRoot + (math.random(20))    		              
	
		AutoMode = 2 --Switch to FollowUp Mode	
		ColourNote(CMessage, CBackground, "DiscUI (AutoDoIdleCommand) : Switched to XP FollowUp Mode")   
	end
end

--------------------------------------------------------------------------------
function AutoDoIdleCommandFollowUp()
   if (AutoMode == 2) then
      local CurrentTick = UIMushGetTimeMS()
           
      --world.Note(CurrentTick-IdleCommandLastTick)
      if (CurrentTick-IdleCommandFollowUpLastTick) > IdleCommandFollowUpFlagDelay then
      
         --world.Note(CurrentTick-IdleCommandLastTick)
         ColourNote(CMessage, CBackground, "DiscUI (AutoDoIdleCommandFollowUp) : Follow Up No : " ..IdleCommandFollowUpCurrent)
         
         local ACommandIndex = math.random(IdleCommandFollowUpCommandsCount)
         local ACommand = IdleCommandFollowUpCommands[ACommandIndex]       
         world.Send(ACommand)
                  
         IdleCommandFollowUpLastTick = UIMushGetTimeMS()
         
         IdleCommandFollowUpCurrent = IdleCommandFollowUpCurrent + 1
         if IdleCommandFollowUpCurrent > IdleCommandFollowUpCountMax then
         
         	IdleCommandFollowUpCurrent = 1         
            AutoMode = 0 --Switch to Idle Mode
            ColourNote(CMessage, CBackground, "DiscUI (AutoDoIdleCommandFollowUp) : Switched to Idle Mode")   
         end
      end    
   end
end

--------------------------------------------------------------------------------
function AutoDoIdleSimulate()
   if (AutoMode == 3) then
	
		--ColourNote(CMessage, CBackground, "DiscUI (AutoDoIdleSimulate) : Called")
	   	
		local CurrentTick = UIMushGetTimeMS()         
      
		if ((CurrentTick-IdleSimulateActionSubLastTick) > IdleSimulateActionSubFlagDelay) and        
			(IdleSimulateActionSubCurrent <= IdleSimulateActionSubCount) then
		                                                     
			--Add Jitter to Simulate Action Sub Delay         
         IdleSimulateActionSubFlagDelay = IdleSimulateActionSubFlagDelayRoot + math.random((1000))   
      	IdleSimulateActionSubLastTick = UIMushGetTimeMS()

			--Issue thge Sub Action (Skip [DELAY]))
			if not (IdleSimulateActions[IdleSimulateActionCurrent][IdleSimulateActionSubCurrent] == "[DELAY]") then
				ColourNote(CMessage, CBackground, "DiscUI (AutoDoIdleSimulate) : Issue Sub-Action '" .. IdleSimulateActions[IdleSimulateActionCurrent][IdleSimulateActionSubCurrent] .. "' (Jitter:" .. IdleSimulateActionSubFlagDelay .. ")")							
				world.Send(IdleSimulateActions[IdleSimulateActionCurrent][IdleSimulateActionSubCurrent])
			else
				ColourNote(CMessage, CBackground, "DiscUI (AutoDoIdleSimulate) : Delaying (Jitter:" .. IdleSimulateActionSubFlagDelay .. ")")											
			end
						
			IdleSimulateActionSubCurrent = IdleSimulateActionSubCurrent + 1
		end
										              	     
     	--Move to next Action
      if IdleSimulateActionSubCurrent > IdleSimulateActionSubCount then
      
         --Select Random Action
      	IdleSimulateActionCurrent = math.random(IdleSimulateActionCount)
         --Itterate
			--IdleSimulateActionCurrent = IdleSimulateActionCurrent + 1			
      	--if IdleSimulateActionCurrent > IdleSimulateActionCount then IdleSimulateActionCurrent = 1 end
      	
      	--Get Sub Action Count
			IdleSimulateActionSubCount = tablelength(IdleSimulateActions[IdleSimulateActionCurrent])
			IdleSimulateActionSubCurrent = 1
			
			--Add Jitter to Simulate Action Delay         
         IdleSimulateFlagDelay = IdleSimulateFlagDelayRoot + math.random((1000 * 30))   
      	
			--Add Jitter to Simulate Action Sub Delay         
         IdleSimulateActionSubFlagDelay = IdleSimulateActionSubFlagDelayRoot + math.random((1000))   
      	IdleSimulateActionSubLastTick = UIMushGetTimeMS()

			--Reset Simulate Tick
			IdleSimulateLastTick = UIMushGetTimeMS()       	
			
			AutoMode = 0 --Switch to Idle Mode 
			ColourNote(CMessage, CBackground, "DiscUI (AutoDoIdleSimulate) : Switched to Idle Mode")   
		end				  
   end
end

function AutoDoMission()
	if (AutoMode == 4) then	
		--ColourNote(CMessage, CBackground, "DiscUI (AutoDoMission) : Called")
		
		--Perform current objective
		if ((UIMushGetTimeMS()-IdleMissionObjectiveLastTick) > IdleMissionObjectiveDelay) and        
				(IdleMissionObjectiveCurrent <= IdleMissionObjectiveCount) then      
		
			
			if not (IdleMissions[IdleMissionCurrent][IdleMissionObjectiveCurrent] == "[DELAY]") then
				ColourNote(CMessage, CBackground, "DiscUI (AutoDoMission) : Attempt Objective '" .. IdleMissions[IdleMissionCurrent][IdleMissionObjectiveCurrent] .. "' (Jitter:" .. IdleMissionObjectiveDelay .. ")")							
				world.Send(IdleMissions[IdleMissionCurrent][IdleMissionObjectiveCurrent])
			else
				ColourNote(CMessage, CBackground, "DiscUI (AutoDoMission) : Caution (Jitter:" .. IdleMissionObjectiveDelay .. ")")											
			end
			
		
			--Add Jitter To Objective Delay
			IdleMissionObjectiveDelay = IdleMissionObjectiveDelayRoot + math.random((3500))   
	      IdleMissionObjectiveLastTick = UIMushGetTimeMS()		
			--Move to next objective
			IdleMissionObjectiveCurrent = IdleMissionObjectiveCurrent + 1			
		end 
		
		--If all Objectives are Complete then move onto the next mission
      if IdleMissionObjectiveCurrent > IdleMissionObjectiveCount then   
         --Select a Random Mission
      	IdleMissionCurrent = math.random(IdleMissionCount)
         --Select Next Mission
			--IdleMissionCurrent = IdleMissionCurrent + 1			
      	--if IdleMissionCurrent > IdleMissionCount then IdleMissionCurrent = 1 end
      	
      	--Add Jitter To Mission Schedule
			IdleMissionDelay = IdleMissionDelayRoot + math.random((15000))   
	            	           	
      	--Get Objective Count
			IdleMissionObjectiveCount = tablelength(IdleMissions[IdleMissionCurrent])
			IdleMissionObjectiveCurrent = 1
									
			--Add Jitter To Objective Delay
			IdleMissionObjectiveDelay = IdleMissionObjectiveDelayRoot + math.random((3500))   
	      IdleMissionObjectiveLastTick = UIMushGetTimeMS()		

			--Reset Simulate Tick
			IdleMissionLastTick = UIMushGetTimeMS()       	
			
			AutoMode = 0 --Switch to Idle Mode 
			ColourNote(CMessage, CBackground, "DiscUI (AutoDoMission) : Mission Complete. Switching to Idle Mode")   
		end	
		                                                            
	end
end

--------------------------------------------------------------------------------
function AutoUpdateSlow()
   if AutoEnabled then
   	--Slow updates for 'top level' mode stuff   
   	
      --ColourNote(CMessage, CBackground, "DiscUI (AutoUpdateSlow) : Called")
      
      --Idle
      if (AutoMode == 0) then 
      
         --XP Command Mode
         if (UICharacter.GuildPoints > IdleGPThreshold) then                                 
				AutoMode = 1 --Switch to XP Command Mode 
				ColourNote(CMessage, CBackground, "DiscUI (AutoUpdateSlow) : Switched to XP Command Mode (XPJitter:" .. IdleGPThreshold .. ")")				         
         end 
         
         --Simulate Mode
         local CurrentTick = UIMushGetTimeMS()         
         if ((CurrentTick-IdleSimulateLastTick) > IdleSimulateFlagDelay) then 								
				AutoMode = 3                    			
				ColourNote(CMessage, CBackground, "DiscUI (AutoUpdateSlow) : Switched to Simulate Mode (Jitter:" .. IdleSimulateFlagDelay .. ")")	      
			end  
			
			--Mission Mode
         --CurrentTick = UIMushGetTimeMS()         
         --if ((CurrentTick-IdleMissionLastTick) > IdleMissionDelay) then 								
			--	AutoMode = 4                    			
			--	ColourNote(CMessage, CBackground, "DiscUI (AutoUpdateSlow) : Commencing Mission (Jitter:" .. IdleSimulateFlagDelay .. ")")	      
			--end  
			   			       		
      end  
		      
   end
end

--------------------------------------------------------------------------------
function AutoUpdateMedium()
   if AutoEnabled then
      --ColourNote(CMessage, CBackground, "DiscUI (AutoUpdateMedium) : Called")
                    
      --XP Command
      if (AutoMode == 1) then
			--Handle XP FollowUp mode
			AutoDoIdleCommand() 
		end
          
		--XP Command FollowUp
		if (AutoMode == 2) then
			--Handle XP FollowUp mode
			AutoDoIdleCommandFollowUp()
		end
                		
   end
end

function AutoUpdateFast()
   if AutoEnabled then
     --ColourNote(CMessage, CBackground, "DiscUI (AutoUpdateFast) : Called")
     
     --Simulate Command
		if (AutoMode == 3) then
			--Handle XP FollowUp mode
			AutoDoIdleSimulate()
		end
	
		--Perform Mission
		if (AutoMode == 4) then
			--Handle Mission Mode
			AutoDoMission()
		end
		
   end
end