
--local references for optimization
local string_format = string.format
local string_char13 = string.char(13)


function UIMapDBReadArrayValue(AArray, ATable, AFieldValue, AWhereField, AWhereValue, AOrderField)      
   local AQuery = ""
   
   AQuery = "SELECT "..AFieldValue.." FROM "..ATable   
   if AWhereField then AQuery = AQuery.." WHERE ("..AWhereField.." = "..AWhereValue ..")" end
   if AOrderField then AQuery = AQuery.." ORDER BY "..AOrderField end
       
   DatabasePrepare(UIDatabaseMap, AQuery)      
   local ColumnCount = DatabaseColumns(UIDatabaseMap)      
   local ColumnNames = DatabaseColumnNames(UIDatabaseMap)         
   local Row = DatabaseStep(UIDatabaseMap)   
   local RowValues = {}
   local I = 1                     
   -- Loop Result Rows
   while Row == sqlite3.ROW do        
      RowValues = DatabaseColumnValues(UIDatabaseMap)            
      AArray[I] = RowValues[1]                            
      Row = DatabaseStep(UIDatabaseMap)
      I=I+1
   end    
   DatabaseFinalize(UIDatabaseMap)   
end

function UIMapDBReadArrayKeyValue(AArray, ATable, AFieldKey, AFieldValue, AWhereField, AWhereValue, AOrderField)            
   local AQuery = ""
   
   AQuery = "SELECT "..AFieldKey..","..AFieldValue.." FROM "..ATable   
   if AWhereField then AQuery = AQuery.." WHERE "..AWhereValue.." = "..AWhereValue end
   if AOrderField then AQuery = AQuery.." ORDER BY "..AOrderField end
       
   DatabasePrepare(UIDatabaseMap, AQuery)      
   local ColumnCount = DatabaseColumns(UIDatabaseMap)      
   local ColumnNames = DatabaseColumnNames(UIDatabaseMap)         
   local Row = DatabaseStep(UIDatabaseMap)   
   local RowValues = {}                       
   -- Loop Result Rows
   while Row == sqlite3.ROW do        
      RowValues = DatabaseColumnValues(UIDatabaseMap)            
      AArray[RowValues[1]] = RowValues[2]                             
      Row = DatabaseStep(UIDatabaseMap)      
   end    
   DatabaseFinalize(UIDatabaseMap)     
end

--------------------------------------------------------------------------------
--//Region
--------------------------------------------------------------------------------

function UIMapDBRegionIDRead(ARegionID)
           
    local Result = nil
          
   -- Prepare Statement
   DatabasePrepare(UIDatabaseMap, string_format(       
      "SELECT RegionID, RegionName, RegionStride, RegionType, RegionColour, RegionSectorLeft, RegionSectorTop, RegionSectorRight, RegionSectorBottom, RegionSectorUp, RegionSectorDown, RegionParentID, RegionParentScale, RegionParentPositionX, RegionParentPositionY, RegionParentPositionZ FROM Regions WHERE (RegionID = %i) ORDER BY RegionID",
      ARegionID))
      
   
   -- Get Column Count
   local ColumnCount = DatabaseColumns(UIDatabaseMap)   
   -- Get Column Names
   local ColumnNames = DatabaseColumnNames(UIDatabaseMap)         
   -- Get First Row
   local Row = DatabaseStep (UIDatabaseMap)  -- read first row
   
   if Row == sqlite3.ROW then        
      local RowValues = DatabaseColumnValues(UIDatabaseMap)
            
      Result = {}      
      UIMapRegionReset(Result)
            
      -- Set Region       
      Result.RegionID = tonumber(RowValues[1])
      Result.RegionName = RowValues[2]
      Result.RegionStride = tonumber(RowValues[3])
      Result.RegionType = tonumber(RowValues[4])
      Result.RegionColour = tonumber(RowValues[5])
      Result.RegionSectorLeft = tonumber(RowValues[6])
      Result.RegionSectorTop = tonumber(RowValues[7])
      Result.RegionSectorRight = tonumber(RowValues[8])
      Result.RegionSectorBottom = tonumber(RowValues[9])            
      Result.RegionSectorUp = tonumber(RowValues[10])
      Result.RegionSectorDown = tonumber(RowValues[11])      
      Result.RegionParentID = tonumber(RowValues[12])                                
      Result.RegionParentScale = tonumber(RowValues[13])
      Result.RegionParentPositionX = tonumber(RowValues[14])
      Result.RegionParentPositionY = tonumber(RowValues[15])
      Result.RegionParentPositionZ = tonumber(RowValues[16])
   end
   
   -- Finalize statement
   DatabaseFinalize(UIDatabaseMap)
   
   return Result            
end

function UIMapDBRegionWrite(ARegion)
         
   if not UIEnableDBWrite then return end

   local DBResult = 0
   local DBRegionNameString = UIDatabasePrepareString(ARegion.RegionName)
            
   if (ARegion.RegionID == 0) then
      --not yet in database
      DBResult = DatabaseExec(UIDatabaseMap, string_format(
         "INSERT INTO Regions (RegionName, RegionStride, RegionType, RegionColour, RegionSectorLeft, RegionSectorTop, RegionSectorRight, RegionSectorBottom, RegionSectorUp, RegionSectorDown, RegionParentID, RegionParentScale, RegionParentPositionX, RegionParentPositionY, RegionParentPositionZ, TimeStamp) VALUES (%s, %i, %i, %i, %i, %i, %i, %i, %i, %i, %i, %f, %f, %f, %f, strftime('%%s', 'now'));",
         DBRegionNameString, ARegion.RegionStride, ARegion.RegionType, ARegion.RegionColour, ARegion.RegionSectorLeft, ARegion.RegionSectorTop, ARegion.RegionSectorRight, ARegion.RegionSectorBottom, ARegion.RegionSectorUp, ARegion.RegionSectorDown, ARegion.RegionParentID, ARegion.RegionParentScale, ARegion.RegionParentPositionX, ARegion.RegionParentPositionY, ARegion.RegionParentPositionZ))
      
      if UIDatabaseResultCheck(DBResult) then              
         --get the ID of the new record
         ARegion.RegionID = tonumber(DatabaseLastInsertRowid(UIDatabaseMap))
      else 
         UILog("UIMapDBRegionWrite", "Region INSERT failed.",1)                                              
      end
            
   else
      --already in database      
      DatabaseExec(UIDatabaseMap, string_format(      
         "UPDATE Regions SET RegionName = %s, RegionStride = %i, RegionType = %i, RegionColour = %i, RegionSectorLeft = %i, RegionSectorTop = %i, RegionSectorRight = %i, RegionSectorBottom = %i,RegionSectorUp = %i, RegionSectorDown = %i, RegionParentID = %i, RegionParentScale = %f, RegionParentPositionX = %f, RegionParentPositionY = %f, RegionParentPositionZ = %f, TimeStamp = strftime('%%s', 'now') WHERE RegionID = %i",
         DBRegionNameString, ARegion.RegionStride, ARegion.RegionType, ARegion.RegionColour, ARegion.RegionSectorLeft, ARegion.RegionSectorTop, ARegion.RegionSectorRight, ARegion.RegionSectorBottom, ARegion.RegionSectorUp, ARegion.RegionSectorDown, ARegion.RegionParentID, ARegion.RegionParentScale, ARegion.RegionParentPositionX, ARegion.RegionParentPositionY, ARegion.RegionParentPositionZ, ARegion.RegionID))
         
       if UIDatabaseResultCheck(DBResult) then              
      
      else 
         UILog("UIMapDBRegionWrite", "Region UPDATE failed.",1)                                              
      end
   end     
end

--------------------------------------------------------------------------------
--//Sector
--------------------------------------------------------------------------------

function UIMapDBSectorRead(ARegionID, ASectorPositionX, ASectorPositionY, ASectorPositionZ)
      
   local Result = nil
          
   -- Prepare Statement
   DatabasePrepare(UIDatabaseMap, string_format(       
      "SELECT SectorID, RegionID, SectorPositionX, SectorPositionY, SectorPositionZ, CellLeft, CellTop, CellRight, CellBottom, SectorData, SectorDataColour FROM Sectors WHERE (RegionID = %i) AND (SectorPositionX = %i) AND (SectorPositionY = %i) AND (SectorPositionZ = %i)",
      ARegionID, ASectorPositionX, ASectorPositionY, ASectorPositionZ))
          
   -- Get Column Count
   local ColumnCount = DatabaseColumns(UIDatabaseMap)   
   -- Get Column Names
   local ColumnNames = DatabaseColumnNames(UIDatabaseMap)       
   -- Get First Row
   local Row = DatabaseStep(UIDatabaseMap)  -- read first row
         
   if (Row == sqlite3.ROW) then
      local RowValues = DatabaseColumnValues(UIDatabaseMap)  
      
      Result = {}      
      UIMapSectorReset(Result)
       
      -- Set Sector       
      Result.SectorID = tonumber(RowValues[1])
      Result.RegionID = tonumber(RowValues[2])
      Result.SectorPositionX = tonumber(RowValues[3])
      Result.SectorPositionY = tonumber(RowValues[4])
      Result.SectorPositionZ = tonumber(RowValues[5])
      Result.CellLeft = tonumber(RowValues[6])
      Result.CellTop = tonumber(RowValues[7])
      Result.CellRight = tonumber(RowValues[8])
      Result.CellBottom = tonumber(RowValues[9])
      Result.SectorData = splitN(RowValues[10], UIMapSectorSize)   
      Result.SectorDataColour = splitN(RowValues[11], UIMapSectorSize)    
      
      if #Result.SectorData ~= 16*16 then
         Note("SECTOR READ ERROR, DATA LENGTH OF ID " ..Result.SectorID .. " is " .. #Result.SectorData)
      end
      if #Result.SectorDataColour ~= 16*16 then
         Note("SECTOR READ ERROR, SectorDataColour LENGTH OF ID " ..Result.SectorID .. " is " .. #Result.SectorDataColour)
      end
                
      
      --TODO -- Should Compress Data to save space   
      --s = utils.compress (s [, method] )
        
   end
   
   -- Finalize statement
   DatabaseFinalize(UIDatabaseMap)
   
   return Result
end

function UIMapDBSectorIDRead(ASectorID)
    
   local Result = nil
                
   -- Prepare Statement
   DatabasePrepare(UIDatabaseMap, string_format(       
      "SELECT SectorID, RegionID, SectorPositionX, SectorPositionY, SectorPositionZ, CellLeft, CellTop, CellRight, CellBottom, SectorData, SectorDataColour FROM Sectors WHERE (SectorID = %i)",
      ASectorID))
                
         
   -- Get Column Count
   local ColumnCount = DatabaseColumns(UIDatabaseMap)   
   -- Get Column Names
   local ColumnNames = DatabaseColumnNames(UIDatabaseMap)         
   -- Get First Row
   local Row = DatabaseStep (UIDatabaseMap)  -- read first row   
   
   if Row == sqlite3.ROW then         
      local RowValues = DatabaseColumnValues(UIDatabaseMap)  
      -- Set Sector
      Result = {}     
      UIMapSectorReset(Result)                             
      Result.SectorID = tonumber(RowValues[1])
      Result.RegionID = tonumber(RowValues[2])
      Result.SectorPositionX = tonumber(RowValues[3])
      Result.SectorPositionY = tonumber(RowValues[4])
      Result.SectorPositionZ = tonumber(RowValues[5])
      Result.CellLeft = tonumber(RowValues[6])
      Result.CellTop = tonumber(RowValues[7])
      Result.CellRight = tonumber(RowValues[8])
      Result.CellBottom = tonumber(RowValues[9])
      Result.SectorData = splitN(RowValues[10], UIMapSectorSize)   
      Result.SectorDataColour = splitN(RowValues[11], UIMapSectorSize)     
   
      --TODO -- Should Compress Data to save space   
      --s = utils.compress (s [, method] )
             
   end
      
   -- Finalize statement
   DatabaseFinalize(UIDatabaseMap)
   
   return Result  
      
end

function UIMapDBSectorWrite(ASector)

   if not UIEnableDBWrite then return end
      
   local DBResult = 0
   local DBDataString = ""
   local DBDataColourString = ""
   
   --Convert Sector data to string, use char(1) as seperator
   for I = 1, #ASector.SectorData do      
      DBDataString = DBDataString .. ASector.SectorData[I]      
   end   
   for I = 1, #ASector.SectorDataColour do      
      DBDataColourString = DBDataColourString .. ASector.SectorDataColour[I]            
   end
   
   DBDataString = UIDatabasePrepareString(DBDataString)
   DBDataColourString = UIDatabasePrepareString(DBDataColourString)
   
   --TODO -- Should Compress Data to save space   
   --s = utils.compress (s [, method] )
      
   if (ASector.SectorID == 0) then
      --not yet in database
      DBResult = DatabaseExec(UIDatabaseMap, string_format(
         "INSERT INTO Sectors (RegionID, SectorPositionX, SectorPositionY, SectorPositionZ, CellLeft, CellTop, CellRight, CellBottom, SectorData, SectorDataColour, TimeStamp) VALUES (%i, %i, %i, %i, %i, %i, %i, %i, %s, %s, strftime('%%s', 'now'));",
         ASector.RegionID, ASector.SectorPositionX, ASector.SectorPositionY, ASector.SectorPositionZ, ASector.CellLeft, ASector.CellTop, ASector.CellRight, ASector.CellBottom, DBDataString, DBDataColourString))
      
      if UIDatabaseResultCheck(DBResult) then              
         --get the ID of the new record
         ASector.SectorID = tonumber(DatabaseLastInsertRowid(UIDatabaseMap))
      else         
         UILog("UIMapDBSectorWrite", "Sector INSERT failed.",1)                                   
      end          
   else
      --already in database
      DatabaseExec(UIDatabaseMap, string_format(
         "UPDATE Sectors SET RegionID = %i, SectorPositionX = %i, SectorPositionY = %i, SectorPositionZ = %i, CellLeft = %i, CellTop = %i, CellRight = %i, CellBottom = %i, SectorData = %s, SectorDataColour = %s, TimeStamp = strftime('%%s', 'now') WHERE SectorID = %i;",      
         ASector.RegionID, ASector.SectorPositionX, ASector.SectorPositionY, ASector.SectorPositionZ, ASector.CellLeft, ASector.CellTop, ASector.CellRight, ASector.CellBottom, DBDataString, DBDataColourString, ASector.SectorID))      
   end  
end

--------------------------------------------------------------------------------
--//Room
--------------------------------------------------------------------------------

function UIMapDBRoomRead(ARegionID, APositionX, APositionY, APositionZ)
      
   local Result = nil             

   -- Prepare Statement
   DatabasePrepare(UIDatabaseMap, string_format(       
      "SELECT RoomID, RegionID, SectorID, RoomTypeID, RoomSubTypeID, RoomPositionX, RoomPositionY, RoomPositionZ, RoomName, RoomDescription, ExitNorth, ExitNorthType, ExitNorthEast, ExitNorthEastType, ExitEast, ExitEastType, ExitSouthEast, ExitSouthEastType, ExitSouth, ExitSouthType, ExitSouthWest, ExitSouthWestType, ExitWest, ExitWestType, ExitNorthWest, ExitNorthWestType, ExitUp, ExitUpType, ExitDown, ExitDownType FROM Rooms WHERE (RegionID = %i) and (RoomPositionX = %i) and (RoomPositionY = %i) and (RoomPositionZ = %i)",
      ARegionID, APositionX, APositionY, APositionZ))
         
   -- Get Column Count
   local ColumnCount = DatabaseColumns(UIDatabaseMap)   
   -- Get Column Names
   local ColumnNames = DatabaseColumnNames(UIDatabaseMap)         
   -- Get First Row
   local Row = DatabaseStep (UIDatabaseMap)  -- read first row   
   
   if Row == sqlite3.ROW then      
      local RowValues = DatabaseColumnValues(UIDatabaseMap)
      
      Result = {}      
      UIMapRoomReset(Result)
         
      -- Set Room       
      Result.RoomID = tonumber(RowValues[1])
      Result.RegionID = tonumber(RowValues[2])
      Result.SectorID = tonumber(RowValues[3])      
      Result.RoomTypeID = tonumber(RowValues[4])
      Result.RoomSubTypeID = tonumber(RowValues[5])    
      Result.RoomPositionX = tonumber(RowValues[6])
      Result.RoomPositionY = tonumber(RowValues[7])
      Result.RoomPositionZ = tonumber(RowValues[8])
      Result.RoomName = RowValues[9]
      Result.RoomDescription = split(RowValues[10],string_char13)      
      Result.ExitNorth = tonumber(RowValues[11])
      Result.ExitNorthType = tonumber(RowValues[12])
      Result.ExitNorthEast = tonumber(RowValues[13])
      Result.ExitNorthEastType = tonumber(RowValues[14])
      Result.ExitEast = tonumber(RowValues[15])
      Result.ExitEastType = tonumber(RowValues[16])
      Result.ExitSouthEast = tonumber(RowValues[17])
      Result.ExitSouthEastType = tonumber(RowValues[18])
      Result.ExitSouth = tonumber(RowValues[19])
      Result.ExitSouthType = tonumber(RowValues[20])
      Result.ExitSouthWest = tonumber(RowValues[21])
      Result.ExitSouthWestType = tonumber(RowValues[22])
      Result.ExitWest = tonumber(RowValues[23])
      Result.ExitWestType = tonumber(RowValues[24])
      Result.ExitNorthWest = tonumber(RowValues[25])
      Result.ExitNorthWestType = tonumber(RowValues[26])
      Result.ExitUp = tonumber(RowValues[27])
      Result.ExitUpType = tonumber(RowValues[28])
      Result.ExitDown = tonumber(RowValues[29])
      Result.ExitDownType = tonumber(RowValues[30])
   end

   -- Finalize statement
   DatabaseFinalize(UIDatabaseMap)
   
   return Result                  
end

function UIMapDBRoomIDRead(ARoomID)
      
   local Result = nil
            
   -- Prepare Statement
   DatabasePrepare(UIDatabaseMap, string_format(       
      "SELECT RoomID, RegionID, SectorID, RoomTypeID, RoomSubTypeID, RoomPositionX, RoomPositionY, RoomPositionZ, RoomName, RoomDescription, ExitNorth, ExitNorthType, ExitNorthEast, ExitNorthEastType, ExitEast, ExitEastType, ExitSouthEast, ExitSouthEastType, ExitSouth, ExitSouthType, ExitSouthWest, ExitSouthWestType, ExitWest, ExitWestType, ExitNorthWest, ExitNorthWestType, ExitUp, ExitUpType, ExitDown, ExitDownType FROM Rooms WHERE (RoomID = %i)",
      ARoomID))
         
   -- Get Column Count
   local ColumnCount = DatabaseColumns(UIDatabaseMap)   
   -- Get Column Names
   local ColumnNames = DatabaseColumnNames(UIDatabaseMap)         
   -- Get First Row
   local Row = DatabaseStep (UIDatabaseMap)  -- read first row   
   
   if Row == sqlite3.ROW then         
      local RowValues = DatabaseColumnValues(UIDatabaseMap)      
      -- Set Room
      Result = {}            
      UIMapRoomReset(Result)                              
      Result.RoomID = tonumber(RowValues[1])
      Result.RegionID = tonumber(RowValues[2])
      Result.SectorID = tonumber(RowValues[3])      
      Result.RoomTypeID = tonumber(RowValues[4])
      Result.RoomSubTypeID = tonumber(RowValues[5])    
      Result.RoomPositionX = tonumber(RowValues[6])
      Result.RoomPositionY = tonumber(RowValues[7])
      Result.RoomPositionZ = tonumber(RowValues[8])
      Result.RoomName = RowValues[9]
      Result.RoomDescription = split(RowValues[10],string_char13)      
      Result.ExitNorth = tonumber(RowValues[11])
      Result.ExitNorthType = tonumber(RowValues[12])
      Result.ExitNorthEast = tonumber(RowValues[13])
      Result.ExitNorthEastType = tonumber(RowValues[14])
      Result.ExitEast = tonumber(RowValues[15])
      Result.ExitEastType = tonumber(RowValues[16])
      Result.ExitSouthEast = tonumber(RowValues[17])
      Result.ExitSouthEastType = tonumber(RowValues[18])
      Result.ExitSouth = tonumber(RowValues[19])
      Result.ExitSouthType = tonumber(RowValues[20])
      Result.ExitSouthWest = tonumber(RowValues[21])
      Result.ExitSouthWestType = tonumber(RowValues[22])
      Result.ExitWest = tonumber(RowValues[23])
      Result.ExitWestType = tonumber(RowValues[24])
      Result.ExitNorthWest = tonumber(RowValues[25])
      Result.ExitNorthWestType = tonumber(RowValues[26])
      Result.ExitUp = tonumber(RowValues[27])
      Result.ExitUpType = tonumber(RowValues[28])
      Result.ExitDown = tonumber(RowValues[29])
      Result.ExitDownType = tonumber(RowValues[30])            
   end
      
   -- Finalize statement
   DatabaseFinalize(UIDatabaseMap)
   
   return Result                  
end

function UIMapDBRoomWrite(ARoom)
   
   if not UIEnableDBWrite then return end
   if not UIEnableMapMergeRoom then return end
   
   local DBResult = 0
   local DBRoomNameString = UIDatabasePrepareString(ARoom.RoomName)
   local DBRoomDescriptionString = ""
   
   --Concatenate description string
   for I = 1, #ARoom.RoomDescription do
      if (I < #ARoom.RoomDescription) then
         DBRoomDescriptionString = DBRoomDescriptionString .. ARoom.RoomDescription[I] .. string_char13
      else
         DBRoomDescriptionString = DBRoomDescriptionString .. ARoom.RoomDescription[I]
      end  
   end
   
   DBRoomDescriptionString = UIDatabasePrepareString(DBRoomDescriptionString) 
        
   if (ARoom.RoomID == 0) then
      --not yet in database
      DBResult = DatabaseExec(UIDatabaseMap, string_format(         
         "INSERT INTO Rooms (RegionID, SectorID, RoomTypeID, RoomSubTypeID, RoomPositionX, RoomPositionY, RoomPositionZ, RoomName, RoomDescription, ExitNorth, ExitNorthType, ExitNorthEast, ExitNorthEastType, ExitEast, ExitEastType, ExitSouthEast, ExitSouthEastType, ExitSouth, ExitSouthType, ExitSouthWest, ExitSouthWestType, ExitWest, ExitWestType, ExitNorthWest, ExitNorthWestType, ExitUp, ExitUpType, ExitDown, ExitDownType, TimeStamp) VALUES (%i, %i, %i, %i, %i, %i, %i, %s, %s, %i, %i, %i, %i, %i, %i, %i, %i, %i, %i, %i, %i, %i, %i, %i, %i, %i, %i, %i, %i, strftime('%%s', 'now'));",      
         ARoom.RegionID, ARoom.SectorID, ARoom.RoomTypeID, ARoom.RoomSubTypeID, ARoom.RoomPositionX, ARoom.RoomPositionY, ARoom.RoomPositionZ,
         DBRoomNameString, DBRoomDescriptionString, ARoom.ExitNorth, ARoom.ExitNorthType, ARoom.ExitNorthEast, ARoom.ExitNorthEastType,
         ARoom.ExitEast, ARoom.ExitEastType, ARoom.ExitSouthEast, ARoom.ExitSouthEastType, ARoom.ExitSouth, ARoom.ExitSouthType,
         ARoom.ExitSouthWest, ARoom.ExitSouthWestType, ARoom.ExitWest, ARoom.ExitWestType, ARoom.ExitNorthWest, ARoom.ExitNorthWestType,
         ARoom.ExitUp, ARoom.ExitUpType, ARoom.ExitDown, ARoom.ExitDownType))                     
                     
      if UIDatabaseResultCheck(DBResult) then              
         --get the ID of the new record
         ARoom.RoomID = tonumber(DatabaseLastInsertRowid(UIDatabaseMap))
      else  
         UILog("UIMapDBRoomWrite", "Room INSERT failed.",1)                                          
      end           
   else   
      --room already in database, update      
      DatabaseExec(UIDatabaseMap, string.format(
         "UPDATE Rooms SET RegionID = %i, SectorID = %i, RoomTypeID = %i, RoomSubTypeID = %i, RoomPositionX = %i, RoomPositionY = %i, RoomPositionZ = %i, RoomName = %s, RoomDescription = %s, ExitNorth = %i, ExitNorthType = %i, ExitNorthEast = %i, ExitNorthEastType = %i, ExitEast = %i, ExitEastType = %i, ExitSouthEast = %i, ExitSouthEastType = %i, ExitSouth = %i, ExitSouthType = %i, ExitSouthWest = %i, ExitSouthWestType = %i, ExitWest = %i, ExitWestType = %i, ExitNorthWest = %i, ExitNorthWestType = %i, ExitUp = %i, ExitUpType = %i, ExitDown = %i, ExitDownType = %i, TimeStamp = strftime('%%s', 'now') WHERE RoomID = %i",      
                      ARoom.RegionID, ARoom.SectorID, ARoom.RoomTypeID, ARoom.RoomSubTypeID, ARoom.RoomPositionX, ARoom.RoomPositionY, ARoom.RoomPositionZ, DBRoomNameString, DBRoomDescriptionString, ARoom.ExitNorth, ARoom.ExitNorthType, ARoom.ExitNorthEast, ARoom.ExitNorthEastType, ARoom.ExitEast, ARoom.ExitEastType, ARoom.ExitSouthEast, ARoom.ExitSouthEastType, ARoom.ExitSouth, ARoom.ExitSouthType, ARoom.ExitSouthWest, ARoom.ExitSouthWestType, ARoom.ExitWest, ARoom.ExitWestType, ARoom.ExitNorthWest, ARoom.ExitNorthWestType, ARoom.ExitUp, ARoom.ExitUpType, ARoom.ExitDown, ARoom.ExitDownType, ARoom.RoomID))
   end                 
end

--------------------------------------------------------------------------------
--//Portal
--------------------------------------------------------------------------------

function UIMapDBPortalRead(ARegionID, APositionX, APositionY, APositionZ)
                   
end

function UIMapDBPortalIDRead(APortalID)
                   
end

function UIMapDBPortalWrite(APortal)
                  
end

--------------------------------------------------------------------------------
--//Place
--------------------------------------------------------------------------------

function UIMapDBPlaceIDRead(APlaceID)
      
   local Result = nil
            
   -- Prepare Statement
   DatabasePrepare(UIDatabaseMap, string_format(       
      "SELECT PlaceID, RegionID, PlaceName, PlaceParentID FROM Places WHERE (PlaceID = %i)",
      APlaceID))
         
   -- Get Column Count
   local ColumnCount = DatabaseColumns(UIDatabaseMap)   
   -- Get Column Names
   local ColumnNames = DatabaseColumnNames(UIDatabaseMap)         
   -- Get First Row
   local Row = DatabaseStep (UIDatabaseMap)  -- read first row   
   
   if Row == sqlite3.ROW then         
      local RowValues = DatabaseColumnValues(UIDatabaseMap)                 
      -- Set Room
      Result = {}
      UIMapPlaceReset(Result)                        
      Result.PlaceID = tonumber(RowValues[1])
      Result.RegionID = tonumber(RowValues[2])
      Result.PlaceName = RowValues[3]
      Result.PlaceParentID = tonumber(RowValues[1])
                              
   end
      
   -- Finalize statement
   DatabaseFinalize(UIDatabaseMap)
   
   return Result                    
end

function UIMapDBPlaceWrite(APlace)
                  
end

--------------------------------------------------------------------------------
--//Street
--------------------------------------------------------------------------------

function UIMapDBStreetIDRead(AStreetID)
      
   local Result = nil
            
   -- Prepare Statement
   DatabasePrepare(UIDatabaseMap, string_format(       
      "SELECT StreetID, RegionID, StreetName FROM Streets WHERE (StreetID = %i)",
      AStreetID))
         
   -- Get Column Count
   local ColumnCount = DatabaseColumns(UIDatabaseMap)   
   -- Get Column Names
   local ColumnNames = DatabaseColumnNames(UIDatabaseMap)         
   -- Get First Row
   local Row = DatabaseStep (UIDatabaseMap)  -- read first row   
   
   if Row == sqlite3.ROW then         
      local RowValues = DatabaseColumnValues(UIDatabaseMap)                 
      -- Set Room
      Result = {}
      UIMapStreetReset(Result)                        
      Result.StreetID = tonumber(RowValues[1])
      Result.RegionID = tonumber(RowValues[2])
      Result.StreetName = RowValues[3]
                              
   end
      
   -- Finalize statement
   DatabaseFinalize(UIDatabaseMap)
   
   return Result                     
end

function UIMapDBStreetWrite(AStreet)

   if not UIEnableDBWrite then return end

   local DBResult = 0
         
   if (AStreet.StreetID == 0) then
      --not yet in database
      DBResult = DatabaseExec(UIDatabaseMap, string_format(
         "INSERT INTO Streets (RegionID, StreetName, TimeStamp) VALUES (%i, %s, strftime('%%s', 'now'));",
         AStreet.RegionID, AStreet.StreetName))
      
      if UIDatabaseResultCheck(DBResult) then              
         --get the ID of the new record
         AStreet.SectorID = tonumber(DatabaseLastInsertRowid(UIDatabaseMap))
      else
         UILog("UIMapDBStreetWrite", "Street INSERT failed.",1)                                            
      end          
   else
      --already in database
      DatabaseExec(UIDatabaseMap, string_format(
         "UPDATE Streets SET RegionID = %i, StreetName = %s, TimeStamp = strftime('%%s', 'now') WHERE StreetID = %i;",      
         AStreet.RegionID, AStreet.StreetName, AStreet.StreetID))      
   end                    
end
