--------------------------------------------------------------------------------
--//DiscUI Map Edit Window Variables
--------------------------------------------------------------------------------

UIWindowMapLocalBorderWidth = 5
UIWindowMapLocal = {}

--------------------------------------------------------------------------------
--//DiscUI Map Edit Window Functions
--------------------------------------------------------------------------------

function UIWindowMapLocalCreate()   

   --Create Window
   UIWindowMapLocal = UIWindowCreate("MapLocal", UI_BarLeftWidth, 0, 300, UI_BarTopHeight, 4)
   
   local FFontName = 'consolas';
   local FFontHeight = 8;
   
   local FFontSmallName = 'consolas';
   local FFontSmallHeight = 8;   
   
   UIFontCreate(UIWindowMapLocal.MushWindow, UIWindowMapLocal.Font, FFontName, FFontHeight, false) 
   UIFontCreate(UIWindowMapLocal.MushWindow, UIWindowMapLocal.FontSmall, FFontSmallName, FFontSmallHeight, false)
                      
   UIWindowMapLocal.TitleBarText = "Local Map"
   
   local FBorderWidth = 4
    
   UIWindowMapLocal.OnRender = UIWindowMapLocalRender  
    
   UIWindowMapLocal.Render()         
   UIWindowMapLocal.Show()   
end

function UIWindowMapLocalRender(ADelta)
   
   UIMapCaptureRenderToTarget(UIWindowMapLocal, 5, UIWindowMapLocal.TitleBarHeight + 5, UIWindowMapLocal.Width - 5, UIWindowMapLocal.Height - 5)
   
end