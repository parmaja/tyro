--------------------------------------------------------------------------------
--//DiscUI Popup Window
--------------------------------------------------------------------------------
local UIWindowPopupCounter = 0 -- Global private variable

--Invisible window for capturing mouse click outside of menu
UIPopupWindowBackground = ""
UIPopupWindowBackgroundHotSpot = ""


UIPopups = {} --store a record of all popups for hiding etc
--------------------------------------------------------------------------------
--//DiscUI Popup Window
--------------------------------------------------------------------------------

function UIPopupWindowHideAll()   
   for I, Popup in pairs(UIPopups) do
      Popup.Hide()
   end
   WindowShow (UIPopupWindowBackground, false)           
end

function UIPopupWindowBackgroundMouseDown(flags, hotspot_id)
   
   local MouseX = WindowInfo(UIPopupWindowBackground, 14)
   local MouseY = WindowInfo(UIPopupWindowBackground, 15)
   
   for I, Window in pairs(UIWindows) do
      if Window then
               
         if (MouseX > Window.Left) and 
         (MouseY > Window.Top) and 
         (MouseX <  (Window.Top+Window.Height)) and 
         (MouseY < (Window.Left+Window.Width)) then
            
            Window.MouseButton(MouseX, MouseY, 1, 1)
                     
            MouseX = MouseX - Window.Left
            MouseY = MouseY - Window.Top
            
            for K, Widget in ipairs(Window.Widgets) do
               if (MouseX > Widget.Left) and (MouseY > Widget.Top) and (MouseX < Widget.Right) and (MouseY < Widget.Bottom) then
                  
                  Widget.MouseButton(MouseX, MouseY, 1, 1)
               end
            end
            
         end   
      end     
   end
   
   UIPopupWindowHideAll()
     
end
      
function UIPopupWindowBackgroundCancelMouseDown(flags, hotspot_id)
   UIPopupWindowHideAll()
end

function UIPopupWindowBackgroundCancelMouseUp(flags, hotspot_id)
   UIPopupWindowHideAll()
end

function UIWindowPopupCreate(APopupName)

   --create self instance
   local self = {}
   self.id = UIWindowPopupCounter
   UIWindowPopupCounter = UIWindowPopupCounter + 1
   
   -----------------------------------------------------------------------------
   --Private                                                             Private
   -----------------------------------------------------------------------------
   --
   
   local FHotSpot = "HotSpot" .. APopupName .. self.id
   local FPopupName = APopupName    
   
   
   
   local FFontName = "Consolas"
   local FFontHeight = 8
   
        
   -----------------------------------------------------------------------------
   --Public                                                               Public
   -----------------------------------------------------------------------------
   self.MushWindow = APopupName .. self.id   
   self.Left = 0
   self.Top = 0
   self.Width = 50
   self.Height = 150
      
   self.PopupFont = APopupName .. "Font" .. self.id    
   self.Items = {}
   self.SelectedItem = {}
   
   self.OnItemSelect = nil
     
   
   function self.ItemAdd(AItemCaption, AItemData)
      local Item = {}
      Item.Caption = AItemCaption
      Item.Data = AItemData
      table.insert(self.Items,Item)
   end
   
   function self.ItemsClear()
      self.Items = {}
   end
   
   
   function self.Popup(APositionX, APositionY, AMinimumWidth)   
   
      if not AMinimumWidth then
         AMinimumWidth = 30
      end
        
      --create invisible background window and hotspot to capture click out
      if UIPopupWindowBackground == "" then
         UIPopupWindowBackground = "WindowPopupBackground"
         UIPopupWindowBackgroundHotSpot = "WindowPopupBackgroundHotSpot"
                 
         local width = UIMushClientWidth()
         local height = UIMushClientHeight()
          
         result = WindowCreate(UIPopupWindowBackground, 0, 0, width, height,  4, 6, 0x000000)
         
         result = WindowAddHotspot(UIPopupWindowBackground, UIPopupWindowBackgroundHotSpot, 
         0, 0, width, height,   
         "", "", "UIPopupWindowBackgroundMouseDown", "UIPopupWindowBackgroundCancelMouseDown", "UIPopupWindowBackgroundCancelMouseUp", "",  0, 0)
             
         WindowShow (UIPopupWindowBackground, true) -- show the popup                 
      end
      
      local PopupPositionX = 0
      local PopupPositionY = 0 
      
      PopupPositionX = APositionX 
      PopupPositionY = APositionY
      
      if self.Width < AMinimumWidth then
         self.Width = AMinimumWidth
      end 
      
      WindowPosition(self.MushWindow, PopupPositionX, PopupPositionY, 4, 18)
      WindowResize(self.MushWindow, self.Width, self.Height, 0x000000)
      
      WindowDeleteHotspot(self.MushWindow, FHotSpot);
      
      WindowAddHotspot(self.MushWindow, FHotSpot, 
         0, 0, self.Width, self.Height,   
         "WindowPopupMouseOver", "WindowPopupCancelMouseOver", "WindowPopupMouseDown", "WindowPopupCancelMouseDown", "WindowPopupMouseUp", "",  0, 0x01)
       
      WindowSetZOrder(self.MushWindow, 100);
            
      self.Render()
      WindowShow (UIPopupWindowBackground, true) -- show the background catcter          
      WindowShow (self.MushWindow, true) -- show the popup   
                           
   end
   
   function self.Hide()
      WindowShow(self.MushWindow, false)   
   end
   
   function self.MouseMove(AMouseX, AMouseY)
      --world.Note("PopupMoseMove")
      --world.Note(self.Caption .. "MouseMoveXY = "..AMouseX..":"..AMouseY)
      for I,Item in ipairs(self.Items) do         
         if (AMouseY > 15*(I-1)) and (AMouseY < 15*(I-1)+15) then
            self.SelectedItem = Item
         end
      end      
      if self.OnMouseMove ~= nil then
         self.OnMouseMove(AMouseX, AMouseY)
      end
   
   end
      
   function self.MouseButton(AMouseX, AMouseY, Button, State)
   
      for I,Item in ipairs(self.Items) do         
         if (AMouseY > 15*(I-1)) and (AMouseY < 15*(I-1)+15) then
            self.SelectedItem = Item
            
         end
      end             
     
     if self.SelectedItem then
         if self.OnItemSelect then
            self.OnItemSelect(self.SelectedItem)
         end
     end
      --world.Note(self.Caption .. "MouseDownXY = "..AMouseX..":"..AMouseY)
      
      if self.OnMouseButton ~= nil then
         self.OnMouseButton(AMouseX, AMouseY, Button, State)
      end
      
      UIPopupWindowHideAll()
   end
   
   
   function self.Render()
   
      WindowRectOp(self.MushWindow, 2, 0, 0, self.Width, self.Height, 0x232323)
      local FontColour = 0xFFFFFF
      
      local SelectedColour = 0xFFFFFF
      local SelectedFontColour = 0x000000
      
      for I, Item in ipairs(self.Items) do
         if Item == self.SelectedItem then
            
            WindowRectOp(self.MushWindow, 2, 0, 5 + 15*(I-1), self.Width, 5 + 15*(I-1)+15, SelectedColour)
            FontColour = SelectedFontColour      
         else
            FontColour = 0xFFFFFF            
         end
         WindowText(self.MushWindow, self.PopupFont, Item.Caption, 5, 5 + 15*(I-1), self.Width-5, 5 + 15*(I-1)+15, FontColour)      
      end      
      
      
      --Render outline      
      WindowRectOp(self.MushWindow, 4, 0, 0, self.Width, self.Height, 0x939393, 0x939393)  -- Two Colour Border
               
   end
   
          
   WindowCreate(self.MushWindow, self.Left, self.Top, self.Width, self.Height,  4, 2, 0x232323)      
   UIFontCreate(self.MushWindow, self.PopupFont, FFontName, FFontHeight, false)  
   
   --WindowAddHotspot(MushWindow, FHotSpot, 
   --      0, 0, self.Width, self.Height,   
   --      "WindowPopupMouseOver", "WindowPopupCancelMouseOver", "WindowPopupMouseDown", "WindowPopupCancelMouseDown", "WindowPopupMouseUp", "",  0, 0x01) 
         
         --world.Note(result)    
 --        WindowShow (UIPopupWindowBackground, true) -- show the popup       
           
   --store a reference to this new popup
   
   UIPopups[FHotSpot] = self  
        
   return self   
end

function WindowPopupMouseOver(flags, hotspot_id)

   local APopup = UIPopups[hotspot_id]
   
   local MouseX = (WindowInfo(APopup.MushWindow, 14))-- - AWidget.Left  -- where mouse is relative to output window (X)
   local MouseY = (WindowInfo(APopup.MushWindow, 15))-- - AWidget.Top -- where mouse is relative to output window (Y) 
  
   APopup.MouseMove(MouseX, MouseY)
   
   APopup.Render()
   Redraw()
   
   return 0 -- needed for some languages   
end

function WindowPopupCancelMouseOver(flags, hotspot_id)
   
   local APopup = UIPopups[hotspot_id]
   local MouseX = (WindowInfo(APopup.MushWindow, 14)+APopup.Left)-- - AWidget.Left  -- where mouse is relative to output window (X)
   local MouseY = (WindowInfo(UIPopupWindowBackground, 15)+APopup.Top)-- - AWidget.Top -- where mouse is relative to output window (Y)
      
   APopup.Render()
   Redraw()
              
   return 0 -- needed for some languages   
end

function WindowPopupMouseDown(flags, hotspot_id)
   
   local APopup = UIPopups[hotspot_id]
   
   local MouseX = (WindowInfo(APopup.MushWindow, 14)+APopup.Left)-- - AWidget.Left  -- where mouse is relative to output window (X)
   local MouseY = (WindowInfo(APopup.MushWindow, 15)+APopup.Top)-- - AWidget.Top -- where mouse is relative to output window (Y)
         
   APopup.MouseButton(MouseX,MouseY,1,1)
      
   APopup.Render()
   Redraw()
         

   return 0 -- needed for some languages    
end

function WindowPopupCancelMouseDown(flags, hotspot_id)
      

   return 0 -- needed for some languages  
end

function WindowPopupMouseUp(flags, hotspot_id)
      

   return 0 -- needed for some languages  
end