--------------------------------------------------------------------------------
--//DiscUI Widget Dropdown 
--------------------------------------------------------------------------------

function UIWidgetDropdownCreate(AWindow, AWidgetLeft, AWidgetTop, AWidgetRight, AWidgetBottom)
   
    local self = UIWidgetCreate(AWindow, AWidgetLeft, AWidgetTop, AWidgetRight, AWidgetBottom)
          
   --overrides
   self.WidgetType = UIWidget_Dropdown
   self.WidgetTypeName = "WidgetDropdown"
   self.SetCaption("")   
   self.RenderParent = self.Render
   self.ColourBackground = 0x363636
   self.Font = self.Window.FontSmall
      
   --additions      
   self.PopupList = UIWindowPopupCreate("DropDownPopup" .. self.id)   
   self.Items = self.PopupList.Items
   self.Item = {}
   self.SelectedItem = nil
   
   --callbacks 
   self.OnDropDown = nil
   self.OnItemSelect = nil
           
      
   function self.DoPopupItemSelect(AItem)
      self.SelectedItem = AItem
      self.SetCaption(AItem.Caption)             
      self.Render()     
   end   
           
   --additions
   
   self.MouseButtonParent = self.MouseButton 
   function self.MouseButton(AMouseX, AMouseY, Button, State)
   
      self.MouseButtonParent(AMouseX, AMouseY, Button, State)
      
      
      self.PopupList.Popup(self.Window.Left + self.Left, self.Window.Top + self.Bottom, self.Width)
      
      --world.Note(self.Caption .. "MouseDownXY = "..AMouseX..":"..AMouseY)            
   end    

   function self.ItemAdd(AItemCaption, AItemData)
      local Item = {}
      Item.Caption = AItemCaption
      Item.Data = AItemData
      table.insert(self.PopupList.Items, Item)
   end

   
      
   function self.Render()   
               
      --don't render default widget rect
      --self.RenderParent()  

      --Render Background                  
      self.Window.RectColour(self.ColourBackground)
      self.Window.Rect(self.Left,self.Top,self.Right,self.Bottom)
                       
      local APosX = self.Left + 5 -- (self.WidthDiv2 - self.CaptionWidthDiv2)
      local APosY = self.Top + (self.HeightDiv2 - self.CaptionHeightDiv2)
            
      --Render Text
      self.Window.TextColour(self.ColourFont)
      self.Window.Text(self.Caption, self.Font, APosX, APosY, (self.Right-2)-self.Height, APosY + self.CaptionHeight)
      
      --Render Button
      if self.IsHovering == true then
         self.Window.RectColour(self.ColourBackgroundHovering)
      else
         self.Window.RectColour(self.ColourBackground)
      end
      
      self.Window.Rect((self.Right)-self.Height,self.Top,self.Right,self.Bottom)
      self.Window.RectColour(0x939393)      
      self.Window.RectOutline((self.Right)-self.Height,self.Top,self.Right,self.Bottom)
      
      
      local AMidX = self.Right-self.Height + (self.Height)/2
      local AMidY = self.Top + (self.Bottom-self.Top)/2
                  
      WindowCircleOp(self.Window.MushWindow,1, AMidX-3,AMidY-3,AMidX+3,AMidY+3, 0x939393, 0, 1, 0x939393, 0) -- circle
      
      
      --Render outline
      self.Window.RectColour(0x939393)
      self.Window.RectOutline(self.Left,self.Top,self.Right,self.Bottom)                      
   end
   
   
   --Setup Dropdown
   self.PopupList.OnItemSelect = self.DoPopupItemSelect
   
               
   return self      
end