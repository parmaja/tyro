--------------------------------------------------------------------------------
--//DiscUI Utilities
--------------------------------------------------------------------------------

--local references for optimization
local string_gmatch = string.gmatch
local string_match = string.match
local string_find = string.find
local math_floor = math.floor
local math_ceil = math.ceil
local math_fmod = math.fmod
local string_sub = string.sub
local table_insert = table.insert
local os_time = os.time

function UIcommas (num)
  assert (type (num) == "number" or
          type (num) == "string")
  
  local result = ""

  -- split number into 3 parts, eg. -1234.545e22
  -- sign = + or -
  -- before = 1234
  -- after = .545e22

  local sign, before, after =
    string.match (tostring (num), "^([%+%-]?)(%d*)(%.?.*)$")

  -- pull out batches of 3 digits from the end, put a comma before them

  while string.len (before) > 3 do
    result = "," .. string.sub (before, -3, -1) .. result
    before = string.sub (before, 1, -4)  -- remove last 3 digits
  end -- while

  -- we want the original sign, any left-over digits, the comma part,
  -- and the stuff after the decimal point, if any
  return sign .. before .. result .. after

end -- function commas

--------------------------------------------------------------------------------
function UILog(ASender, AMessage, ALevel)
   if (not ASender) then ASender = "ERR_NO_SENDER" end
   if (not AMessage) then AMessage = "ERR_NO_MESSAGE" end
   if (not ALevel) then ALevel = 0 end
   local CBackground = "#121212"         
   local CMessage = "#FFFFFF"      
   if ALevel == 0 then CMessage = "#AAFFAA" else CMessage = "#FFAAAA" end            
   ColourNote(CMessage, CBackground, "["..ASender..":"..ALevel.."] "..AMessage)         
end

--------------------------------------------------------------------------------
function UIRGBToColour(ARed, AGreen, ABlue)
   return ABlue + (AGreen * 256) + (ARed * 65536)      
   --return ARed * 2 ^ 16 + ABlue * 2 ^ 8 + AGreen   
end

--------------------------------------------------------------------------------   
function UIColourToRGB(AColour)   
   local ARed = math.floor(AColour/65536)   
   local AGreen = math.floor((AColour-(ARed*65536))/256)   
   local ABlue = math.floor((AColour-(ARed*65536)-(AGreen*256)))
   return ARed, AGreen, ABlue      
end

--------------------------------------------------------------------------------
function UIRGBBlend(R1,G1,B1, R2,G2,B2, ADelta)
   local ARed = math.floor(R1 + ((R2-R1)*ADelta))
   local AGreen = math.floor(G1 + ((G2-G1)*ADelta))
   local ABlue = math.floor(B1 + ((B2-B1)*ADelta))
   return ARed, AGreen, ABlue
end

--------------------------------------------------------------------------------
function UIColourBlend(AColour1, AColour2, ADelta)
   local R1, G1, B1 ,R2, G2, B2
   R1, G1, B1 = UIColourToRGB(AColour1)
   R2, G2, B2 = UIColourToRGB(AColour2)   
   R1, G1, B1 = UIRGBBlend(R1,G1,B1, R2,G2,B2, ADelta)    
   return UIRGBToColour(R1, G1, B1)        
end

--------------------------------------------------------------------------------
function num2hex(num)    
    --local s = string.format("%x", num)    
    local hexstr = '0123456789ABCDEF'
    local s = ''
    while num > 0 do
        local mod = math.fmod(num, 16)
        s = string.sub(hexstr, mod+1, mod+1) .. s
        num = math.floor(num / 16)
    end
    
    if s == '' then s = '0' end
    if #s == 4 then
      s = "00"..s
    end    
    return "0x"..s
end

--------------------------------------------------------------------------------
function trim(s)
   --world.trim BSTR Trim(BSTR Source);
  return string_match(s,'^()%s*$') and '' or string_match(s,'^%s*(.*%S)')
end
   
--------------------------------------------------------------------------------   
function StringCapitalizeFirst(str)
    return (str:gsub("^%l", string.upper))
end
   
--------------------------------------------------------------------------------   
function StringCapitalizeAll(AString)   
   function StringCapitalizeFunc( first, rest )
      return first:upper()..rest:lower()
   end
   return string.gsub(AString, "(%a)([%w_']*)", StringCapitalizeFunc)
end

--------------------------------------------------------------------------------
function StringIsRepeatedChar(AString, AChar)
   if not AChar then AChar = AString:sub(1,1) end   
   local Result = false
   --Note("|||| - " .. AString:gsub('(.)%z%1','%1'):gsub('%z.([^%z]+)',""))
   --if AString:gsub('.','\0%0%0'):gsub('(.)%z%1','%1'):gsub('%z.([^%z]+)',"") == "" then
   if AString:gsub("^" ..  AChar .. "+$","") == "" then   
      Result = true
   end
   return Result 
end

--------------------------------------------------------------------------------
function splitpairs(AString, Token)            
   if (AString == "") or (AString == nil) then return {} end    
   if string_find(AString, Token) == nil then return {AString} end
    
   local result = {}
   local pat = "(.-)" .. Token .. "()"
   local nb = 0
   local lastPos
   local CurrentKey = ""
   local CurrentPair = 0
    
   for part, pos in string_gmatch(AString, pat) do
      nb = nb + 1        
      if CurrentPair == 0 then
         CurrentKey = part
         CurrentPair = 1         
      else         
        result[CurrentKey] = part
        CurrentPair = 0                    
     end
     lastPos = pos
    end    
    
    if CurrentPair == 1 then -- Add the last field
      result[CurrentKey] = string_sub(AString, lastPos)
    end    
    return result    
end

--------------------------------------------------------------------------------
function split(AString, Token)
  --return utils.split(AString, Token)    
   if (AString == "") or (AString == nil) then return {} end    
   if string_find(AString, Token) == nil then return {AString} end
    
   local result = {}
   local pat = "(.-)" .. Token .. "()"
   local nb = 0
   local lastPos
    
   for part, pos in string_gmatch(AString, pat) do
       nb = nb + 1
       result[nb] = part
       lastPos = pos    
   end
    
   result[nb + 1] = string_sub(AString, lastPos) -- Add the last field
    
   return result  
end

--------------------------------------------------------------------------------
function splitN(AString, SplitLength)    
    
   if (AString == "") or (AString == nil) then return {} end
    
   if #AString < SplitLength then return {AString} end
                      
   local ACount = math_floor(#AString / SplitLength)
   local AStart = 1
   local AEnd = SplitLength
   local AResult = {}
   
   for I = 1, ACount do
     table_insert(AResult, string_sub(AString,AStart,AEnd))
     AStart = AStart + SplitLength
     AEnd = AEnd + SplitLength
   end
      
   if AStart < #AString then
     table_insert(AResult, string_sub(AString,AStart))
   end
    
   return AResult
end

--------------------------------------------------------------------------------
function UnixTimeToDiscTime( Tick )
   
   --Converts a UNIX Time into an array containing elements of the Discworld time.
   if Tick==nil then Tick = os_time() end --Default to Now.    
   
   --Arrays containing the names of months, days, cycles, and the number of days in each month.
   month_names = {[0] = 
      "Offle", "February", "March", 
      "April", "May", "June", 
      "Grune", "August", "Spune", 
      "Sektober", "Ember", "December", 
      "Ick", "Off", "Feb", 
      "Mar", "Apr", "May", 
      "Jun", "Gru", "Aug", 
      "Spu", "Sek", "Emb", 
      "Dec", "Ick"}   
   day_names = {[0] = 
      "Octeday", "Monday", "Tuesday", 
      "Wednesday", "Thursday", "Friday", 
      "Saturday", "Sunday", "Oct", 
      "Mon", "Tue", "Wed", 
      "Thu", "Fri", "Sat", "Sun"}      
    days_per_month={[0] = 31,30,31,31,31,30,31,31,31,30,31,31,31}    
    cycles = {[0] = "Prime", "Secundus", "I", "II"}
              
   --Calculating simple elements:
   S = math_floor(math_fmod(Tick, 18)) --Seconds
   M = math_floor(math_fmod(Tick, 18*60)/18) --Minutes
   H = math_floor(math_fmod(Tick, 18*60*24)/(18*60)) --Hours (on the 24 hour clock)
   I = math_fmod(H, 12) if I == 0 then I = 12 end --Hours (on the 12 hour clock)
   j = math_floor(math_fmod(Tick, 18*60*24*400)/(18*60*24)) --Day of the year (0-399)
   w = math_floor(math_fmod(Tick+(18*60*24*5), 18*60*24*8)/(18*60*24)) --The addition makes it start on Octeday instead of Friday.
   Y = math_floor(Tick/(18*60*24*400*2)) + 1966 --Year (four digit number)
   C = math_floor(math_fmod((Tick/(18*60*24*400)),2)) --Cycle (0 -> Prime, 1 -> Secundus)    
   --Calculating which month the time is in.
   
   -- Basically, we pop days off the stack in months at a time until there are less than a month remaining.
   day_stack = j
                                   
   m=0                                       -- 
   while (day_stack>=days_per_month[m]) do
      day_stack = day_stack - days_per_month[m]
      m = m + 1 
   end    
   
   --And then make a correction for the lack of a 0th day of year, before setting the day of the month element.
   d = day_stack + 1 ; 
                          
   --d = day_stack -- Or not, if you want to use zero based month days as well.        
   B = month_names[m] -- Name of the month.
   b = month_names[m + 13] -- TLA of the month.
   A = day_names[w] -- Name of the day.
   a = day_names[w+8] -- TLA of the day.
   P = cycles[C] -- Name of the cycle.
   p = cycles[C+2] -- Roman numberal of the cycle.
   
   if H > 11 then Z = "pm" else  Z = "am" end  -- AM/PM.
   
   --Special Day checks!
   special_day = nil    
   if m==0 and d==1 then
      if C==0 then special_day = "Hogswatch" 
      else special_day = "Crueltide" 
      end
   end
   if m==6 and d==16 then
      special_day = "Small Gods day"
   end
   if m==7 and d==23 then
      special_day = "Soul Cake Tuesday"
   end
   if m==9 and d==1 then
      special_day = "Sektober Fools' Day"
   end   
   if special_day then D=special_day else D=A end        
   
   return S, M, H, Z, I, j, w, Y, C, m, d, B, b, A, a, P, p, special_day, D
      
    --S     Seconds (no leading zeroes added)    --M     Minutes (no leading zeroes added)
    --H     Hours (24) (no leading zeroes added) --Z     am/pm
    --I     Hours (12)                           --j     Day of Year (0 - 399)
    --w     Day of Week as Number                --Y     Year
    --C     Cycle as number (0 - 1)              --m     Month of year as number
    --d     Day of month                         --B     Month of year as string
    --b     Month of year as abbreviated string  --A     Day of week as string
    --a     Day of week as abbreviated string    --P     Cycle as string
    --p     Cycle as abbreviated string --special_day Does what it says
    --D     if not a special day then the day of the week else the day name
end
