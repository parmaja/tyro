--------------------------------------------------------------------------------
--//DiscUI Output Scrollbar
--------------------------------------------------------------------------------

UIWindowOutputScrollbar = {}

function UIWindowOutputScrollbarCreate()      
   UIWindowOutputScrollbar = UIWindowCreate("OutputScrollbar", UIMushClientWidth()-UI_BarRightWidth, UI_BarTopHeight, UI_BarRightWidth, UIMushClientHeight()-UI_BarTopHeight, 4)
   UIWindowOutputScrollbar.TitleBarText = "OutputScrollbar"
   --UIWindowOutputScrollbar.SetLeft(UI_BarLeftWidth+300)   
   --UIWindowOutputScrollbar.SetHeight(UI_BarTopHeight)
   --UIWindowOutputScrollbar.SetWidth(UIMushClientWidth()-(UI_BarLeftWidth+300))             
   UIWindowOutputScrollbar.Anchor.Left = false
   UIWindowOutputScrollbar.Anchor.Top = true
   UIWindowOutputScrollbar.Anchor.Right = true
   UIWindowOutputScrollbar.Anchor.Bottom = true
   
      
   
   
   local ALeft = 0
   local ATop = 0
   local ARight = UIWindowOutputScrollbar.Width
   local ABottom = UIWindowOutputScrollbar.Height     
   UIWindowOutputScrollbar.Scrollbar = UIWindowOutputScrollbar.WidgetCreate(UIWidget_Scrollbar, ALeft, ATop,  ARight,  ABottom)         
   UIWindowOutputScrollbar.Scrollbar.Anchor.Left = true
   UIWindowOutputScrollbar.Scrollbar.Anchor.Top = true
   UIWindowOutputScrollbar.Scrollbar.Anchor.Right = false
   UIWindowOutputScrollbar.Scrollbar.Anchor.Bottom =  true                  
   
   --Add Properties        
   --UIWindowOutputScrollbar.HotSpotGraph = "HotSpotMap"
   --result = WindowAddHotspot(UIWindowOutputScrollbar.MushWindow, UIWindowOutputScrollbar.HotSpotMap, 
   --UIWindowOutputScrollbar.ViewPort.Left,UIWindowOutputScrollbar.ViewPort.Top,UIWindowOutputScrollbar.ViewPort.Right,UIWindowOutputScrollbar.ViewPort.Bottom,   
   --"", "", "", "", "", "", 3, 0)      
   --result = WindowDragHandler(UIWindowOutputScrollbar.MushWindow, UIWindowOutputScrollbar.HotSpotMap, "UIWindowMapMouseDragMove", "UIWindowMapMouseDragEnd", 0)    
   --result = WindowScrollwheelHandler(UIWindowOutputScrollbar.MushWindow, UIWindowOutputScrollbar.HotSpotMap, "UIWindowMapMouseWheel")
   

   
   -- Assign Callbacks (or is it a copy of the function? who cares? I want a sandwich.)
   UIWindowOutputScrollbar.OnRender = UIWindowOutputScrollbarRender         
   UIWindowOutputScrollbar.Render()         
   UIWindowOutputScrollbar.Show()
       
end

function UIWindowOutputScrollbarRender(ADelta)
   UIWindowOutputScrollbarUpdateFromClient()
end

function UIWindowOutputScrollbarUpdateFromClient()
         
   local FFontHeight = GetInfo(212)  --212 - Output font height
   local FOutputTop = GetInfo(291) -- Text rectangle - top actual
   local FOutputBottom = GetInfo(293) -- Text rectangle - bottom actual    
   local FOutputHeight = FOutputBottom-FOutputTop
   local FLinesVisibleCount = math.ceil(FOutputHeight / FFontHeight)   
   -- subtract visible line count so we get a 0..100 range
   local FLinesCount = GetInfo(224) -- FLinesVisibleCount --224 - Count of lines in output window
   -- GetInfo(296) returned in pixels
   local FScrollPosition = math.ceil(GetInfo(296) / FFontHeight) --296 - Current vertical position of scroll bar in first output window (long)   
                        
   --Note("FLinesCount " .. FLinesCount) --224 - Count of lines in output window
   --Note("FScrollPosition " .. FScrollPosition)   --296 - Current vertical position of scroll bar in first output window (long)
                  
   UIWindowOutputScrollbar.Scrollbar.SetScrollHeight(FLinesCount)           
   UIWindowOutputScrollbar.Scrollbar.SetPageHeight(FLinesVisibleCount)
   UIWindowOutputScrollbar.Scrollbar.SetScrollY(FScrollPosition)                 
end