--------------------------------------------------------------------------------
--//Global Vaiables
--------------------------------------------------------------------------------

--Debug flags
UI_DebugMain = true
UI_DebugGUI = false
UI_DebugDatabase = false
UI_DebugCharacter = true

UI_DebugMapRender = false
UI_DebugMapBuffer = false
UI_DebugMapRegions = true
UI_DebugMapSectors = false
UI_DebugMapRooms = false
UI_DebugMapStreets = false
UI_DebugMapCapture = false
UI_DebugMapPath = false


--EditMode
UI_EditMode = 0

--Global Flags
UIEnableDBWrite = false
UIEnableMapMergeRoom = false
UIEnableMapMergeSector = false

--Global DiscUI variables
UI_BarTopHeight = 280
UI_BarLeftWidth = 600
UI_BarRightWidth = 25

--------------------------------------------------------------------------------
--//System Requires
--------------------------------------------------------------------------------

require("socket") --//Socket functions
require("sqlite3") --//sqlite database

--require("json") --json functionality
--require("serialize") --//serialize table to string
--require("mw") --//Miniwindow helpers/popups
--require("movewindow") --//MiniWindow Drag/move helper
 
--------------------------------------------------------------------------------
--//DiscUI Requires
--------------------------------------------------------------------------------

--System
require("DiscUI_Math")  --//DiscUI Math functions / types
require("DiscUI_Utils")  --//DiscUI utility functions
require("DiscUI_Database")  --//DiscUI Database functions
require("DiscUI_Font")  --//DiscUI Font

--MUD Client interfaces

------------------------------
--TODO : Detect MUD Client, add mudlet support, examine possibly add cmud support (zmud?) 
------------------------------
require("DiscUI_InterfaceMush")  --//DiscUI MushClient settings/functions



--DiscUI Modules
require("DiscUI_Image") --//DiscUI Image Class
require("DiscUI_Surface") --//DiscUI RenderBuffer

require("DiscUI_Character")  --//DiscUI Character Data / functions
require("DiscUI_Stats")  --//DiscUI Stats/functions

require("DiscUI_Capture")  --//DiscUI Capturing map / objects etc


require("DiscUI_Map")  --//DiscUI Map Types / utility functions
require("DiscUI_MapCaptureRender")  --//DiscUI Map Capture Rendering
require("DiscUI_MapDB")  --//DiscUI Map Database Read/Write                                                  
require("DiscUI_MapBuffer")  --//DiscUI Map Buffer
require("DiscUI_MapPath") --//DiscUI Map A* Path Finding


require("DiscUI_MapRender")  --//DiscUI Map Rendering
require("DiscUI_MapRenderCache")  --//DiscUI Map Cache Rendering

require("DiscUI_MapRenderGrid") --//DiscUI Map Render Grid


--require("DiscUI_TreeNode")  --//DiscUI Map Rendering

--DiscUI Widgets
require("DiscUI_Widget")
require("DiscUI_WidgetLabel")
require("DiscUI_WidgetButton")
require("DiscUI_WidgetEditBox")
require("DiscUI_WidgetDropdown")
require("DiscUI_WidgetListview")
require("DiscUI_WidgetTreeview")
require("DiscUI_WidgetMemo")
require("DiscUI_WidgetBar")
require("DiscUI_WidgetGraph")
require("DiscUI_WidgetScrollbar")

--DiscUI Window
require("DiscUI_Window")  --//DiscUI Windows/functions
require("DiscUI_WindowPopup")  --//DiscUI Windows/functions


--DiscUI Applications
require("DiscUI_WindowOutputScrollbar")  --//DiscUI Output Scrollbar
require("DiscUI_WindowMap")  --//DiscUI Map Window
require("DiscUI_WindowMapLocal") --//DiscUI Local Map Window
require("DiscUI_WindowMapInfo")  --//DiscUI Map Info Window
require("DiscUI_WindowMapSearch")  --//DiscUI Map Search Window
require("DiscUI_WindowMapEdit")  --//DiscUI Map Edit Window

require("DiscUI_WindowOptions")  --//DiscUI DW Options Window

require("DiscUI_WindowStats")  --//DiscUI Stats Window
require("DiscUI_WindowBars") --DiscUI Bars Window
require("DiscUI_WindowTalker")  --//DiscUI Talker Window

--Main
require("DiscUI_Console")  --//DiscUI Console

--Auto
require("DiscUI_Auto") --DiscUI Auto

--------------------------------------------------------------------------------
--//DiscUI Main Variables
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
--//DiscUI Main Functions
--------------------------------------------------------------------------------


function UIMain()
   if UI_DebugMain then
      UILog("UIMain","Initializing DiscUI")   
   end
   
   --Initialize   
   UIDatabaseOpen()      
   UIMapColoursRead()
                
   UIWindowsHostWidth = UIMushClientWidth()
   UIWindowsHostHeight = UIMushClientHeight() 
               
   UIMapBuffer = UIMapBufferCreate() --Create Main Map Buffer   
   UICharacter = UICharacterCreate() --Create Main Character Object
   UIStats = UIStatsCreate() --Create main Stats Object   
         
   --Create Windows
   
   UIWindowOutputScrollbarCreate()
                  
   
   UIWindowMapCreate(UIMapBuffer)
   UIWindowMapInfoCreate()
                               
   UIWindowMapEditCreate(UIMapBuffer)
      
         
   UIWindowMapSearchCreate(UIMapBuffer)   
   UIWindowMapLocalCreate(UIMapBuffer)
   UIWindowOptionsCreate(UIMapBuffer)
   
   UIWindowMapLocal.GroupWindow(UIWindowMapSearch)
   UIWindowMapLocal.GroupWindow(UIWindowOptions)
                    
   
   UIWindowStatsCreate()
   UIWindowTalkerCreate()   
   
   UIWindowStats.GroupWindow(UIWindowTalker)      

   
   UIWindowBarsCreate()
   
   --colours test
     
   --for I = 1, #UIMapColours do                      
      --world.Note("Read UIMapColours - ID:" .. I .. " Colour:"  .. UIMapColours[I])   
   --end     
                       
   --Configure MUD Client
   UIMushScrollbarVisible(false)                              
   UIMushSetTextRectangle(UI_BarLeftWidth+1, UI_BarTopHeight+1,UIMushClientWidth()-(UI_BarRightWidth+1), 0)
   
   --Repaint()   
   --UIMushCaptureKeyboard(true)
        
   --void SetClipboard(BSTR Text);   
   --BSTR GetClipboard();
   
   --(SetBackgroundColour) Sets a background colour for the output window
   --long SetBackgroundColour(long Colour);
   -- 0xFFFFFFFF  -- reset to default
   -- returns the previous background colour.
   
   --(SetBackgroundImage) Sets a background image for the output window
   --long SetBackgroundImage(BSTR FileName, short Mode); 
         
   --local ARed, AGreen, ABlue = UIColourToRGB(0xFFFFFF)   
   --world.Note("R:"..ARed.." G:"..AGreen.." B:"..ABlue)
   
   
   if UI_DebugMain then
      UILog("UIMain","Finished Initializing DiscUI")   
   end
            
end


--------------------------------------------------------------------------------
function UIMainTimerSecondAnimate()

   --if UIWindowMap.CameraAnimateFlag then
   --   UIWindowMap.Render()
   --  
   --end  
  TickleCo()  
end
--------------------------------------------------------------------------------
function UIMainTimerSecondFast()
   --Note("[TimerFast]")
   UICharacter.UpdateEstimates()
   UIStats.UpdateEstimates()
   
   --Update UIAuto System
   AutoUpdateFast() 
end

--------------------------------------------------------------------------------
function UIMainTimerSecondMedium()
   --Note("[TimerMedium]")
   UIWindowOutputScrollbar.Render()

   --Update UIAuto System
   AutoUpdateMedium()
end

--------------------------------------------------------------------------------
function UIMainTimerSecondSlow()
   --Note("[TimerSlow]")
   
	--Update UIAuto System
   AutoUpdateSlow() 
end
   
   

--[[
------------------------------------------------------------------------------------------------------------
-- This creates the funky metatable that lets us use MUSHClient variables (which persist) as Lua variables--
--	(which don't). Awesome, no? It uses a metatable, where the __index value refers to a function that	  --
--	defines what happens when a value is retrieved, and the __newindex value to a function that defines   --
--	what happens when a value is created.                                                                 --
--                                                                                                        --
-- Due to the case-insensitive and string-valued nature of MUSHClient variables, though, some on-the-fly  --
--	type correction is required, and the table's elements are all also case-insensitive.                  --
------------------------------------------------------------------------------------------------------------
mushvar = {}	-- variables table
--
setmetatable (mushvar, 
 { 
   -- called to access an entry
	__index = 
  function (t, name) 
    name=string.lower(name)
    tempvalue = tonumber( GetVariable (name) )
    if tempvalue == nil then
      tempvalue = GetVariable(name)
    end
    return tempvalue
  end;
 
  -- called to change or delete an entry
  __newindex = 
  function (t, name, val) 
  name=string.lower(name)
  local result
	  if val == nil then	-- nil deletes it
		  result = DeleteVariable (name)
	  else
		  result = SetVariable (name, tostring (val)) 
	  end
	   
	  -- warn if they are using bad variable names
	  if result == error_code.eInvalidObjectLabel then
		  error ("Bad variable name '" .. name .. "'")
	  end
  end;
 })

if world.GetVariable("FirstChecker") == nil then
	mushvar.FirstChecker = 1
	mushvar.AttainedXP=0
	mushvar.TotalTime=1  -- This value is used to calculate XP means. If it were 0, there would be a possibility of a div/0 error.
end 

--]]