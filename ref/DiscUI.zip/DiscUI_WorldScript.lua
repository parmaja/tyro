--------------------------------------------------------------------------------
--//DiscUI MushClient WorldScript Functions
--------------------------------------------------------------------------------

function QuitDiscworld()
   world.Execute("quit")
end -- QuitDiscworld