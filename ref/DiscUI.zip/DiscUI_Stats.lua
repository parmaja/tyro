--------------------------------------------------------------------------------
--//DiscUI Stats
--------------------------------------------------------------------------------
local UIStatsCounter = 0
local UIStatList = {} 

UIStats = {}


function UIStatsCreate()
   --create self instance
   local self = {}
   self.id = UIStatsCounter
   UIStatsCounter = UIStatsCounter + 1

   -----------------------------------------------------------------------------
   --Private                                                             Private
   -----------------------------------------------------------------------------   
          
   -----------------------------------------------------------------------------
   --Public                                                               Public
   -----------------------------------------------------------------------------
   
   self.Blocks = {}
   self.BlocksCount = 0
   self.BlockLength = 0    
   self.BlockDuration = (1000*60) * 5 --(5 minutes)  
   -----------------------------------------------------------------------------
   function self.Clear()      
      for I = 1,self.BlocksCount do
         for K = 1,self.BlockLength do
         self.Blocks[I][K] = nil
         end
         self.Blocks[I] = nil         
      end      
      self.Blocks = {} 
   end   
   -----------------------------------------------------------------------------
   function self.SampleAdd(ASampleKey, ASampleValue)
      local ASample = {}
      ASample[ASampleKey] = ASampleValue
      ASample.TimeStamp = UIMushGetTime()               
      table.insert(FSamples,ASample)     
   end
   
   function self.BlockSetCount(ABlockCount)            
      --Clear any previous blocks
      for I = 1,self.BlocksCount do
         for K = 1,self.BlockLength do
         self.Blocks[I][K] = nil
         end
         self.Blocks[I] = nil         
      end      
      self.Blocks = {}
            
      --Set count and initialize blocks
      self.BlocksCount = ABlockCount
      for I = 1,self.BlocksCount do
         self.Blocks[I] = {}
         for K = 1,self.BlockLength do      
         self.Blocks[I][K] = 0
         end         
      end
   end
   
   function self.BlockSetLength(ABlockLength)      
      for I = 1,self.BlocksCount do        
         for K = 1,self.BlockLength do      
            self.Blocks[I][K] = nil
         end
         self.Blocks[I] = {}                                   
      end      
      self.BlockLength = ABlockLength
      for I = 1,self.BlocksCount do
         self.Blocks[I] = {}
         for K = 1,self.BlockLength do      
            self.Blocks[I][K] = 0
         end                                   
      end
   end 
   
   function self.UpdateEstimates()
   
   end
   
   -----------------------------------------------------------------------------
   --Constructor                                                     Constructor
   -----------------------------------------------------------------------------
                     
   self.BlockSetCount(1)
   self.BlockSetLength(256)                     
                     
   table.insert(UIStatList,self)   
   return self      
end

