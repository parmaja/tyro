--------------------------------------------------------------------------------
--//DiscUI MUSHClient Interface
--------------------------------------------------------------------------------

--local references
local string_find = string.find
local string_sub = string.sub

local KeyboardCapture = false
local KeyboardChar = ""

local MXPObjectLivingFlag = false
local MXPObjectFloorFlag = false



local GMCPDebug = 0
local IAC = 0xFF 
local SB = 0xFA
local SE = 0xF0
local DO = 0xFD 
local GMCP = 201

function Send_GMCP_Packet(APacket)
   if (APacket) then
      SendPkt (string.char (IAC, SB, GMCP) .. (string.gsub (APacket, "\255", "\255\255")) .. string.char (IAC, SE))  
   else
  
   end   
end

function OnPluginTelnetRequest(msg_type, data)
  if msg_type == GMCP and data == "WILL" then
    return true
  end -- if

  if msg_type == GMCP and data == "SENT_DO" then
    Note("DiscUI : GMCP Enable")
    -- This hard-coded block may need to be made into a config table as we add more message types.
    Send_GMCP_Packet(string.format('Core.Hello { "client": "MUSHclient", "version": "%s" }', Version()))                   
    Send_GMCP_Packet('Core.Supports.Set [ "Char.Vitals", "Window.Frame.map" ]')
    --Send_GMCP_Packet('Core.Supports.Set [ "Window.Frame.map" ]')
    return true
  end

  return false
end

------------------------------------------------------------------------------------------------
-- Mushclient callback function when telnet SB data received.
------------------------------------------------------------------------------------------------
function OnPluginTelnetSubnegotiation(msg_type, data)   
   if msg_type ~= GMCP then return end
   
   data = string.gsub(data, "&quot;", string.char(34)) -- MM fix      
   local message, params = string.match(data, "([%a%d%-%_%.]+)%s+(.*)") -- MM fix: regex

   if not message then return end
 
   if (GMCPDebug > 1) then
      Note("message: " .. message)
      Note("params: " .. params)
   end
        
   if message == "Char.Vitals" then                   
      params = string.sub(params,2,#params-1)                          
      params = string.gsub(params, "\"", "")                  
      params = string.gsub(params, ":", ",")                  
      local vitals = splitpairs(params, ",")
            
      for Key,Value in pairs(vitals) do
         UICharacter.SetValueFromMUD(Key,Value)
         --Note("Key : " .. Key .. " Value : " .. Value)
      end
          
   elseif message == "Window.Frame.map" then
      params = string.sub(params,2,#params-3) -- -3 to skip last new line       
      UIMapCaptureMapDataGMCP = {}      
      --Note("MAaAP: \["..params.."\]")         
      UIMapCaptureMapDataGMCP = split(params, "\\n")
      
      EnableTrigger ("TriggerMapRoomName", true) -- start capturing room name           
      
      --for _,line in pairs(UIMapCaptureMapDataGMCP) do
      --   Note("MAaAP: \["..line.."\]")
      --end
                     
   end    
end

function UIMushGetTime()
   return socket.gettime()
end

function UIMushGetTimeMS()
   return socket.gettime()*1000
end

function UIMushSetTextRectangle(ALeft, ATop, ARight, ABottom)

   TextRectangle(ALeft,ATop,ARight,ABottom, 0, 0x000000, 0, ColourNameToRGB ("black"), 0)     
end

function UIMushScrollbarVisible(ABoolean)
   SetScroll(-2,ABoolean)
end   


function UIMushClientWidth()
   local Value = 0
   Value = math.floor(GetInfo(281)) --Main frame window width       
   --if not Value then
   --Value = GetInfo(264) --World Window Client Width
   --end
   if Value < 1 then
   Value = 100
   end   
   return Value    
end

function UIMushClientHeight()
   local Value = 0
   Value = math.floor(GetInfo(280)) --Main frame window width       
   --if not Value then
   --Value = GetInfo(263) --World Window Client Width
   --end
   if Value < 1 then
   Value = 100
   end
   return Value   
end



function UIMushDoKey(AKey)
   --world.Note("'"..AKey.."'")
   if UIWidgetFocused then
      UIWidgetFocused.Keyboard(AKey,1)      
   end
end

function UIMushCaptureKeyboard(ABoolean)

   -------------------------------------------------------------
   --MUSHClient doesn't provide for keyboards in its script API
   --So we'll abuse the command line and accelerators to
   --create a usable input mechansim
   -------------------------------------------------------------
  
   KeyboardCapture = ABoolean
   if ABoolean then
      AcceleratorTo("BACKSPACE", "UIMushDoKey(\"BKSPACE\")", 12)
      AcceleratorTo("DELETE", "UIMushDoKey(\"DELETE\")", 12)      
      AcceleratorTo("LEFT", "UIMushDoKey(\"LEFT\")", 12)      
      AcceleratorTo("RIGHT", "UIMushDoKey(\"RIGHT\")", 12)
      AcceleratorTo("Up", "UIMushDoKey(\"UP\")", 12)      
      AcceleratorTo("Down", "UIMushDoKey(\"DOWN\")", 12)
      AcceleratorTo("HOME", "UIMushDoKey(\"HOME\")", 12)      
      AcceleratorTo("END", "UIMushDoKey(\"END\")", 12)
      AcceleratorTo("ESC", "UIMushDoKey(\"ESC\")", 12)
         
   else   
      AcceleratorTo("BACKSPACE", "", 0)
      AcceleratorTo("DELETE", "", 0)
      AcceleratorTo("LEFT", "", 0)
      AcceleratorTo("RIGHT", "", 0)
      AcceleratorTo("Up", "", 0)      
      AcceleratorTo("Down", "", 0)
      AcceleratorTo("HOME", "", 0)
      AcceleratorTo("END", "", 0)
      AcceleratorTo("ESC", "", 0)   
   end
   
 
end

--------------------------------------------------------------------------------
--//Timer Callbacks
--------------------------------------------------------------------------------


function TimerCallbackStats(sName, sLine, wildcards)
   
   -- This moves the graph points along one tick when the timer fires
  
   --table.remove (points, 1)
       
   --if isnan( ((xp_phj+1)/1000000)*GRAPH_HEIGHT ) then
   --   table.insert (points, 0) 
   --elseif ((xp_phj+1)/1000000)*GRAPH_HEIGHT > GRAPH_HEIGHT then
   --   table.insert (points, GRAPH_HEIGHT)
   --elseif ((xp_phj+1)/1000000)*GRAPH_HEIGHT < 0 then
   --   table.insert (points, 0)
   --else    
   --   table.insert (points, ((xp_phj+1)/1000000)*GRAPH_HEIGHT)
   --end -- if
     

   --table.remove (pointsxp, 1)

   --if isnan( ((xpdiff+1)/100000)*GRAPH_HEIGHT ) then
   --   table.insert (points, 0) 
   --elseif ((xpdiff+1)/100000)*GRAPH_HEIGHT > GRAPH_HEIGHT then
   --   table.insert (pointsxp, GRAPH_HEIGHT)
   --elseif ((xpdiff+1)/100000)*GRAPH_HEIGHT < 0 then
   --   table.insert (pointsxp, 0)
   --else
   --   table.insert (pointsxp, ((xpdiff+1)/100000)*GRAPH_HEIGHT)
   --end

end

--------------------------------------------------------------------------------
--//Alias Functions
--------------------------------------------------------------------------------


--------------------------------------------------------------------------------
--//MUSHClient Callback Functions
--------------------------------------------------------------------------------

function OnPluginCommand (sText)   
   --  The player has typed the command 'sText'
   --  Return TRUE to process the command, FALSE to discard it      
   local ACommand = sText:lower()
   local ADirection = ""            
   if not (ACommand == "") then
   
      --capture map output trigger; assumes alias of 'm' as 'map;yawn' - uses yawn text to denote end of map, disable trigger
      if string.lower(ACommand) == "m" then
         EnableTrigger("TriggerMapCaptureOutputMap", true)     
         return true
      end 
   
      ADirection = UIMapDirectionMin[ACommand]             
      if not (ADirection == nil) then                  
         UIMapBuffer.MoveDirectionAttempt(ADirection)
         return true
      end
      
      
               
   end                      
   return true -- process command
end   

function OnPluginMXPopenTag(name, args, mylist)
   
   local AObjectName = ""
   local ASplitPos = 0
   
   --world.Note(name)
   
   --Mesa Boogie is standing here and an unkempt pigeon is perched on the street lamp.
   --[Object Living = 'Mesa Boogie']
   --[Object Living = 'unkempt pigeon']
   --[Object Floor = 'street lamp']
   --A street lamp is emitting a grimy light here.
   --[Object Floor = 'street lamp']
   
   if UIMapCaptureRoomObjectsFlag then                       
      if (name == "livingpopup,") then   
         --world.Note("LIVING OBJECT")
         MXPObjectLivingFlag = true
         MXPObjectFloorFlag = false                  
      elseif (name == "floorobjectpopup,") then
         --world.Note("FLOOR OBJECT")
         MXPObjectFloorFlag = true
         MXPObjectLivingFlag = false
      elseif string_sub(name, 1, 5) == "send," then                               
         if MXPObjectLivingFlag then            
            ASplitPos = string_find(name,'|')-1                 
            AObjectName = string_sub(name, 11, ASplitPos)       
            ASplitPos = string_find(AObjectName,' ')+1
            AObjectName = string_sub(AObjectName,ASplitPos)          
            world.Note("[Object Living = '" .. AObjectName .. "']")                               
            table.insert(UIMapCaptureRoomObjectsLiving, AObjectName)                                                                                 
         end         
         if MXPObjectFloorFlag then          
            ASplitPos = string_find(name,'|')-1                 
            AObjectName = string_sub(name, 11, ASplitPos)       
            ASplitPos = string_find(AObjectName,' ')+1
            AObjectName = string_sub(AObjectName,ASplitPos)                
            world.Note("[Object Floor = '" .. AObjectName .. "']")
            table.insert(UIMapCaptureRoomObjectsFloor, AObjectName)                       
         end                                   
      elseif (name == "br,") then 
         if MXPObjectLivingFlag then
            MXPObjectLivingFlag = false
         elseif MXPObjectFloorFlag then
            MXPObjectFloorFlag = false
         else                             
            UIMapCaptureRoomObjectsFlag = false
            --TODO should be a callback
            UIWindowMapLocal.Render()                        
         end                                      
      else --some other MXP tag
         
         --between livingpopups can sometimes be yellow tags so don't break on these   
         if not (name == "yellow,") and not (name == "c,'yellow'") then
            --if flags are set and we've not got br, send, livingpopup, or floorobjectpopup, then we're finished capturing               
            if (MXPObjectLivingFlag) or (MXPObjectFloorFlag) then
               UIMapCaptureRoomObjectsFlag = false
               MXPObjectFloorFlag = false
               MXPObjectLivingFlag = false
               --TODO should be a callback
               UIWindowMapLocal.Render()
            end
            
         end         
      end
   end
               
   -- we use the mxp tag for reliability
   if name == "talker," then      
      EnableTrigger("TriggerCaptureChat", true)       
   end   
end

function OnPluginMXPerror(level, number, line, message)
   if level == 1009 then
      Note("MXP ERROR Inavlid Element : " .. message)
      
   
   end
end


function OnPluginMXPsetVariable(AName, AValue)
   Note ("OnPluginMXPsetVariable " .. AName .. " = " .. AValue)
end

  
function OnCombatTrigger(iHP, iMaxHP, iGP, iMaxGP, iXP)
   
   --mushvar.MaxHP = iMaxHP
   --mushvar.MaxGP = iMaxGP
   --OnPluginMXPsetEntity ("hp="..iHP)
   --OnPluginMXPsetEntity ("xp="..iXP)
   --OnPluginMXPsetEntity ("gp="..iGP)
   
end
 
    
function OnPluginMXPsetEntity(sIn)   
   local values = utils.split(sIn, '=')         
   UICharacter.SetValueFromMUD(values[1], values[2]) 
end


function OnPluginWorldOutputResized()
   --This is called when the output window is resized.   
   UIMushScrollbarVisible(false)
      
   if (UIMushClientWidth() == UIWindowsHostWidth) and (UIMushClientHeight() == UIWindowsHostHeight) then return end
   
   --Note("OnPluginWorldOutputResized UIMushClientWidthHeight : [" ..UIMushClientWidth()..","..UIMushClientHeight().."]") 
   
   UIWindowsHostResize(UIMushClientWidth(), UIMushClientHeight())
   
   UIMushSetTextRectangle(UI_BarLeftWidth+1, UI_BarTopHeight+1,UIMushClientWidth()-(UI_BarRightWidth+1), 0)
                  
   --resize output text rectangle   
   --if UIWindowTalker.Bottom then
      
   --   UIMushSetTextRectangle(UI_BarLeftWidth+1, UIWindowTalker.Bottom,UIMushClientWidth()-(UI_BarRightWidth+1), 0)
   --else
   --   UIMushSetTextRectangle(UI_BarLeftWidth+1, 0,UIMushClientWidth()-(UI_BarRightWidth+1), 0)
   --end   
      
end

function OnPluginCommandChanged()
   --The contents of the command window has changed.
   if KeyboardCapture then
      KeyboardChar = ""
      KeyboardChar = world.GetCommand()
      
      world.SetCommandSelection(1,-1)
      world.PasteCommand("")
        
      if UIWidgetFocused then
         UIWidgetFocused.Keyboard(KeyboardChar, 1)
      end
       
   else
      UIPopupWindowHideAll()
   end
   --world.Note("OnPluginCommandChanged")
end -- function

function OnPluginLoseFocus()
   -- The world to which the plugin belongs is losing the focus
   UIPopupWindowHideAll()
   --world.Note("OnPluginLoseFocus")
end -- function 

--function OnPluginTick ()
   -- This is called 25 times a second.
   --if UIWindowMap.CameraAnimateFlag then
   --   UIWindowMap.Render()
   --  
   --end  
    
   --Repaint()
--   TickleCo()    
   --return 0
--end -- function OnPluginTick


function OnPluginDrawOutputWindow (firstline, offset, notused)
  if UIWindowOutputScrollbar then
      UIWindowOutputScrollbar.Scrollbar.SetScrollY(firstline)
      UIWindowOutputScrollbar.Render()      
  end
  --[[
  local background_colour = ColourNameToRGB ("lightgray")
  local text_colour = ColourNameToRGB ("green")
  local main_height = GetInfo (263)
  local font_height = GetInfo (212)

  -- clear window  
  WindowRectOp (win, miniwin.rect_fill, 0, 0, 0, 0, background_colour)

  -- allow for scrolling position
  local top =  (((firstline - 1) * font_height) - offset) - 2

  -- how many lines to draw
  local lastline = firstline + (main_height / font_height)
  
  for line = firstline, lastline do
    if line >= 1 and GetLineInfo (line, 1) then
      WindowText (win, font, line .. ": " .. GetLineInfo (line, 1), 0, top, 
                  0, 0, text_colour)
      top = top + font_height  
    end -- if line exists
  end -- for each line
  --]]
end -- OnPluginDrawOutputWindow

--[[
function OnPluginClose()

end

function OnPluginConnect()

end

function OnPluginDisconnect()

end

function OnPluginEnable()
                 
end

function OnPluginDisable()

end

function OnPluginGetFocus()
   -- The world to which the plugin belongs is getting the focus
   --world.Note("OnPluginGetFocus")
end -- function

function OnPluginMouseMoved(x, y, mw)
   -- This is called when the mouse is moved inside the output window.
   --The x and y arguments (long integers) give the location of the mouse, relative to the top-left corner of the current world's output window.
   --The third argument is the miniwindow ID of any miniwindow the mouse may happen to be over, or "" if it is not over a miniwindow.
   --world.Note("OnPluginMouseMoved:["..x..","..y.."]")
  return 0
end

--]]
