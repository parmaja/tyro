--//DiscUI Database

--------------------------------------------------------------------------------
--//DiscUI Database Variables
--------------------------------------------------------------------------------

UIDatabase = "DiscUI"
UIDatabasePath = "DiscUI.db"

UIDatabaseMap = "DiscMap"
UIDatabaseMapPath = "DiscMap.db"

UIDatabaseStats = "DiscStats"
UIDatabaseStatsPath = "DiscStats.db"

--------------------------------------------------------------------------------
--//DiscUI Database Functions
--------------------------------------------------------------------------------

-- check for errors on a DatabaseXXXXX call
function UIDatabaseResultCheck(ACheckCode)
   if ACheckCode == sqlite3.OK or       -- no error
      ACheckCode == sqlite3.ROW or      -- completed OK with another row of data
      ACheckCode == sqlite3.DONE then   -- completed OK, no more rows
      return ACheckCode -- if ACheckCode OK
   end
end 


function UIDatabasePrepareString(AString)
   if AString then
        -- replace single quotes with two lots of single quotes
        return "'" .. (string.gsub (AString, "'", "''")) .. "'"       
   else
      return "NULL"
   end
end


  
function UIDatabaseOpen()
   if UI_DebugDatabase then
      UILog("UIDatabaseOpen","Opening databases",0)
   end   
   DatabaseOpen(UIDatabase, UIDatabasePath, 6)
   DatabaseOpen(UIDatabaseMap, UIDatabaseMapPath, 6)   
   DatabaseOpen(UIDatabaseStats, UIDatabaseStatsPath, 6)
end

function UIDatabaseClose()
   if UI_DebugDatabase then
      UILog("UIDatabaseClose","Closing databases",0)
   end   
   DatabaseClose(UIDatabase)
   DatabaseClose(UIDatabaseMap)
   DatabaseClose(UIDatabaseStats)                  
end



function UIDatabaseArrayReadValue(ADatabase, AArray, ATable, AFieldValue, AWhereField, AWhereValue, AOrderField)      
   local AQuery = ""
   
   AQuery = "SELECT "..AFieldValue.." FROM "..ATable   
   if AWhereField then AQuery = AQuery.." WHERE ("..AWhereField.." = "..AWhereValue ..")" end
   if AOrderField then AQuery = AQuery.." ORDER BY "..AOrderField end
       
   DatabasePrepare(UIDatabaseMap, AQuery)      
   local ColumnCount = DatabaseColumns(UIDatabaseMap)      
   local ColumnNames = DatabaseColumnNames(UIDatabaseMap)         
   local Row = DatabaseStep(UIDatabaseMap)   
   local RowValues = {}
   local I = 1         
   --world.Note("DB Column Count:" .. ColumnCount)          
   -- Loop Result Rows
   while Row == sqlite3.ROW do        
      RowValues = DatabaseColumnValues(UIDatabaseMap)            
      AArray[I] = RowValues[1]                            
      Row = DatabaseStep(UIDatabaseMap)
      I=I+1
   end    
   DatabaseFinalize(UIDatabaseMap)   
end

function UIDatabaseArrayReadKeyValue(ADatabase, AArray, ATable, AFieldKey, AFieldValue, AWhereField, AWhereValue, AOrderField)            
   local AQuery = ""
   
   AQuery = "SELECT "..AFieldKey..","..AFieldValue.." FROM "..ATable   
   if AWhereField then AQuery = AQuery.." WHERE "..AWhereValue.." = "..AWhereValue end
   if AOrderField then AQuery = AQuery.." ORDER BY "..AOrderField end
       
   DatabasePrepare(UIDatabaseMap, AQuery)      
   local ColumnCount = DatabaseColumns(UIDatabaseMap)      
   local ColumnNames = DatabaseColumnNames(UIDatabaseMap)         
   local Row = DatabaseStep(UIDatabaseMap)   
   local RowValues = {}           
   --world.Note("DB Column Count:" .. ColumnCount)          
   -- Loop Result Rows
   while Row == sqlite3.ROW do        
      RowValues = DatabaseColumnValues(UIDatabaseMap)            
      AArray[RowValues[1]] = RowValues[2]                             
      Row = DatabaseStep(UIDatabaseMap)      
   end    
   DatabaseFinalize(UIDatabaseMap)     
end
