--------------------------------------------------------------------------------
--//DiscUI Window
--------------------------------------------------------------------------------
local UIWindowCounter = 0 -- Global private variable

local UIWindowDefaultHeight = 300
local UIWindowDefaultTitleBarHeight = 15

UIWindows = {}

UIWindowsHostWidth = 0
UIWindowsHostHeight = 0

--------------------------------------------------------------------------------
function UIWindowCreate(AWindowName, ALeft, ATop, AWidth, AHeight, AWindowPosition)
   --create self instance
   local self = {}
   self.id = UIWindowCounter
   UIWindowCounter = UIWindowCounter + 1
         
   -- Private variables
   local FFontName = "Consolas"
   local FFontHeight = 10
   local FFontSmallName = "Consolas"
   local FFontSmallHeight = 8
   local FFontTitleBarName = "Consolas"
   local FFontTitleBarHeight = 8
   local FWindowColour = 0x000000
   
   local FLineColour = 0xFFFFFF
   local FRectColour = 0x222222
   local FCircleColour = 0x666666
   local FTextColour = 0xFFFFFF
   local FLineWidth = 0
   
              
   -- Private methods
 
   -- Public variables
   self.MushWindow = AWindowName
   self.Left = ALeft
   self.Top = ATop
   self.Right = ALeft+AWidth
   self.Bottom = ATop+AHeight   
   self.Width = self.Right-self.Left
   self.Height = self.Bottom-self.Top 
   self.Anchor = {}
   self.Anchor.Left = true
   self.Anchor.Top = true
   self.Anchor.Right = false
   self.Anchor.Bottom = false
   
   self.Font = "WindowFont" .. self.id
   self.FontSmall = "WindowFontSmall" .. self.id    
   
   self.TitleBarVisible = true
   self.TitleBarText = "Window"
    
   self.TitleBarHeight = UIWindowDefaultTitleBarHeight
   local FTitleBarHeightVisible = UIWindowDefaultTitleBarHeight
      
   self.TitleBarFont = "TitleBarFont" .. self.id
   
   self.ColourTitleShadow = 0x202020
   self.ColourTitle = 0xFFFFFF
   
   self.Widgets = {}
   
   self.Group = {}
   
   self.Hotspot = ""
   
   --flags
   self.IsHovering = false
      
   -- Callbacks   
   self.OnRender = nil
   self.OnMouseMove = nil
   self.OnMouseButton = nil
   self.OnMouseWheel = nil
   self.OnKeyboard = nil
      
   -- Public methods:
   
   -----------------------------------------------------------------------------
   --//Rendering
   -----------------------------------------------------------------------------

   -----------------------------------------------------------------------------
   function self.LineColour(AColour)
      FLineColour = AColour
   end
   
   -----------------------------------------------------------------------------
   function self.RectColour(AColour)
      FRectColour = AColour
   end
   
   function self.CircleColour(AColour)
      FCircleColour = AColour
   end
   
   -----------------------------------------------------------------------------
   function self.TextColour(AColour)
      if AColour == nil then
         FTextColour = 0xFFFFFF
      else
         FTextColour = AColour
      end
   end  
   
   function self.LineWidth(AWidth)
      FLineWidth = AWidth
   end 
      
   -----------------------------------------------------------------------------   
   function self.Line(AStartX,AStartY,AEndX,AEndY,APenStyle)
      if not APenStyle then APenStyle = 0 end
      WindowLine(self.MushWindow, AStartX, AStartY, AEndX, AEndY, FLineColour, APenStyle, FLineWidth)
   end
      
   -----------------------------------------------------------------------------   
   function self.Rect(ALeft,ATop,ARight,ABottom)
      WindowRectOp(self.MushWindow, 2, ALeft, ATop, ARight, ABottom, FRectColour)      
   end
       
   -----------------------------------------------------------------------------
   function self.RectOutline(ALeft,ATop,ARight,ABottom)
   -- Window border
      WindowRectOp(self.MushWindow, 4, ALeft, ATop, ARight, ABottom, FRectColour, FRectColour)  -- Two Colour Border
   end
   
   -----------------------------------------------------------------------------   
   function self.Circle(ALeft,ATop,ARight,ABottom)
      WindowCircleOp(self.MushWindow,1, ALeft, ATop, ARight, ABottom, FLineColour, 0, FLineWidth, FCircleColour, 0) -- circle   
   end
   
   -----------------------------------------------------------------------------   
   function self.CircleOutline(ALeft,ATop,ARight,ABottom)
      WindowCircleOp(self.MushWindow,1, ALeft, ATop, ARight, ABottom, FLineColour, 0, FLineWidth, FCircleColour, 0) -- circle   
   end   
   
   -----------------------------------------------------------------------------
   function self.Text(AText, AFont, ALeft, ATop, ARight, ABottom)         
      WindowText(self.MushWindow, AFont, AText, ALeft, ATop, ARight, ABottom, FTextColour)
   end   
   -----------------------------------------------------------------------------
   function self.TextCenter(AText, ALeft, ATop, ARight, ABottom, AFont)            
      WindowText(self.MushWindow, AFont, AText, ALeft, ATop, ARight, ABottom, FTextColour)
   end
   -----------------------------------------------------------------------------
   function self.TextWidth(AText, AFont)      
      local Value = WindowTextWidth(self.MushWindow, AFont, AText) 
      if not Value then
         Value = 10
      end   
   
      return Value
   end
   
   function self.TextHeight(AText,AFont)
      local Value = WindowFontInfo(self.MushWindow, AFont, 1)
      if not Value then
         Value = 10
      end   
   
      return Value
   end
         
   --------------------------------------------------------------------------------
   --//Input
   --------------------------------------------------------------------------------

   -----------------------------------------------------------------------------         
   function self.MouseMove(AMouseX, AMouseY)
   
   end
      
   -----------------------------------------------------------------------------   
   function self.MouseButton(AMouseX, AMouseY, Button, State)
   
      if AMouseY < self.TitleBarHeight then      

         --world.Note("CLICK")               
         
         local AButton = math.floor(#self.Group * (AMouseX / self.Width))+1
                  
         if (AButton >= 1) and (AButton <= #self.Group) then
                  
            --world.Note("Button : " .. AButton)
                     
            self.Show(false)            
            local AWindow = self.Group[AButton]
            AWindow.Render()                  
            AWindow.Show(true)
            
         end
      end   
   end

   -----------------------------------------------------------------------------
   function self.MouseWheel(AMouseX, AMouseY, AWheelDelta)
   
   end
   
   -----------------------------------------------------------------------------
   function self.Keyboard(AChar, State)
   
   end
   
   --------------------------------------------------------------------------------
   --//Widget Functions
   --------------------------------------------------------------------------------
   
   -----------------------------------------------------------------------------
   function self.WidgetCreate(AWidgetType, AWidgetLeft, AWidgetTop, AWidgetRight, AWidgetBottom)      
      
      local AWidget = {}
      
      if AWidgetType == UIWidget_Label then
                 
      elseif AWidgetType == UIWidget_Button then       
         AWidget = UIWidgetButtonCreate(self, AWidgetLeft, AWidgetTop, AWidgetRight, AWidgetBottom)      
      elseif AWidgetType == UIWidget_Editbox then 
         AWidget = UIWidgetEditboxCreate(self, AWidgetLeft, AWidgetTop, AWidgetRight, AWidgetBottom)           
      elseif AWidgetType == UIWidget_Dropdown then      
         AWidget = UIWidgetDropdownCreate(self, AWidgetLeft, AWidgetTop, AWidgetRight, AWidgetBottom)
      elseif AWidgetType == UIWidget_Memo then      
         AWidget = UIWidgetMemoCreate(self, AWidgetLeft, AWidgetTop, AWidgetRight, AWidgetBottom)               
      elseif AWidgetType == UIWidget_Listview then      
         AWidget = UIWidgetListviewCreate(self, AWidgetLeft, AWidgetTop, AWidgetRight, AWidgetBottom)
      elseif AWidgetType == UIWidget_Treeview then      
         AWidget = UIWidgetTreeviewCreate(self, AWidgetLeft, AWidgetTop, AWidgetRight, AWidgetBottom)         
      elseif AWidgetType == UIWidget_Bar then            
         AWidget = UIWidgetBarCreate(self, AWidgetLeft, AWidgetTop, AWidgetRight, AWidgetBottom)
      elseif AWidgetType == UIWidget_Graph then            
         AWidget = UIWidgetGraphCreate(self, AWidgetLeft, AWidgetTop, AWidgetRight, AWidgetBottom)                  
      elseif AWidgetType == UIWidget_Scrollbar then            
         AWidget = UIWidgetScrollbarCreate(self, AWidgetLeft, AWidgetTop, AWidgetRight, AWidgetBottom)         
      end            
      --Add widget to list
      self.Widgets[#self.Widgets+1] = AWidget           
      --table.insert(self.Widgets, AWidget)
      --return index
      return self.Widgets[#self.Widgets]                
   end

   -----------------------------------------------------------------------------   
   function self.WidgetDestroy(AWidgetIndex)
      if (AWidgetIndex > 0) and (AWidgetIndex <= #self.Widgets) then
         self.Widgets[AWidgetIndex] = nil
      end                      
       
   end
   --------------------------------------------------------------------------------
   --//Window Fuctions
   --------------------------------------------------------------------------------

   -----------------------------------------------------------------------------
   function self.GroupWindow(ASisterWindow)
            
      ASisterWindow.Group = self.Group
      table.insert(self.Group, ASisterWindow)
                                     
      ASisterWindow.Show(false)
      self.Show(true)      
      self.Render()            
   end

   -----------------------------------------------------------------------------
   function self.SetTitleBarVisible(AVisible)
         
      if (AVisible) and (not self.TitleBarVisible) then
         self.TitleBarHeight = FTitleBarHeightVisible
         self.TitleBarVisible = true
      elseif (not AVisible) and (self.TitleBarVisible) then
         FTitleBarHeightVisible = self.TitleBarHeight
         self.TitleBarHeight = 0
         self.TitleBarVisible = false      
      end
   end
   
   -----------------------------------------------------------------------------   
   function self.SetPositon(APositionX, APositionY)
   
   end   
     
   function self.SetLeft(ALeft)  
      self.Left = ALeft
      self.Width = self.Right-self.Left          
      WindowPosition(self.MushWindow, self.Left, self.Top, 4, 18)            
   end
   
   -----------------------------------------------------------------------------
   function self.SetTop(ATop)
      self.Top = ATop
      self.Height = self.Bottom-self.Top           
      WindowPosition(self.MushWindow, self.Left, ATop, 4, 18)  
   end
   
   -----------------------------------------------------------------------------
   function self.SetLeftTop(ALeft, ATop)
      self.Left = ALeft
      self.Top = ATop
      self.Width = self.Right-self.Left
      self.Height = self.Bottom-self.Top 
      WindowPosition(self.MushWindow, self.Left, self.Top, 4, 18)       
   end
   
      -----------------------------------------------------------------------------
   function self.SetRight(ARight)
      
      local RelativeX = (ARight-self.Right)
       
      for _, Widget in pairs(self.Widgets) do                  
         if Widget.Anchor.Left and Widget.Anchor.Right then            
            Widget.SetRight(Widget.Right+RelativeX)
         elseif not Widget.Anchor.Left and Widget.Anchor.Right then
            Widget.SetLeft(Widget.Left+RelativeX)
            Widget.SetRight(Widget.Right+RelativeX)                
         end                          
      end
      
      self.Right = ARight
      self.Width = self.Right-self.Left                        
      WindowResize(self.MushWindow, self.Width, self.Height, FWindowColour)      
   end
   
   -----------------------------------------------------------------------------
   function self.SetBottom(ABottom)
   
      local RelativeY = (ABottom-self.Bottom)            
      
      for _, Widget in pairs(self.Widgets) do                  
         if Widget.Anchor.Top and Widget.Anchor.Bottom then            
            Widget.SetBottom(Widget.Bottom+RelativeY)
         elseif not Widget.Anchor.Top and Widget.Anchor.Bottom then
            Widget.SetTop(Widget.Top+RelativeY)
            Widget.SetBottom(Widget.Bottom+RelativeY)                
         end                          
      end 
         
      self.Bottom = ABottom 
      self.Height = self.Bottom-self.Top     
      WindowResize(self.MushWindow, self.Width, self.Height, FWindowColour)      
   end
   
   -----------------------------------------------------------------------------
   function self.SetWidth(AWidth)
      
      local RelativeX = (AWidth-self.Width)
      
      for _, Widget in pairs(self.Widgets) do                  
         if Widget.Anchor.Left and Widget.Anchor.Right then            
            Widget.SetRight(Widget.Right+RelativeX)
         elseif not Widget.Anchor.Left and Widget.Anchor.Right then
            Widget.SetLeft(Widget.Left+RelativeX)
            Widget.SetRight(Widget.Right+RelativeX)                
         end                          
      end
      
      self.Width = AWidth
      self.Right = self.Left+self.Width              
      WindowResize(self.MushWindow, self.Width, self.Height, FWindowColour)      
   end
   
   -----------------------------------------------------------------------------
   function self.SetHeight(AHeight)
   
      local RelativeY = (AHeight-self.Height)
      
      for _, Widget in pairs(self.Widgets) do                  
         if Widget.Anchor.Top and Widget.Anchor.Bottom then            
            Widget.SetBottom(Widget.Bottom+RelativeY)
         elseif not Widget.Anchor.Top and Widget.Anchor.Bottom then
            Widget.SetTop(Widget.Top+RelativeY)
            Widget.SetBottom(Widget.Bottom+RelativeY)                
         end                          
      end 
         
      self.Height = AHeight
      self.Bottom = self.Top+self.Height
      WindowResize(self.MushWindow, self.Width, self.Height, FWindowColour)      
   end
   
   -----------------------------------------------------------------------------
   function self.SetWidthHeight(AWidth,AHeight)
   
      local RelativeX = (AWidth-self.Width)
      local RelativeY = (AHeight-self.Height)
      
      for _, Widget in pairs(self.Widgets) do                  
         if Widget.Anchor.Left and Widget.Anchor.Right then            
            Widget.SetRight(Widget.Right+RelativeX)
         elseif not Widget.Anchor.Left and Widget.Anchor.Right then
            Widget.SetLeft(Widget.Left+RelativeX)
            Widget.SetRight(Widget.Right+RelativeX)                
         end
         if Widget.Anchor.Top and Widget.Anchor.Bottom then            
            Widget.SetBottom(Widget.Bottom+RelativeY)
         elseif not Widget.Anchor.Top and Widget.Anchor.Bottom then
            Widget.SetTop(Widget.Top+RelativeY)
            Widget.SetBottom(Widget.Bottom+RelativeY)                
         end                          
      end
            
      self.Width = AWidth
      self.Height = AHeight
      self.Right = self.Left+self.Width
      self.Bottom = self.Top+self.Height
      WindowResize(self.MushWindow, self.Width, self.Height, FWindowColour)      
   end
   
   -----------------------------------------------------------------------------
   function self.Show(ABoolean)   
      --Show the window      
      WindowShow (self.MushWindow, ABoolean)
   end
   
   -----------------------------------------------------------------------------
   function self.Render()

      --Window
      self.RectColour(0x222222)
      self.Rect(0, 0+self.TitleBarHeight, self.Width, 0+self.Height)
      
      --Titlebar
      if self.TitleBarVisible then      
      
         local ATitleBarColour = 0x555555
         local ATitleBarColourFade = 0x222222
         local AWindow = nil
         local ABarWidth = 0
         local ABarLeft = 0
         local ABarRight = 0                  
          
         ABarWidth = self.Width / #self.Group
      
         for I = 1, #self.Group do
           
            AWindow = self.Group[I]
            ABarLeft = (I-1) * ABarWidth
            ABarRight = (I) * ABarWidth
            
            if AWindow == self then
               ATitleBarColour = 0x666666
               ATitleBarColourFade = 0x222222
            else
               ATitleBarColour = 0x222222
               ATitleBarColourFade = 0x222222          
            end          
            WindowGradient(self.MushWindow, ABarLeft, 0+0, ABarRight, 0+self.TitleBarHeight, ATitleBarColour, ATitleBarColourFade, 2) --1 = horz, 2 = vert               
            --WindowGradient(self.MushWindow, 0, 0+0, self.Width, 0+self.TitleBarHeight/2, 0x222222, 0x555555, 2) --1 = horz, 2 = vert
            --WindowGradient(self.MushWindow, 0, 0+self.TitleBarHeight/2, self.Width, 0+self.TitleBarHeight, 0x555555, 0x222222, 2) --1 = horz, 2 = vert         
            
            -- Titlebar text           
            local TitleTextWidth = self.TextWidth(AWindow.TitleBarText, self.TitleBarFont) 
            local TitleTextHeight = self.TextHeight(AWindow.TitleBarText, self.TitleBarFont)
                                      
            local APosX = ABarLeft + (ABarWidth / 2) - (TitleTextWidth / 2)
            local APosY = (AWindow.TitleBarHeight / 2) - (TitleTextHeight / 2)
                   

                                  
            --Render shadow
            self.TextColour(AWindow.ColourTitleShadow)
            self.Text(AWindow.TitleBarText, self.TitleBarFont, APosX-1, APosY-1, APosX-1 + TitleTextWidth, APosY-1 + TitleTextHeight)      
            self.Text(AWindow.TitleBarText, self.TitleBarFont, APosX+1, APosY+1, APosX+1 + TitleTextWidth, APosY+1 + TitleTextHeight)      
            self.Text(AWindow.TitleBarText, self.TitleBarFont, APosX-1, APosY+1, APosX-1 + TitleTextWidth, APosY+1 + TitleTextHeight)      
            self.Text(AWindow.TitleBarText, self.TitleBarFont, APosX+1, APosY-1, APosX+1 + TitleTextWidth, APosY-1 + TitleTextHeight) 
            
                                   
            self.TextColour(AWindow.ColourTitle)
            self.Text(AWindow.TitleBarText, self.TitleBarFont, APosX, APosY, APosX+TitleTextWidth, APosY+TitleTextHeight)
         
         end
         
     
      end
                              
      --Window border
      self.RectColour(0x555555)
      self.RectOutline(0,0,self.Width,self.Height)
                 
      --Callback                        
      if self.OnRender ~= nil then
         self.OnRender(0.1)
      end

      --Widgets                           
      for I = 1, #self.Widgets do      
         self.Widgets[I].Render()
      end
                       
   end
   
   ---Clear Surface
   function self.Clear()
      self.RectColour(0x00000000)
      self.Rect(0, 0, self.Width, self.Height)
   end   
               
   ---Load an image file, return Image
   function self.ImageLoad(AFileName)
      local AImage = UIImageCreate(self.MushWindow)      
      local AResult = WindowLoadImage(self.MushWindow, AImage.MushImage, AFileName)
      return AImage
   end
      
   ---Save surface to image file 
   function self.ImageSave(AFileName)
      local AResult = WindowWrite(self.MushWindow, AFileName);
   end
   
   ---Create an image from source surface data, return ImageID
   function self.ImageCreate(ASource)
      local AImage = UIImageCreate(self.MushWindow)
      WindowImageFromWindow(self.MushWindow, AImage.MushImage, ASource.MushWindow)
      return AImage
   end
            
   -----------------------------------------------------------------------------
   --Constructor                                                     Constructor
   -----------------------------------------------------------------------------
     
   if UI_DebugGUI then    
      UILog("UIWindowCreate", "Creating Window", 0)
   end
          
         
   WindowCreate(self.MushWindow, self.Left, self.Top, self.Width, self.Height,  AWindowPosition, 2, 0x232323)
   
   --Setup Fonts
   UIFontCreate(self.MushWindow, self.Font, FFontName, FFontHeight,false) 
   UIFontCreate(self.MushWindow, self.FontSmall, FFontSmallName, FFontSmallHeight,false)
   UIFontCreate(self.MushWindow, self.TitleBarFont, FFontTitleBarName, FFontTitleBarHeight,false)
      
   self.Hotspot = "WindowHotSpot" .. self.id                
   WindowAddHotspot(self.MushWindow, self.Hotspot, 
      0,0,self.Width,self.Height,   
      "UIWindowMouseOver", "", "UIWindowMouseDown", "UIWindowMouseCancelDown", "UIWindowMouseUp", "", 3, 0x01)   
      
   
   table.insert(self.Group, self)
           
                    
   UIWindows[self.Hotspot] = self       
   --table.insert(UIWindows, self)
   
   return self
end

-----------------------------------------------------------------------------
function UIWindowsHostResize(AWidth, AHeight)

   if (UIWindowsHostWidth == AWidth) and (UIWindowsHostHeight == AHeight) then return end 

   local RelativeX = AWidth - UIWindowsHostWidth 
   local RelativeY = AHeight - UIWindowsHostHeight 
   
  
   for _,Window in pairs(UIWindows) do
      if Window.Anchor.Left and Window.Anchor.Right then            
         Window.SetRight(Window.Right+RelativeX)
         
      elseif not Window.Anchor.Left and Window.Anchor.Right then
         Window.SetLeft(Window.Left+RelativeX)
         Window.SetRight(Window.Right+RelativeX)                
      end
      if Window.Anchor.Top and Window.Anchor.Bottom then            
         Window.SetBottom(Window.Bottom+RelativeY)
      elseif not Window.Anchor.Top and Window.Anchor.Bottom then
         Window.SetTop(Window.Top+RelativeY)
         Window.SetBottom(Window.Bottom+RelativeY)                
      end           
   end

   UIWindowsHostWidth = AWidth
   UIWindowsHostHeight = AHeight
   --Redraw()
   for _,Window in pairs(UIWindows) do
      Window.Render()
   end   
   Repaint()
end

--------------------------------------------------------------------------------
function UIWindowsClear()
      
   if UI_DebugGUI then    
      UILog("UIWindowsClear", "Clearing Windows [Not Implemented]", 1)
   end   
end

--------------------------------------------------------------------------------
function UIWindowDestroy(AWindowIndex)

   if UI_DebugGUI then    
      UILog("UIWindowDestroy", "Destroying Windows [Not Implemented]", 1)
   end   
end


function UIWindowMouseOver(flags, hotspot_id)
   
   local AWindow = UIWindows[hotspot_id]
   
   if AWindow then
   
      local MouseX = (WindowInfo(AWindow.MushWindow, 14))-- - AWidget.Left  -- where mouse is relative to output window (X)
      local MouseY = (WindowInfo(AWindow.MushWindow, 15))-- - AWidget.Top -- where mouse is relative to output window (Y)
   
      AWindow.IsHovering = true
   
      AWindow.MouseMove(MouseX, MouseY)
   
      AWindow.Render()
      Redraw()
   end
   
   return 0 -- needed for some languages   
end -- mouseover

function UIWindowCancelMouseOver(flags, hotspot_id)
   
   local AWindow = UIWindows[hotspot_id]
   
   if AWindow then
   
      AWindow.IsHovering = false
         
      AWindow.Render()
      Redraw()

   end              
   return 0 -- needed for some languages   
end -- mouseover

function UIWindowMouseDown(flags, hotspot_id)
   
   local AWindow = UIWindows[hotspot_id]
   
   if AWindow then
       
      local MouseX = (WindowInfo(AWindow.MushWindow, 14))-- - AWidget.Left  -- where mouse is relative to output window (X)
      local MouseY = (WindowInfo(AWindow.MushWindow, 15))-- - AWidget.Top -- where mouse is relative to output window (Y)
       
      AWindow.IsHovering = true
         
      AWindow.MouseButton(MouseX,MouseY,1,1)
         
      AWindow.Render()
      Redraw()
            
   end
   
   return 0 -- needed for some languages   
end -- mouseover


function UIWindowCancelMouseDown(flags, hotspot_id)
   local AWindow = UIWindows[hotspot_id]
      

   return 0 -- needed for some languages   
end -- mouseover


function UIWindowMouseUp(flags, hotspot_id)
   local AWindow = UIWindows[hotspot_id]
      

   return 0 -- needed for some languages   
end -- mouseover

