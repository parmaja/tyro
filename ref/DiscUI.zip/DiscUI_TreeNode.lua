--------------------------------------------------------------------------------
--//DiscUI TreeNode
--------------------------------------------------------------------------------

local UITreeNodesCounter = 0
local UITreeNodes = {}

function UITreeNodeCreate(ANodeParent)
   --create self instance
   local self = {}
   self.id = UITreeNodesCounter
   UITreeNodesCounter = UITreeNodesCounter + 1
   
   -----------------------------------------------------------------------------
   --Private                                                             Private
   -----------------------------------------------------------------------------
   
   local FHasChildren = false
   local FExpanded = false
   local FAllowSelect = true   
   local FPositionX = 0
   local FPositionY = 0
   local FHeight = 1
      
   
   -----------------------------------------------------------------------------
   --Public                                                               Public
   -----------------------------------------------------------------------------   
   self.Nodes = {}
   self.Parent = nil
   self.SisterNext = nil
   self.SisterPrev = nil
   self.Visible = true
   self.Caption = ""
   self.CaptionWidth = 0
      
   
   -----------------------------------------------------------------------------
   function self.NodeCreate()
      local Result = UITreeNodeCreate(self)
      table.insert(self.Nodes,Result)
      if not FHasChildren then FHasChildren = true end
      if #self.Nodes > 1 then
         Result.SisterPrev = self.Nodes[#self.Nodes-2]
         Result.SisterPrev.SisterNext = self.Nodes[#self.Nodes-1]
      end
      return Result        
   end
   
   -----------------------------------------------------------------------------
   function self.NodeDestroy(ATreeNode)      
      if ATreeNode then
         if ATreeNode.SisterPrev ~= nil then ATreeNode.SisterPrev.SisterNext = ATreeNode.SisterNext end      
         if ATreeNode.SisterNext ~= nil then ATreeNode.SisterNext.SisterPrev = ATreeNode.SisterPrev end
      end      
      if #self.Nodes <= 0 then FHasChildren = false end           
   end        
   
   -----------------------------------------------------------------------------
   function self.NodeDestroyAll()
      self.Nodes = {}      
   end
   
   -----------------------------------------------------------------------------
   function self.GetLevel()
   
      local Result = 0
      local ATreeNode = self.Parent
      while ATreeNode ~= nil do
         Result = Result + 1
         ATreeNode = ATreeNode.Parent
      end
      return Result
   end
   
   -----------------------------------------------------------------------------
   function self.GetLastSister()
      local Result = nil      
      if self.Parent ~= nil then
         Result = self.Parent.GetLastChild()
      else
         Result = self
      end           
      while Result.SisterNext ~= nil do
         Result = Result.SisterNext
      end
      return Result  
   end
   
   -----------------------------------------------------------------------------
   function self.GetFirstChild()
      local Result = nil
      if #self.Nodes > 0 then
         Result = self.Nodes[1]      
      end     
      return Result
   end
   
   -----------------------------------------------------------------------------
   function self.GetLastChild()
      local Result = nil
      if #self.Nodes > 0 then
         Result = self.Nodes[#self.Nodes]      
      end     
      return Result
   end
   
   -----------------------------------------------------------------------------
   function self.GetNextChild(ATreeNode)
      local Result = nil
      if ATreeNode ~= nil then
         Result = ATreeNode.SisterNext
      end      
      return Result
   end
   
   -----------------------------------------------------------------------------
   function self.GetPrevChild(ATreeNode)
      local Result = nil
      if ATreeNode ~= nil then
         Result = ATreeNode.SisterPrev
      end      
      return Result
   end
   
   -----------------------------------------------------------------------------
   function self.GetLastSubChild()
      local ANode = nil
      local Result = GetLastChild()
      if Result ~= nil then
         ANode = Result.GetLastSubChild()         
         if ANode then Result = ANode end
      end   
      return Result
   end
   
   -----------------------------------------------------------------------------
   function self.GetNextExpanded()
      local Result = nil                  
      if FExpanded and GetFirstChild() then
         Result = GetFirstChild()
      else
         Result = self               
         while Result and (Result.SisterNext==nil) do
            Result = Result.Parent
         end         
         if Result then Result = Result.SisterNext end                  
      end
      return Result
   end
   
   -----------------------------------------------------------------------------
   function self.GetNextVisible()
      local Result = nil                  
      if FExpanded and GetFirstChild() then
         Result = GetFirstChild()
      else
         Result = self               
         while Result and (Result.SisterNext==nil) do
            Result = Result.Parent
         end         
         if Result then Result = Result.SisterNext end                  
      end
   
      if (Result) and (not Result.Visible) then
         Result = nil
      end
   end
   
   -----------------------------------------------------------------------------
   function self.Bottom()
      return FPositionY + FHeight     
   end
   
   -----------------------------------------------------------------------------
   function self.BottomExpanded()
      if GetNextSibling<>nil then
    Result:=GetNextSibling.PositionY
  else if GetLastChild<>nil then
    Result:=GetLastChild.BottomExpanded
  else
    Result:=Bottom;
   end
   
   function self.Expand(AExpand, ARecurse)
   var
  AItem: TJUITreeItem;
begin

  FExpanded := ExpandIt;
  
  if Recurse then
  begin
    //ExpandItem(ExpandIt, False);
    AItem := GetFirstChild;
    while AItem<>nil do begin
      AItem.ExpandItem(ExpandIt, true);
      AItem := AItem.FNextBrother;
    end;
  end;
   
   end
   
   
   -----------------------------------------------------------------------------
     
   
   self.Nodes = {}
   self.Parent = ANodeParent
   self.SisterNext = nil
   self.SisterPrev = nil
   FExpanded = false
   self.Visible = true
   FPositionX = 0
   FPositionY = 0
   FHeight = 1
   
   table.insert(UITreeNodes,self)   
   return self      
end 