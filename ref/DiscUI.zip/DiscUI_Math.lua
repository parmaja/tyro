--------------------------------------------------------------------------------
--//DiscUI Math Variables
--------------------------------------------------------------------------------

--local references for optimization
local math_floor = math.floor
local math_ceil = math.ceil
local math_fmod = math.fmod
local math_sqrt = math.sqrt

--mathmatical constants
DegToRad = 0.017453292519943295769236907684883
RadToDeg = 57.295779513082320876798154814114
PI = 3.141592653589793238462643383279502
PI2 = PI * 2
PIDiv2 = PI / 2 

--------------------------------------------------------------------------------
--//DiscUI Math Functions
--------------------------------------------------------------------------------

function round(x)
  return x>=0 and math_floor(x+0.5) or math_ceil(x-0.5)
end

function Vec2Add(AX,AY, BX,BY)
   return AX+BX, AY+BY
end

function Vec2Sub(AX,AY, BX,BY)
   return (AX-BX), (AY-BY)
end

function Vec2Mul(AX,AY, AF)
   return (AX*AF), (AY*AF)
end

function Vec2Div(AX,AY, AF)
   return AX/AF, AY/AF
end

function Vec2Lerp(AX,AY, BX,BY, AF)
  return AX+((BX-AX)*AF), AY+((BY-AY)*AF)  
end

function Vec2Dot(AX,AY, BX,BY)
   return (AX * BX) + (AY * BY);
end

function Vec2LengthSquared(AX,AY)
   return (AX * AX) + (AY * AY);
end

function Vec2Length(AX,AY)
   return math_sqrt((AX * AX) + (AY * AY))
end 

function Vec2Normalize(AX, AY)
   local L = math_sqrt((AX * AX) + (AY * AY))      
   if L > 0 then
      return AX/L, AY/L   
   else 
      return AX, AY
   end   
end
