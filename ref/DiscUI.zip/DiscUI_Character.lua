--------------------------------------------------------------------------------
--//DiscUI Character
--------------------------------------------------------------------------------
local UICharacterCounter = 0       
local UIHeartBeat = 2
UICharacters = {}
UICharacter = {}
   
function UICharacterCreate()
   local self = {}
   self.id = UICharacterCounter
   UICharacterCounter = UICharacterCounter + 1
   
   -----------------------------------------------------------------------------
   --Private                                                             Private
   -----------------------------------------------------------------------------
   


   -----------------------------------------------------------------------------
   --Public                                                               Public
   -----------------------------------------------------------------------------

   
   ---------------------
   --Character specifics
   ---------------------            
   self.Name = ""
   self.Guild = ""
   self.GuildSpecific = ""
   self.GuildLevel = 0
   self.ExperienceStart = 0
   self.ExperienceStartFlag = true
   self.ExperienceStartTick = 0
   self.ExperienceCurrentTotal = 0
   self.Experience = 1
   self.ExperienceRate = 1
   self.ExperienceLast = 1
   self.ExperienceLastTick = 0
   
      
   self.HitPoints = 0
   self.HitPointsLast = 0   
   self.HitPointsMax = 0
   self.HitPointsRate = 4 / UIHeartBeat --Heartbeat roughly every two seconds   
   self.HitPointsLast = 0 --Used to estimate rate
   self.HitPointsLastTick = 0 --Used to estimate rate   
   
   self.GuildPoints = 0   
   self.GuildPointsMax = 0
   self.GuildPointsRate = 3 / UIHeartBeat   
   self.GuildPointsLast = 0
   self.GuildPointsLastTick = 0
   
   self.SocialPoints = 0
   self.SocialPointsMax = 0
   self.SocialPointsRate = 0.3 / UIHeartBeat   
   self.SocialPointsLast = 0
   self.SocialPointsLastTick = 0
   
   self.Overprotective = 0 --in seconds
   self.OverprotectiveMax = 3600 --One hour for now
   self.OverprotectiveRate = -1 / UIHeartBeat --one second per second.........
   self.OverprotectiveLast = 0
   self.OverprotectiveLastTick = 0
   
   self.Burden = 0
   self.Alignment = ""
   
   self.Stats = {}
   self.Skills = {}
   self.TalkerChannels = {} --Channels available to this char (mxp talkerchannels)
        
   ----------------
   --login / global
   ----------------
   self.Guilds = {} --Possible guilds (mxp guilds on connect)   
   self.GroupCommands = {} --Available group commands
   self.MUDChannels = {} -- MUD Channels (like but not talker, mxp on connect = newbie|newbiehelpers|groups)
    
   
   self.LastEstimateTick = UIMushGetTime()
   self.LastSetTick =  UIMushGetTime()
   self.CurrentTick = UIMushGetTime()
   self.TickSeconds = 0
    
   ----------------
   --Callbacks
   ----------------
   self.OnGuildLevelSample = nil
   self.OnGuildLevelMaxSet = nil
   
   self.OnExperienceSample = nil
   self.OnExperienceRateSample = nil
   
   self.OnGuildPointsSample = nil
   self.OnGuildPointsMaxSet = nil
   
   self.OnSocialPointsSample = nil
   self.OnSocialPointsMaxSet = nil
   
   self.OnBurdenSample = nil
   
   
   
   function self.UpdateEstimates()
      --HP regen per round = rounddown(sqrt(200/9.8 * (4 * ln(con) + ln (str)) - 50) - 10)
      --we should do an on the fly estimate of hp and gp rates       
      self.CurrentTick = UIMushGetTime()      
      self.TickSeconds = (self.CurrentTick - self.LastEstimateTick)
                
      self.HitPoints = math.min(self.HitPointsMax, self.HitPoints + (self.HitPointsRate * self.TickSeconds))
      self.GuildPoints = math.min(self.GuildPointsMax, self.GuildPoints + (self.GuildPointsRate * self.TickSeconds))            
      self.Overprotective = math.min(self.OverprotectiveMax, self.Overprotective + (self.OverprotectiveRate * self.TickSeconds))
      
      --self.SocialPoints = math.min(self.SocialPointsMax, self.SocialPoints + (self.SocialPointsRate * self.TickSeconds))
      
      
      self.ExperienceCurrentTotal = self.Experience-self.ExperienceStart      
      self.ExperienceRate = (self.ExperienceCurrentTotal / (self.CurrentTick-self.ExperienceStartTick))*60*60
                       
      
      if self.OnGuildPointsSample then
         self.OnGuildPointsSample(self.GuildPoints)      
      end
      
      if self.OnExperienceRateSample then
         self.OnExperienceRateSample(self.ExperienceRate)      
      end      
                                    
                            
      self.LastEstimateTick = self.CurrentTick
      
         
      if self.HitPointsMax > 0 then 
         UIWindowBars.BarHP.SetValue(self.HitPoints / self.HitPointsMax)
         UIWindowBars.BarHP.SetCaption("[HP : " .. round(self.HitPoints) .. " / " .. self.HitPointsMax .. "]")      
      end
      if self.GuildPointsMax > 0 then
         UIWindowBars.BarGP.SetValue(self.GuildPoints / self.GuildPointsMax)
         UIWindowBars.BarGP.SetCaption("[GP : " .. round(self.GuildPoints) .. " / " .. self.GuildPointsMax .. "]")            
      end
      if self.OverprotectiveMax > 0 then
         UIWindowBars.BarSH.SetValue(self.Overprotective / self.OverprotectiveMax)
         
         local Hours = math.floor(self.Overprotective / (60*60)) 
         local Minutes = math.floor( (self.Overprotective-(Hours*60*60)) / 60)                  
         local Seconds = math.floor(self.Overprotective - (Hours*60*60) - (Minutes*60))
         
         if string.len(Hours) == 1 then
            Hours = "0" .. Hours
         end
         
         if string.len(Minutes) == 1 then
            Minutes = "0" .. Minutes
         end
         
         if string.len(Seconds) == 1 then
            Seconds = "0" .. Seconds
         end
         
         UIWindowBars.BarSH.SetCaption("[SH : " .. Hours .. ":" .. Minutes .. ":" .. Seconds .. "]")
                              
      end   
      
      Repaint()
   end        
   
   -----------------------------------------------------------------------------
   function self.SetValueFromMUD(AName, AValue)
      
      local AHandled = false

    
      if (AName == "hp") then
         self.HitPoints = tonumber(AValue)         
         if (self.HitPointsLast > 0) and (self.HitPointsLast < self.HitPoints) then                     
            --UICharacter.HitPointsRate = (UICharacter.HitPoints-UICharacter.HitPointsLast) / ((UIMushGetTime()-UICharacter.HitPointsLastTick))                                  
         end                           
         self.HitPointsLast = self.HitPoints
         self.HitPointsLastTick = UIMushGetTime()
         AHandled = true
                                                  
      elseif (AName == "maxhp") then
         self.HitPointsMax = tonumber(AValue)     
         AHandled = true
                                                
      elseif (AName == "gp") then
         self.GuildPoints = tonumber(AValue)
         if (self.GuildPointsLast > 0) and (self.GuildPointsLast < self.GuildPoints) then
            --UICharacter.GuildPointsRate = (UICharacter.GuildPoints-UICharacter.GuildPointsLast) / (UIMushGetTime()-UICharacter.GuildPointsLastTick)                         
         end
         self.GuildPointsLast = self.GuildPoints
         self.GuildPointsLastTick = UIMushGetTime()  
         AHandled = true
                                  
      elseif (AName == "maxgp") then
         self.GuildPointsMax = tonumber(AValue)

         if self.OnGuildPointsMaxSet then
            self.OnGuildPointsMaxSet(self.GuildPointsMax)        
         end
         
                           
         AHandled = true
      
      elseif (AName == "Overprotective") then
         self.Overprotective = tonumber(AValue)         
         self.Overprotective = (60*60*24) * (self.Overprotective/100)
                            
         if (self.OverprotectiveLast > 0) and (self.OverprotectiveLast < self.Overprotective) then                     
            --UICharacter.OverprotectiveRate = (UICharacter.Overprotective-UICharacter.OverprotectiveLast) / ((UIMushGetTime()-UICharacter.OverprotectiveLastTick))                                  
         end                           
         self.OverprotectiveLast = self.Overprotective
         self.OverprotectiveLastTick = UIMushGetTime()                     
         self.OverprotectiveLast = tonumber(AValue)
         AHandled = true
                                                                         
      elseif (AName == "sp") then
         self.SocialPoints = tonumber(AValue)
         if (self.SocialPointsLast > 0)  and (self.SocialPointsLast < self.SocialPoints) then
            --UICharacter.SocialPointsRate = (UICharacter.SocialPoints-UICharacter.SocialPointsLast) / (UIMushGetTime()-UICharacter.SocialPointsLastTick)             
         end
         self.SocialPointsLast = self.SocialPoints
         self.SocialPointsLastTick = UIMushGetTime()
         AHandled = true
           
      elseif (AName == "maxsp") then      
         self.SocialPointsMax = tonumber(AValue)
         AHandled = true
                                                                  
      elseif (AName == "burden") then      
         self.Burden = tonumber(AValue)
         AHandled = true
                        
      elseif (AName == "alignment") then
         self.Alignment = AValue
         AHandled = true   
      elseif (AName == "xp") then 
  
        
         self.ExperienceLast = self.Experience
         self.ExperienceLastTick = UIMushGetTime()
         self.Experience = tonumber(AValue)  
         
         if (self.ExperienceStartFlag) and (self.Experience > 0) then
            self.ExperienceStart = self.Experience
            self.ExperienceStartTick = UIMushGetTime() 
            self.ExperienceStartFlag = false
         end
                
         AHandled = true
      
      elseif (AName == "combat") then
         --not sure, some kind of status - values of 'burden' and don't know any others.         
         AHandled = true
         
      elseif (AName == "club") then
         --recieved (also) on club talk (possibly other club related functions)
         AHandled = true
                 
      elseif (AName == "guilds") then
         self.Guilds = split(AValue,"|")
         AHandled = true

      elseif (AName == "groupcmds") then        
         self.GroupCommands = split(AValue,"|")
         AHandled = true
                                                        
      elseif (AName == "channels") then   
         self.MUDChannels = split(AValue,"|")
         AHandled = true

      elseif (AName == "talkerchannels") then
         self.TalkerChannels = split(AValue,"|")
         AHandled = true        
         
      elseif (AName == "lastskillchanged") then
         --TODO create/increment skill in tree   
         --lastskillchanged=faith.points
          --[lastskillchanged=fighting.defence.dodging]
         AHandled = true     
      elseif (AName == "ob") or (AName == "clubnames") or (AName =="informtype") or (AName == "informtypes") then                  
         AHandled = true --Ignore these for now                 
      end
              
      if UI_DebugCharacter then
         if AHandled then            
            --UILog("UICharacter.SetValueFromMUD" , "Processed Mud Value : [" .. AName .. "=" .. AValue .. "]",0)
         else
            UILog("UICharacter.SetValueFromMUD" , "Unhandled Mud Value : [" .. AName .. "=" .. AValue .. "]",1)
         end
      end            
         
 
      --TODO this shouldn't be happening here                  
      if self.HitPointsMax > 0 then 
         UIWindowBars.BarHP.SetValue(self.HitPoints / self.HitPointsMax)
         UIWindowBars.BarHP.SetCaption("[HP : " .. round(self.HitPoints) .. " / " .. self.HitPointsMax .. "]")      
      end
      if self.GuildPointsMax > 0 then
         UIWindowBars.BarGP.SetValue(self.GuildPoints / self.GuildPointsMax)
         UIWindowBars.BarGP.SetCaption("[GP : " .. round(self.GuildPoints) .. " / " .. self.GuildPointsMax .. "]")            
      end
          
      if self.OverprotectiveMax > 0 then
         UIWindowBars.BarSH.SetValue(self.Overprotective / self.OverprotectiveMax)
         
         local Hours = math.floor(self.Overprotective / (60*60)) 
         local Minutes = math.floor( (self.Overprotective-(Hours*60*60)) / 60)                  
         local Seconds = math.floor(self.Overprotective - (Hours*60*60) - (Minutes*60))
         
         if string.len(Hours) == 1 then
            Hours = "0" .. Hours
         end
         
         if string.len(Minutes) == 1 then
            Minutes = "0" .. Minutes
         end
         
         if string.len(Seconds) == 1 then
            Seconds = "0" .. Seconds
         end
                                  
         UIWindowBars.BarSH.SetCaption("[SH : " .. Hours .. ":" .. Minutes .. ":" .. Seconds .. "]")
         
      end
      if self.SocialPointsMax > 0 then
         UIWindowBars.BarSP.SetValue(self.SocialPoints / self.SocialPointsMax)
         UIWindowBars.BarSP.SetCaption("[SP : " .. round(self.SocialPoints) .. " / " .. self.SocialPointsMax .. "]")            
      end
            
      if self.Burden > 0 then
         UIWindowBars.BarBR.SetValue(self.Burden / 100)
         UIWindowBars.BarBR.SetCaption("[BR : " .. round(self.Burden) .. "%]")      
      end               
      --Redraw()
      Repaint()
        
   end
   
   table.insert(UICharacters,self)
                       
   return self     
end