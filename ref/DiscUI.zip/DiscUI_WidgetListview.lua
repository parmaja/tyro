--------------------------------------------------------------------------------
--//DiscUI Widget Listview 
--------------------------------------------------------------------------------
--local references for optimization
local math_min = math.min
local math_floor = math.floor

function UIWidgetListviewCreate(AWindow, AWidgetLeft, AWidgetTop, AWidgetRight, AWidgetBottom)
 
    local self = UIWidgetCreate(AWindow, AWidgetLeft, AWidgetTop, AWidgetRight, AWidgetBottom)
          
   --overrides
   self.WidgetType = UIWidget_Listview
   self.WidgetTypeName = "WidgetListview"
   self.SetCaption("Listview")      
   self.ColourBackground = 0x101010
   self.Font = self.Window.FontSmall
                        
   self.ScrollX = 0
   self.ScrollY = 0
   
   self.LineBorder = 2
   self.LineHeight = 15   
   self.Lines = {}
   self.LineTop = 1
   self.LineBottom = 1
    
   self.SelectedItem = nil 
   
   function self.LineAdd(ALine, AData)
      self.Lines[#self.Lines+1] = {}      
      self.Lines[#self.Lines].Text = ALine
      self.Lines[#self.Lines].Data = AData
        
      if (#self.Lines * self.LineHeight) > self.Height then
         self.ScrollX = self.ScrollX + self.LineHeight
      end      
   end
      
   function self.LinesClear()
      self.Lines = {}
   end
   
   self.OnItemSelect = nil
   
   self.MouseButtonParent = self.MouseButton 
   function self.MouseButton(AMouseX, AMouseY, Button, State)
   
      self.MouseButtonParent(AMouseX, AMouseY, Button, State)
            
      if #self.Lines > 0 then            
         local AItemIndex = round((AMouseY / self.Height) * self.LineHeight)-1      
         self.SelectedItem = self.Lines[AItemIndex]
         if self.OnItemSelect then
            self.OnItemSelect(self.SelectedItem)      
         end
      end         
              
   end    
   
   
   self.RenderParent = self.Render  ----override   
   function self.Render()                 
      self.RenderParent()  

      --Render Background      
      self.Window.RectColour(self.ColourBackground)                 
      self.Window.Rect(self.Left,self.Top,self.Right,self.Bottom)
      
      self.LineTop = 1
      self.LineBottom = math_min(math_floor(self.Height / self.LineHeight), #self.Lines)
                                               
      --Render Lines
      self.Window.TextColour(self.ColourFont)
      if #self.Lines > 0 then
         for I = self.LineTop,self.LineBottom do
         
            if (self.Lines[I] == self.SelectedItem) then
               self.Window.RectColour(0x555555)
               self.Window.Rect(self.Left+self.LineBorder, self.Top+self.LineBorder+((I-1)*self.LineHeight), self.Left+self.Width-self.LineBorder, self.Top+self.LineBorder+((I-1)*self.LineHeight)+self.LineHeight)
            end         
         --for I,Line in ipairs(self.Lines) do      
               self.Window.Text(self.Lines[I].Text, self.Font, self.Left+self.LineBorder, self.Top+self.LineBorder+((I-1)*self.LineHeight), self.Left+self.Width-self.LineBorder, self.Top+self.LineBorder+((I-1)*self.LineHeight)+self.LineHeight)
         end
      end      
      --Render outline
      self.Window.RectColour(0x939393)
      self.Window.RectOutline(self.Left,self.Top,self.Right,self.Bottom)                      
   end
   
   
   --Setup Listview
   
   
               
   return self      
end