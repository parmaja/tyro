--------------------------------------------------------------------------------
--//DiscUI Widget Graph 
--------------------------------------------------------------------------------

function UIWidgetGraphCreate(AWindow, AWidgetLeft, AWidgetTop, AWidgetRight, AWidgetBottom)
   
    local self = UIWidgetCreate(AWindow, AWidgetLeft, AWidgetTop, AWidgetRight, AWidgetBottom)
          
   --Overrides
   
   self.WidgetType = UIWidget_Graph
   self.WidgetTypeName = "WidgetGraph"
   self.SetCaption("Graph")      
   self.ColourFont = 0xFFFFFF
   
   --Additions
   
   local FFontGraphName = "Consolas"
   local FFontGraphHeight = 9  
   self.Font = "FontGraph" .. self.id    
   
   self.BorderSize = 3   
   self.ColourGraphBackground = 0x222222
   self.ColourFontShadow = 0x252525
   
   self.AxisYWidth = 30
   --Viewport   
   self.ViewportLeft = self.Left+self.BorderSize+self.AxisYWidth
   self.ViewportTop = self.Top+self.BorderSize
   self.ViewportRight = self.Right-self.BorderSize
   self.ViewportBottom = self.Bottom-self.BorderSize
   self.ViewportWidth = self.ViewportRight-self.ViewportLeft
   self.ViewportHeight = self.ViewportBottom-self.ViewportTop
   
   
   --Sample Sets
   self.SampleSetCount = 0
   self.SampleSets = {}       
   
   self.DivisionCount = 10
   self.DivisionWidth = self.ViewportHeight / (self.DivisionCount)
   self.DivisionScaleMax = 500000
   
   function self.SampleSetAdd(ASampleCount, ASampleMin, ASampleMax, AColour)
      
      local ASampleSet = {}  
          
      ASampleSet.SampleCount = ASampleCount      
      ASampleSet.Samples = {}
      for I = 1, ASampleCount do
         ASampleSet.Samples[I] = 0
      end                  
      ASampleSet.SampleMin = ASampleMin
      ASampleSet.SampleMax = ASampleMax
      ASampleSet.Colour = AColour 
      
      function ASampleSet.SampleAdd(ASample)                 
         if ASample > ASampleSet.SampleMax then ASample = ASampleSet.SampleMax end
         if ASample < ASampleSet.SampleMin then ASample = ASampleSet.SampleMin end         
         table.remove(ASampleSet.Samples, 1)
         table.insert(ASampleSet.Samples, ASample)
         
         self.Render()
      end
      
      function ASampleSet.SetSampleMin(ASampleMin)
         ASampleSet.SampleMin = ASampleMin         
      end
      
      function ASampleSet.SetSampleMax(ASampleMax)
         ASampleSet.SampleMax = ASampleMax
      end
                                 
      table.insert(self.SampleSets, ASampleSet)
      self.SampleSetCount = self.SampleSetCount + 1
      
      return ASampleSet
   end
   
   function self.SampleSetSampleAdd(ASampleSet, ASample)      
      if ASample > ASampleSet.SampleMax then ASample = ASampleSet.SampleMax end
      if ASample < ASampleSet.SampleMin then ASample = ASampleSet.SampleMin end         
      table.remove(ASampleSet.Samples, 1)
      table.insert(ASampleSet.Samples,ASample)
      
      self.Render()  
   end
                            
   self.RenderParent = self.Render ----override   
   --
   function self.Render()    
     
      self.RenderParent()
      
      self.ViewportLeft = self.Left+self.BorderSize+self.AxisYWidth
      self.ViewportTop = self.Top+self.BorderSize
      self.ViewportRight = self.Right-self.BorderSize-self.AxisYWidth
      self.ViewportBottom = self.Bottom-self.BorderSize
      self.ViewportWidth = self.ViewportRight-self.ViewportLeft
      self.ViewportHeight = self.ViewportBottom-self.ViewportTop 
   
      
      self.Window.RectColour(self.ColourGraphBackground)
      self.Window.Rect(self.ViewportLeft,self.ViewportTop,self.ViewportRight,self.ViewportBottom)
      
      self.RenderAxis()  
                                          
            
      local APosX = 0
      local APosY = 30
      local BPosX = 0
      local BPosY = 30
      
      local CPosX = 0
      local CPosY = 30
      local DPosX = 0
      local DPosY = 30
      local ASampleSet = nil 
      
      for K = 1, self.SampleSetCount do
      
         ASampleSet = self.SampleSets[K]
                  
         --[[
         self.Window.LineColour(0x000000)
         self.Window.LineWidth(4)         
         for I = 1, ASampleSet.SampleCount-1 do      
            APosX = self.ViewportLeft+(((I)/ASampleSet.SampleCount)*self.ViewportWidth)
            APosY = self.ViewportBottom-(ASampleSet.Samples[I]/ASampleSet.SampleMax)*self.ViewportHeight
            BPosX = self.ViewportLeft+(((I+1)/ASampleSet.SampleCount)*self.ViewportWidth)
            BPosY = self.ViewportBottom-(ASampleSet.Samples[I+1]/ASampleSet.SampleMax)*self.ViewportHeight
            self.Window.Line(APosX,APosY,BPosX,BPosY)
         end
         --]]
         
         self.Window.LineColour(ASampleSet.Colour)
         self.Window.LineWidth(0)
         
         for I = 1, ASampleSet.SampleCount-1 do      
            APosX = self.ViewportLeft+(((I)/ASampleSet.SampleCount)*self.ViewportWidth)
            APosY = self.ViewportBottom-(ASampleSet.Samples[I]/ASampleSet.SampleMax)*self.ViewportHeight
            BPosX = self.ViewportLeft+(((I+1)/ASampleSet.SampleCount)*self.ViewportWidth)
            BPosY = self.ViewportBottom-(ASampleSet.Samples[I+1]/ASampleSet.SampleMax)*self.ViewportHeight
            self.Window.Line(APosX,APosY,BPosX,BPosY)
         end      
      end
      
     if self.OnRender ~= nil then
         self.OnRender(0.1)
     end
                             
   end
   
   
   function self.RenderAxis()
   
      local APosX = self.ViewportLeft
      local APosY = self.ViewportTop
      local BPosX = self.ViewportLeft
      local BPosY = self.ViewportBottom
      
      local CPosX = self.ViewportRight
      local CPosY = self.ViewportTop
      local DPosX = self.ViewportRight
      local DPosY = self.ViewportBottom
      
      
      local AText = ""
      local ATextWidth = 0
      local ATextHeight = 0
      local ATextHeightDiv2 = 0      
      self.Window.LineWidth(0)
      self.Window.LineColour(0xFFFFFF)
      self.Window.Line(APosX,APosY,BPosX,BPosY)
      
      APosX = self.ViewportLeft-5
      BPosX = self.ViewportLeft
      
      CPosX = self.ViewportRight+5
      DPosX = self.ViewportRight
      
      for I = 1,self.DivisionCount+1 do        
      
         --left hand side 
         APosY = self.ViewportBottom-((I-1)*self.DivisionWidth)                           
         BPosY = APosY
         self.Window.Line(APosX,APosY,BPosX,BPosY)
         
         AText = round((((I-1) /self.DivisionCount)*self.DivisionScaleMax)/1000) .. "k"
         ATextWidth = self.Window.TextWidth(AText,self.Window.FontSmall)
         ATextHeight = self.Window.TextHeight(AText,self.Window.FontSmall)
         ATextHeightDiv2 = ATextHeight/2 
         
         self.Window.TextColour(0xCCFFFF)
         if I == self.DivisionCount+1 then
            self.Window.Text(AText, self.Window.FontSmall, APosX-ATextWidth, APosY-3, BPosX, APosY+ATextHeight-3)                  
         elseif I == 1 then
            self.Window.Text(AText, self.Window.FontSmall, APosX-ATextWidth, APosY-ATextHeight+3, BPosX, APosY+3)
         else
            self.Window.Text(AText, self.Window.FontSmall, APosX-ATextWidth, APosY-ATextHeightDiv2, BPosX, APosY+ATextHeightDiv2)
         end
         
         --right hand side
         CPosY = self.ViewportBottom-((I-1)*self.DivisionWidth)                           
         DPosY = CPosY
         self.Window.Line(CPosX,CPosY,DPosX,DPosY)
         
         AText = round((((I-1) /self.DivisionCount)*self.DivisionScaleMax)/1000) .. "k"
         ATextWidth = self.Window.TextWidth(AText,self.Window.FontSmall)
         ATextHeight = self.Window.TextHeight(AText,self.Window.FontSmall)
         ATextHeightDiv2 = ATextHeight/2          
         self.Window.TextColour(0xCCFFFF)
         if I == self.DivisionCount+1 then
            self.Window.Text(AText, self.Window.FontSmall, CPosX, CPosY-3, CPosX+ATextWidth, CPosY+ATextHeight-3)                  
         elseif I == 1 then
            self.Window.Text(AText, self.Window.FontSmall, CPosX, CPosY-ATextHeight+3, CPosX+ATextWidth, CPosY+3)
         else
            self.Window.Text(AText, self.Window.FontSmall, CPosX, CPosY-ATextHeightDiv2, CPosX+ATextWidth, CPosY+ATextHeightDiv2)
         end         
                        
      end
      
      self.Window.LineColour(0x777777)      
      APosX = self.ViewportLeft
      BPosX = self.ViewportRight
      local AToggle = false
      local AToggleColour = 0x555555
      for I = 2,self.DivisionCount+1 do         
         APosY = self.ViewportBottom-((I-1)*self.DivisionWidth)                           
         BPosY = APosY
         
         if AToggle then
            AToggleColour = 0x101010
            AToggle = false
         else
            AToggleColour = 0x080808
            AToggle = true
         end
         self.Window.RectColour(AToggleColour)
         self.Window.Rect(self.ViewportLeft,APosY,self.ViewportRight,APosY+self.DivisionWidth)      
      
         self.Window.Line(APosX,APosY,BPosX,BPosY,2)
     end
   
   end
   
   --Setup Graph
   UIFontCreate(self.Window.MushWindow, self.Font, FFontGraphName, FFontGraphHeight, true)

   return self      
end