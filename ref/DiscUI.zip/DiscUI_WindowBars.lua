--------------------------------------------------------------------------------
--//DiscUI Bars Window Variables
--------------------------------------------------------------------------------

UIWindowBarsBorderWidth = 5
UIWindowBars = {}

--------------------------------------------------------------------------------
--//DiscUI Bars Window Functions
--------------------------------------------------------------------------------

function UIWindowBarsCreate()

   --Create Window
   UIWindowBars = UIWindowCreate("Bars", 0, 0, UI_BarLeftWidth, 250, 4)
   UIWindowBars.SetTitleBarVisible(false)
   UIWindowBars.Anchor.Top = false
   UIWindowBars.Anchor.Bottom = true
        
   UIWindowBars.TitleBarText = "Bars"
   
   local BarBorder = 5   
   local BarHeight = 15            
      
   UIWindowBars.BarHP = UIWindowBars.WidgetCreate(UIWidget_Bar, BarBorder, UIWindowBars.TitleBarHeight+BarBorder, UIWindowBars.Width-BarBorder, UIWindowBars.TitleBarHeight+BarBorder+BarHeight)
   UIWindowBars.BarHP.SetCaption("HP : [ 0 / 0 ]")
   UIWindowBars.BarHP.ColourBar = 0x227722
    
   
   --UIWindowBars.BarGP = UIWindowBars.WidgetCreate(UIWidget_Bar, BarBorder, UIWindowBars.BarHP.Bottom+BarBorder, UIWindowBars.Width-BarBorder, UIWindowBars.BarHP.Bottom+BarBorder+BarHeight)
   --UIWindowBars.BarGP.SetCaption("GP : [ 0 / 0 ]")
   --UIWindowBars.BarGP.ColourBar = 0x777722
   
   --UIWindowBars.BarSH = UIWindowBars.WidgetCreate(UIWidget_Bar, BarBorder, UIWindowBars.BarGP.Bottom+BarBorder, UIWindowBars.Width-BarBorder, UIWindowBars.BarGP.Bottom+BarBorder+BarHeight)
   --UIWindowBars.BarSH.SetCaption("SH : [ 00:00:00 ]")
   --UIWindowBars.BarSH.ColourBar = 0x552288
   
   
   UIWindowBars.BarGP = UIWindowBars.WidgetCreate(UIWidget_Bar, BarBorder, UIWindowBars.BarHP.Bottom+BarBorder, (UIWindowBars.Width / 2)-BarBorder/2, UIWindowBars.BarHP.Bottom+BarBorder+BarHeight)  
   UIWindowBars.BarGP.SetCaption("GP : [ 0 / 0 ]")
   UIWindowBars.BarGP.ColourBar = 0x777722      
   
   UIWindowBars.BarSH = UIWindowBars.WidgetCreate(UIWidget_Bar,UIWindowBars.BarGP.Right+BarBorder, UIWindowBars.BarHP.Bottom+BarBorder, UIWindowBars.Width-BarBorder, UIWindowBars.BarHP.Bottom+BarBorder+BarHeight) 
   UIWindowBars.BarSH.SetCaption("SH : [ 00:00:00 ]")
   UIWindowBars.BarSH.ColourBar = 0x552288
         
      
   UIWindowBars.BarSP = UIWindowBars.WidgetCreate(UIWidget_Bar, BarBorder, UIWindowBars.BarSH.Bottom+BarBorder, (UIWindowBars.Width / 2)-BarBorder/2, UIWindowBars.BarSH.Bottom+BarBorder+BarHeight)  
   UIWindowBars.BarSP.SetCaption("SP : [ 0 / 0 ]")
   UIWindowBars.BarSP.ColourBar = 0x227777      
   
   UIWindowBars.BarBR = UIWindowBars.WidgetCreate(UIWidget_Bar,UIWindowBars.BarSP.Right+BarBorder, UIWindowBars.BarSH.Bottom+BarBorder, UIWindowBars.Width-BarBorder, UIWindowBars.BarSH.Bottom+BarBorder+BarHeight) 
   UIWindowBars.BarBR.SetCaption("[BR : 0%]")
   UIWindowBars.BarBR.ColourBar = 0x222277   
      
      
   UIWindowBars.SetHeight(UIWindowBars.BarBR.Bottom + BarBorder)   
   UIWindowBars.SetTop(UIMushClientHeight()-(UIWindowBars.BarBR.Bottom + BarBorder))                
   UIWindowBars.SetBottom(UIMushClientHeight())


   -- Assign Callbacks (or is it a copy of the function? who cares?)
   UIWindowBars.OnRender = UIWindowBarsRender
        
   UIWindowBars.Render() 
   UIWindowBars.Show()
end

function UIWindowBarsRender(ADelta)
                  
end
