--------------------------------------------------------------------------------
--//DiscUI Map Info Window Variables
--------------------------------------------------------------------------------

UIWindowTalkerBorderWidth = 5
UIWindowTalker = {}

local FBorderWidth = 5
--------------------------------------------------------------------------------
--//DiscUI Map Info Window Functions
--------------------------------------------------------------------------------

function UIWindowTalkerCreate()      
   UIWindowTalker = UIWindowCreate("Talker", UI_BarLeftWidth+300, 0, UIMushClientWidth(), UI_BarTopHeight, 4)
   
   UIWindowTalker.SetLeft(UI_BarLeftWidth+300)   
   UIWindowTalker.SetHeight(UI_BarTopHeight)
   UIWindowTalker.SetWidth(UIMushClientWidth()-(UI_BarLeftWidth+300))
             
   UIWindowTalker.Anchor.Right = true
   UIWindowTalker.TitleBarText = "Talker"   
   
   
   local ALeft = FBorderWidth
   local ATop = UIWindowTalker.TitleBarHeight+FBorderWidth
   local ARight = UIWindowTalker.Width-FBorderWidth
   local ABottom = UIWindowTalker.Height-FBorderWidth     
   UIWindowTalker.Memo = UIWindowTalker.WidgetCreate(UIWidget_Memo, ALeft, ATop,  ARight,  ABottom)
           
   UIWindowTalker.Memo.Anchor.Left = true
   UIWindowTalker.Memo.Anchor.Top = true
   UIWindowTalker.Memo.Anchor.Right = true
   UIWindowTalker.Memo.Anchor.Bottom = true
   
         
   --Add Properties   
   
   
   --UIWindowTalker.HotSpotMap = "HotSpotMap"
   --result = WindowAddHotspot(UIWindowTalker.MushWindow, UIWindowTalker.HotSpotMap, 
   --UIWindowTalker.ViewPort.Left,UIWindowTalker.ViewPort.Top,UIWindowTalker.ViewPort.Right,UIWindowTalker.ViewPort.Bottom,   
   --"", "", "", "", "", "", 3, 0)
      
   --result = WindowDragHandler(UIWindowTalker.MushWindow, UIWindowTalker.HotSpotMap, "UIWindowMapMouseDragMove", "UIWindowMapMouseDragEnd", 0)    
   --result = WindowScrollwheelHandler(UIWindowTalker.MushWindow, UIWindowTalker.HotSpotMap, "UIWindowMapMouseWheel")
   
   
   
   -- Assign Callbacks (or is it a copy of the function? who cares?)
   UIWindowTalker.OnRender = UIWindowTalkerRender         
   UIWindowTalker.Render()         
   UIWindowTalker.Show()    
end

function UIWindowTalkerRender(ADelta)

end

function UIWindowTalkerInput(ALine)
   
   
   
   local APos = 0
   local BPos = 0
   local AChannel = ""
   local APerson = ""
   
   APos = string.find(ALine,")")
   AChannel = string.sub(ALine,2,APos-1)
   
   BPos = string.find(ALine,"'s")
   APerson = string.sub(ALine,APos+2,BPos-1)      
      
   APos = string.find(ALine,"saying:")
   if APos then
      ALine = string.sub(ALine,APos+8)
      UIWindowTalker.Memo.LineAdd("["..AChannel..":"..APerson.."] '"..ALine.."'")
      
   end
           
   APos = string.find(ALine,"saying that she")
   if APos then
      ALine = string.sub(ALine,APos+16)
      UIWindowTalker.Memo.LineAdd("*"..AChannel..":"..APerson.."* '"..ALine.."'")
   end
   
   APos = string.find(ALine,"saying that he")
   BPos = string.find(ALine,"saying that it")
   if APos then
      ALine = string.sub(ALine,APos+15)
      UIWindowTalker.Memo.LineAdd("*"..AChannel..":"..APerson.."* '"..ALine.."'")
   elseif BPos then
      ALine = string.sub(ALine,BPos+15)
      UIWindowTalker.Memo.LineAdd("*"..AChannel..":"..APerson.."* '"..ALine.."'")
   end
   
   
   
      
   UIWindowTalker.Render()
   Repaint()
end
