--------------------------------------------------------------------------------
--//DiscUI Map Info Window Variables
--------------------------------------------------------------------------------

--library local references
local round = round

UIWindowStatsBorderWidth = 5
UIWindowStats = {}

local FBorderWidth = 5
--------------------------------------------------------------------------------
--//DiscUI Map Info Window Functions
--------------------------------------------------------------------------------

function UIWindowStatsCreate()      
   UIWindowStats = UIWindowCreate("Stats",  UI_BarLeftWidth+300, 0, UIMushClientWidth(), UI_BarTopHeight, 4)
   UIWindowStats.SetLeft(UI_BarLeftWidth+300)   
   UIWindowStats.SetHeight(UI_BarTopHeight)
   UIWindowStats.SetWidth(UIMushClientWidth()-(UI_BarLeftWidth+300))             
   UIWindowStats.Anchor.Right = true
   UIWindowStats.TitleBarText = "Stats"   
   
   
   local ALeft = FBorderWidth
   local ATop = UIWindowStats.TitleBarHeight+FBorderWidth
   local ARight = UIWindowStats.Width-FBorderWidth
   local ABottom = UIWindowStats.Height-FBorderWidth     
   UIWindowStats.Graph = UIWindowStats.WidgetCreate(UIWidget_Graph, ALeft, ATop,  ARight,  ABottom)         
   UIWindowStats.Graph.Anchor.Left = true
   UIWindowStats.Graph.Anchor.Top = true
   UIWindowStats.Graph.Anchor.Right = true
   UIWindowStats.Graph.Anchor.Bottom = true
            
   local ASampleSet = UIWindowStats.Graph.SampleSetAdd(512,0,500000, 0x77CC77)                   
   UICharacter.OnExperienceRateSample = ASampleSet.SampleAdd
   
   local ASampleSet = UIWindowStats.Graph.SampleSetAdd(512,0,1000, 0x777722)    
   UICharacter.OnGuildPointsSample = ASampleSet.SampleAdd
   UICharacter.OnGuildPointsMaxSet = ASampleSet.SetSampleMax
   
   --Add Properties        
   --UIWindowStats.HotSpotGraph = "HotSpotMap"
   --result = WindowAddHotspot(UIWindowStats.MushWindow, UIWindowStats.HotSpotMap, 
   --UIWindowStats.ViewPort.Left,UIWindowStats.ViewPort.Top,UIWindowStats.ViewPort.Right,UIWindowStats.ViewPort.Bottom,   
   --"", "", "", "", "", "", 3, 0)      
   --result = WindowDragHandler(UIWindowStats.MushWindow, UIWindowStats.HotSpotMap, "UIWindowMapMouseDragMove", "UIWindowMapMouseDragEnd", 0)    
   --result = WindowScrollwheelHandler(UIWindowStats.MushWindow, UIWindowStats.HotSpotMap, "UIWindowMapMouseWheel")
   
   
   
   -- Assign Callbacks (or is it a copy of the function? who cares?)
   UIWindowStats.Graph.OnRender = UIWindowStatsGraphRender         
   UIWindowStats.Render()         
   UIWindowStats.Show()
       
end

function UIWindowStatsGraphRender(ADelta)
   
   --self.ExperienceStart = 0
   --self.ExperienceStartFlag = true
   --self.ExperienceStartTick = 0
   --self.ExperienceCurrentTotal = 0
   --self.Experience = 1
   --self.ExperienceRate = 1
   --self.ExperienceLast = 1
   --self.ExperienceLastTick = 0
   local ATextHeight = UIWindowStats.TextHeight('0123',UIWindowStats.Font)
   local ALeft = UIWindowStats.Graph.ViewportLeft+FBorderWidth;
   local ATop = UIWindowStats.Graph.ViewportTop+(UIWindowStats.Graph.DivisionWidth/2)-(ATextHeight/2);         
   local ARight =  UIWindowStats.Graph.ViewportRight;
   local ABottom = ATop+ATextHeight;  
         
   UIWindowStats.Text("XP : " .. UIcommas(UICharacter.Experience), UIWindowStats.Font, ALeft, ATop, ARight, ABottom)
   
   ATop = ATop + UIWindowStats.Graph.DivisionWidth
   ABottom = ABottom + UIWindowStats.Graph.DivisionWidth
   
   UIWindowStats.Text("(XP) : " .. UIcommas(UICharacter.ExperienceCurrentTotal), UIWindowStats.Font, ALeft, ATop, ARight, ABottom)     
   
   ATop = ATop + UIWindowStats.Graph.DivisionWidth
   ABottom = ABottom + UIWindowStats.Graph.DivisionWidth
   
   UIWindowStats.Text("XP/h : " .. UIcommas(round(UICharacter.ExperienceRate)), UIWindowStats.Font, ALeft, ATop, ARight, ABottom)     
   
         
end
