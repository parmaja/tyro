--------------------------------------------------------------------------------
--//DiscUI Surface
--------------------------------------------------------------------------------
local UISurfaceCounter = 0
local UISurfaces = {} 

local FWindowDrawImage = WindowDrawImage
local FWindowBlendImage = WindowBlendImage    
         
function UISurfaceCreate(AWindow, AWidth, AHeight)
   --create self instance
   local self = {}
   self.id = UISurfaceCounter
   UISurfaceCounter = UISurfaceCounter + 1
   
   --local external vars for optimization
   local A_X = 0  
   local A_Y = 0
   local B_X = 0  
   local B_Y = 0
   
   local CosL = {}
   local SinL = {}   
   for I = 0,360 do
      CosL[I] = math.cos(I*DegToRad)
      SinL[I] = math.sin(I*DegToRad)
   end
                         
   -----------------------------------------------------------------------------
   --Private                                                             Private
   -----------------------------------------------------------------------------
   
   local FTranslationX = 0
   local FTranslationY = 0   
   local FRotation = 0
   local FRotationSin = math.sin(0)   
   local FRotationCos = math.cos(0)
   local FScale = 0
           
   local FSurfaceColour = 0x222222
   local FLineColour = 0xFFFFFF
   local FRectColour = 0x222222
   local FCircleColour = 0x666666
   local FTextColour = 0xFFFFFF
   local FLineWidth = 0
   
   
   local FFontName = "Consolas"
   local FFontHeight = 10
   local FFontSmallName = "Consolas"
   local FFontSmallHeight = 8
   
   -----------------------------------------------------------------------------
   --Public                                                               Public
   -----------------------------------------------------------------------------      
   self.MushWindow = "UISurface" .. self.id
   self.Image = "UISurfaceImage"..self.id
   self.Width = AWidth
   self.Height = AHeight
   self.Font = "SurfaceFont" .. self.id
   self.FontSmall = "SurfaceFontSmall" .. self.id 
   
   -----------------------------------------------------------------------------
   --//Rendering
   -----------------------------------------------------------------------------
   
   function self.SetIdentity()
      FTranslationX = 0
      FTranslationY = 0
      FScale = 0
      FRotation = 0
   end
      
   function self.Translate(ATranslationX, ATranslationY)
      FTranslationX = FTranslationX + ATranslationX
      FTranslationY = FTranslationY + ATranslationX      
   end
   
   function self.Rotate(ARotation)
      FRotation = ARotation
      FRotationSin = math.sin(ARotation)
      FRotationCos = math.cos(ARotation)      
      --if FRotation < 0 then FRotation = FRotation + 360 end
      --if FRotation > 360 then FRotation = FRotation - 360 end
   end
   
   function self.Scale(AScale)
      FScale = FScale + AScale
   end

   -----------------------------------------------------------------------------
   function self.LineColour(AColour)
      FLineColour = AColour
   end
   
   -----------------------------------------------------------------------------
   function self.RectColour(AColour)
      FRectColour = AColour
   end
   
   function self.CircleColour(AColour)
      FCircleColour = AColour
   end   
   
   -----------------------------------------------------------------------------
   function self.TextColour(AColour)
      if AColour == nil then
         FTextColour = 0xFFFFFF
      else
         FTextColour = AColour
      end
   end   
   
   function self.LineWidth(AWidth)
      FLineWidth = AWidth
   end
      
   -----------------------------------------------------------------------------   
   function self.Line(AStartX,AStartY,AEndX,AEndY,APenStyle)
      if not APenStyle then APenStyle = 0 end
      
      
      --[[
      --Optimized
      AStartX = AStartX-FTranslationX
      AStartY = AStartY-FTranslationY
      AEndX = AEndX-FTranslationX
      AEndY = AEndY-FTranslationY       
      A_X = FTranslationX + AStartX*FRotationCos - AStartY*FRotationSin 
      A_Y = FTranslationY + AStartX*FRotationSin + AStartY*FRotationCos
      B_X = FTranslationX + AEndX*FRotationCos - AEndY*FRotationSin
      B_Y = FTranslationY + AEndX*FRotationSin + AEndY*FRotationCos      
      --WindowLine(self.MushWindow, A_X, A_Y, B_X, B_Y, FLineColour, 0, FLineWidth)
      --]]
      
      --[[
      --Original
      A_X = FTranslationX + (AStartX-FTranslationX)*FRotationCos - (AStartY-FTranslationY)*FRotationSin 
      A_Y = FTranslationY + (AStartX-FTranslationX)*FRotationSin + (AStartY-FTranslationY)*FRotationCos
      B_X = FTranslationX + (AEndX-FTranslationX)*FRotationCos - (AEndY-FTranslationY)*FRotationSin
      B_Y = FTranslationY + (AEndX-FTranslationX)*FRotationSin + (AEndY-FTranslationY)*FRotationCos
      WindowLine(self.MushWindow, A_X, A_Y, B_X, B_Y, FLineColour, 0, FLineWidth)      
      --]]          
                  
      --No rotation / translation                  
      WindowLine(self.MushWindow, AStartX, AStartY, AEndX, AEndY, FLineColour, APenStyle, FLineWidth)      
   end
      
   -----------------------------------------------------------------------------   
   function self.Rect(ALeft, ATop, ARight, ABottom)
      WindowRectOp(self.MushWindow, 2, ALeft, ATop, ARight, ABottom, FRectColour)      
   end
   
   -----------------------------------------------------------------------------
   function self.RectOutline(ALeft, ATop, ARight, ABottom)
   -- Window border
      WindowRectOp(self.MushWindow, 4, ALeft, ATop, ARight, ABottom, FRectColour, FRectColour)  -- Two Colour Border
   end
   
   -----------------------------------------------------------------------------   
   function self.Circle(ALeft,ATop,ARight,ABottom)
      WindowCircleOp(self.MushWindow,1, ALeft, ATop, ARight, ABottom, FLineColour, 0, FLineWidth, FCircleColour, 0) -- circle   
   end
   
   -----------------------------------------------------------------------------   
   function self.CircleOutline(ALeft,ATop,ARight,ABottom)
      WindowCircleOp(self.MushWindow,1, ALeft, ATop, ARight, ABottom, FLineColour, 0, FLineWidth, FCircleColour, 0) -- circle   
   end     
   
   -----------------------------------------------------------------------------
   function self.Text(AText, AFont, ALeft, ATop, ARight, ABottom)         
      WindowText(self.MushWindow, AFont, AText, ALeft, ATop, ARight, ABottom, FTextColour)
   end   
   -----------------------------------------------------------------------------
   function self.TextCenter(AText, ALeft, ATop, ARight, ABottom, AFont)            
      WindowText(self.MushWindow, AFont, AText, ALeft, ATop, ARight, ABottom, FTextColour)
   end
   -----------------------------------------------------------------------------
   function self.TextWidth(AText, AFont)
      return WindowTextWidth(self.MushWindow, AFont, AText)
   end
   
   function self.TextHeight(AText, AFont)
      return WindowFontInfo(self.MushWindow, AFont, 1)
   end
   
   function self.RenderTo(ATarget, ALeft, ATop, ARight, ABottom)
      
      
      --FTranslationX = UIWindowMap.ViewPort.CenterH - UIWindowMap.ViewPort.Left  
      --FTranslationY = UIWindowMap.ViewPort.CenterV - UIWindowMap.ViewPort.Top                           
      --testing - slowly rotate
      --self.Rotate(FRotation + (0.5 * DegToRad))
      --if FRotation > PI2 then FRotation = 0 end
      
      --FWindowDrawImage(AWindow.MushWindow, self.Image, ALeft, ATop, ARight, ABottom, 2) --slower but scaling            
      FWindowBlendImage(ATarget.MushWindow, self.Image, ALeft, ATop, ARight, ABottom, 1, 1) --faster but no scaling     
   end
   
   ---Set Surface Dimensions
   function self.SetSize(AWidth, AHeight)
      self.Width = AWidth
      self.Height = AHeight
      WindowResize(self.MushWindow, AWidth, AHeight, FSurfaceColour)      
   end
   
   
   ---Clear Surface
   function self.Clear()
      self.RectColour(0x00000000)
      self.Rect(0, 0, self.Width, self.Height)
   end   
   
   ---Load an image file, return Image
   function self.ImageLoad(AFileName)
      local AImage = UIImageCreate(self.MushWindow)      
      local AResult = WindowLoadImage(self.MushWindow, AImage.MushImage, AFileName)
      return AImage
   end
      
   ---Save surface to image file 
   function self.ImageSave(AFileName)
      local AResult = WindowWrite(self.MushWindow, AFileName);
   end
   
   ---Create an image from source surface data, return ImageID
   function self.ImageCreate(ASource)
      local AImage = UIImageCreate(self.MushWindow)
      WindowImageFromWindow(self.MushWindow, AImage.MushImage, ASource.MushWindow)
      return AImage
   end
      
   -----------------------------------------------------------------------------
   --Constructor                                                     Constructor
   -----------------------------------------------------------------------------  
            
   WindowCreate(self.MushWindow, 0, 0, self.Width, self.Height,  4, 4, FSurfaceColour)
   UIFontCreate(self.MushWindow, self.Font, FFontName, FFontHeight,false) 
   UIFontCreate(self.MushWindow, self.FontSmall, FFontSmallName, FFontSmallHeight,false)
   
   WindowImageFromWindow(AWindow.MushWindow, self.Image, self.MushWindow)
   
   --insert reference into Surface collection   
   table.insert(UISurfaces,self)   
   return self      
end