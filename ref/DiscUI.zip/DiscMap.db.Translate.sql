UPDATE Rooms SET RoomPositionX = (Rooms.RoomPositionX + 4096), RoomPositionY = (Rooms.RoomPositionY + 4096);

UPDATE Sectors SET SectorPositionX = (Sectors.SectorPositionX + 256), SectorPositionY = (Sectors.SectorPositionY + 256);

UPDATE Sectors SET CellLeft = (Sectors.CellLeft + 4096), CellTop = (Sectors.CellTop + 4096), CellRight = (Sectors.CellRight + 4096), CellBottom = (Sectors.CellBottom + 4096);

UPDATE Regions SET RegionSectorLeft = (Regions.RegionSectorLeft + 256), RegionSectorTop = (Regions.RegionSectorTop + 256), RegionSectorBottom = (Regions.RegionSectorBottom + 256), RegionSectorRight = (Regions.RegionSectorRight + 256);