--------------------------------------------------------------------------------
--//DiscUI Widget Button 
--------------------------------------------------------------------------------

function UIWidgetButtonCreate(AWindow, AWidgetLeft, AWidgetTop, AWidgetRight, AWidgetBottom)
   
    local self = UIWidgetCreate(AWindow, AWidgetLeft, AWidgetTop, AWidgetRight, AWidgetBottom)
          
   --overrides
   self.WidgetType = UIWidget_Button
   self.WidgetTypeName = "WidgetButton"
   self.SetCaption("Button")      
   self.ColourBackground = 0x363636
   self.Font = self.Window.FontSmall   
   --additions
   
   --callbacks         

      
   --additions    
   
   self.RenderParent = self.Render
   function self.Render()   
               
      --don't render default widget rect
      --self.RenderParent()  
      
      local AColour = 0
      local AColourBack = 0
      --Render Background
      if self.IsHovering == true then
         self.Window.RectColour(self.ColourBackgroundHovering)
         AColour = self.ColourBackgroundHovering
         AColourBack = 0x222222
      else
         self.Window.RectColour(self.ColourBackground)
         AColour = self.ColourBackground
         AColourBack = 0x111111
      end     
      
      -- Titlebar
      WindowGradient(self.Window.MushWindow, self.Left,self.Top,self.Right,self.Bottom, AColour, AColourBack, 2) --1 = horz, 2 = vert
             
             
      --self.Window.Rect(self.Left,self.Top,self.Right,self.Bottom)
                       
      local APosX = self.Left + (self.WidthDiv2 - self.CaptionWidthDiv2)
      local APosY = self.Top + (self.HeightDiv2 - self.CaptionHeightDiv2)
            
      --Render Text
      self.Window.TextColour(self.ColourFont)
      self.Window.Text(self.Caption, self.Font, APosX, APosY, APosX + self.CaptionWidth, APosY + self.CaptionHeight)
      
      --Render outline
      self.Window.RectColour(0x939393)
      self.Window.RectOutline(self.Left,self.Top,self.Right,self.Bottom)                      
   end
   
   
   --Setup Button
   
   
               
   return self      
end