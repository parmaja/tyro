-----------------------
--DiscUI Reset Database
-----------------------

--Delete Records
delete from Colours;
delete from Sectors;
delete from Rooms;
delete from RoomPlaces;
delete from RoomStreets;
delete from Portals;
delete from Places;
delete from Streets;

--Reset Sequences
UPDATE sqlite_sequence SET seq = 0 where name = 'Colours';
UPDATE sqlite_sequence SET seq = 0 where name = 'Sectors';
UPDATE sqlite_sequence SET seq = 0 where name = 'Rooms';
UPDATE sqlite_sequence SET seq = 0 where name = 'RoomPlaces';
UPDATE sqlite_sequence SET seq = 0 where name = 'RoomStreets';
UPDATE sqlite_sequence SET seq = 0 where name = 'Portals';
UPDATE sqlite_sequence SET seq = 0 where name = 'Places';
UPDATE sqlite_sequence SET seq = 0 where name = 'Streets';

--Temp - Reset Region Sector Bounds
UPDATE Regions SET RegionSectorLeft = 0, RegionSectorTop = 0, RegionSectorRight = 0, RegionSectorBottom = 0 WHERE RegionID = 1;