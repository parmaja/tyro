--------------------------------------------------------------------------------
--//DiscUI Map Render
--------------------------------------------------------------------------------

--library local references
local math_floor = math.floor
local math_ceil = math.ceil
local math_max = math.max
local string_byte = string.byte
local string_sub = string.sub
local FUIMapExitTypeColour = UIMapExitTypeColour
local FUIMapSectorSize = UIMapSectorSize

--Surface/Map References
local FMapRenderSurface = nil
local FMapRenderSurfaceMushWindow = ""
local FMapRenderSurfaceBuffer = nil
local FMapRenderSurfaceBufferMushWindow = ""
local FMapRenderMapBuffer = nil

--Current Rendering Function References
local FMapRenderCurrentMushWindow = ""
local FMapRenderCurrentLineColour = nil
local FMapRenderCurrentRectColour = nil
local FMapRenderCurrentLine = nil            
local FMapRenderCurrentRect = nil

--Current Rendering Properties
local FMapRenderDelta = 0

local FViewportMiddleX = 0 
local FViewportMiddleY = 0 
local FViewportLeft = 0 
local FViewportTop = 0 
local FViewportRight = 0 
local FViewportBottom = 0
local FViewportWidth = 0
local FViewportHeight = 0

local FMapRenderCurrentCellSize = 0      
local FMapRenderCurrentCellSizeDiv2 = 0                        
local FMapRenderCurrentLineWidth = 5
local FRoomRenderPlayerMinRadius = 4  
local FRoomRenderPlayerRadius = 4
local FRoomRenderPlayerOutlineRadius = 4
local FRoomRenderRoomOutlineRadius = 4

local FRenderCellLeft = 0
local FRenderCellTop = 0
local FRenderCellRight = 0
local FRenderCellBottom = 0
local FRenderCellMiddleX = 0
local FRenderCellMiddleY = 0
local FRoomRenderPosLeft = 0
local FRoomRenderPosTop = 0
local FRoomRenderPosRight = 0
local FRoomRenderPosBottom = 0

local ACameraPositionX = 0
local ACameraPositionY = 0
local ASectors = nil 
local ASector = {}

local FRoomRenderColourRoom = 0x000000
local FRoomRenderColourStreet = 0
local FRenderColourCell = 0x000000

--------------------------------------------------------------------------------
local function UIWindowMapRenderRoomStreet(ARoom, APositionX, APositionY)
   
   local FColour = 0x000000
   local FRenderColour = 0   
   --local FR,FG,FB = 0   
   --FR,FG,FB = UIColourToRGB(UIMapColours[ARoom.Region.RegionColour])    
   --FR,FG,FB = UIRGBBlend(255,255,255, FR,FG,FB, 0.55)   
   --FColour = UIRGBToColour(FR,FG,FB)
   FColour = UIColourBlend(0xFFFFFF, UIMapColours[ARoom.Region.RegionColour],0.55)
        
   local HoverStreet = false
   --if #ARoom.RoomStreets > 0 then         
   --   if UIWindowMap.MapBuffer.HoveringStreet then            
   --      if ARoom.RoomStreets[1].StreetID == UIWindowMap.MapBuffer.HoveringStreet.StreetID then
   --         HoverStreet = true                        
   --      end
   --   end
   --end
   
   if ARoom.Selected then
      HoverStreet = true
   end
                  
   if (ARoom.ExitNorth > -1) and (ARoom.ExitSouth > -1) and (ARoom.ExitNorthType == ARoom.ExitSouthType) then
   
      if ARoom.ExitNorthType == 2 then -- door    
         FRenderColour = UIMapExitTypeColour[2]
      else
         FRenderColour = FColour 
      end    
      if HoverStreet then FRenderColour = 0xFFFFFF end         
      FMapRenderCurrentLineColour(FRenderColour)
      FMapRenderCurrentLine(APositionX, FRenderCellTop, APositionX, FRenderCellBottom)                                         
   else           
      if ARoom.ExitNorth > -1 then         
         if ARoom.ExitNorthType == 2 then -- door    
            FRenderColour = UIMapExitTypeColour[2]
         else
            FRenderColour = FColour 
         end    
         if HoverStreet then FRenderColour = 0xFFFFFF end         
         FMapRenderCurrentLineColour(FRenderColour)
         FMapRenderCurrentLine(APositionX, FRenderCellTop, APositionX, APositionY)                                                   
      end         
      if ARoom.ExitSouth > -1 then
         if ARoom.ExitSouthType == 2 then -- door    
            FRenderColour = UIMapExitTypeColour[2]
         else
            FRenderColour = FColour 
         end    
         if HoverStreet then FRenderColour = 0xFFFFFF end         
         FMapRenderCurrentLineColour(FRenderColour)
         FMapRenderCurrentLine(APositionX, APositionY, APositionX, FRenderCellBottom)                            
      end   
   end   
   if (ARoom.ExitEast > -1) and (ARoom.ExitWest > -1) and (ARoom.ExitEastType == ARoom.ExitWestType) then 
      if ARoom.ExitEastType == 2 then -- door    
            FRenderColour = UIMapExitTypeColour[2]
         else
            FRenderColour = FColour 
         end    
         if HoverStreet then FRenderColour = 0xFFFFFF end         
         FMapRenderCurrentLineColour(FRenderColour)
      FMapRenderCurrentLine(FRenderCellLeft, APositionY, FRenderCellRight, APositionY)                         
   else
      if ARoom.ExitEast > -1 then
         if ARoom.ExitEastType == 2 then -- door    
            FRenderColour = UIMapExitTypeColour[2]
         else
            FRenderColour = FColour 
         end    
         if HoverStreet then FRenderColour = 0xFFFFFF end         
         FMapRenderCurrentLineColour(FRenderColour)
         FMapRenderCurrentLine(APositionX, APositionY, FRenderCellRight, APositionY)                                    
      end
        if ARoom.ExitWest > -1 then
         if ARoom.ExitWestType == 2 then -- door    
            FRenderColour = UIMapExitTypeColour[2]
         else
            FRenderColour = FColour 
         end    
         if HoverStreet then FRenderColour = 0xFFFFFF end         
         FMapRenderCurrentLineColour(FRenderColour)
         FMapRenderCurrentLine(APositionX, APositionY, FRenderCellLeft, APositionY)             
      end   
   end          
   if (ARoom.ExitNorthEast > -1) and (ARoom.ExitSouthWest > -1) and (ARoom.ExitNorthEastType == ARoom.ExitSouthWestType) then 
      if ARoom.ExitNorthEastType == 2 then -- door    
            FRenderColour = UIMapExitTypeColour[2]
         else
            FRenderColour = FColour 
         end    
         if HoverStreet then FRenderColour = 0xFFFFFF end         
         FMapRenderCurrentLineColour(FRenderColour)
      FMapRenderCurrentLine(FRenderCellLeft, FRenderCellBottom, FRenderCellRight, FRenderCellTop)                              
   else
      if ARoom.ExitNorthEast > -1 then
         if ARoom.ExitNorthEastType == 2 then -- door    
            FRenderColour = UIMapExitTypeColour[2]
         else
            FRenderColour = FColour 
         end    
         if HoverStreet then FRenderColour = 0xFFFFFF end         
         FMapRenderCurrentLineColour(FRenderColour)
         FMapRenderCurrentLine(APositionX, APositionY, FRenderCellRight, FRenderCellTop)                                      
      end             
      if ARoom.ExitSouthWest > -1 then
         if ARoom.ExitSouthWestType == 2 then -- door    
            FRenderColour = UIMapExitTypeColour[2]
         else
            FRenderColour = FColour 
         end    
         if HoverStreet then FRenderColour = 0xFFFFFF end         
         FMapRenderCurrentLineColour(FRenderColour)
         FMapRenderCurrentLine(APositionX, APositionY, FRenderCellLeft, FRenderCellBottom)               
      end   
   end   
   if (ARoom.ExitNorthWest > -1) and (ARoom.ExitSouthEast > -1) and (ARoom.ExitNorthWestType == ARoom.ExitSouthEastType) then 
         if ARoom.ExitNorthWestType == 2 then -- door    
            FRenderColour = UIMapExitTypeColour[2]
         else
            FRenderColour = FColour 
         end    
         if HoverStreet then FRenderColour = 0xFFFFFF end         
         FMapRenderCurrentLineColour(FRenderColour)
      FMapRenderCurrentLine(FRenderCellRight, FRenderCellBottom, FRenderCellLeft, FRenderCellTop)                         
   else
      if ARoom.ExitNorthWest > -1 then
      if ARoom.ExitNorthWestType == 2 then -- door    
            FRenderColour = UIMapExitTypeColour[2]
         else
            FRenderColour = FColour 
         end    
         if HoverStreet then FRenderColour = 0xFFFFFF end         
         FMapRenderCurrentLineColour(FRenderColour)
         FMapRenderCurrentLine(APositionX, APositionY, FRenderCellLeft, FRenderCellTop)              
      end
      if ARoom.ExitSouthEast > -1 then
         if ARoom.ExitSouthEastType == 2 then -- door    
            FRenderColour = UIMapExitTypeColour[2]
         else
            FRenderColour = FColour 
         end    
         if HoverStreet then FRenderColour = 0xFFFFFF end         
         FMapRenderCurrentLineColour(FRenderColour)
         FMapRenderCurrentLine(APositionX, APositionY, FRenderCellRight, FRenderCellBottom)               
      end         
   end         
end

--------------------------------------------------------------------------------
local function UIWindowMapRenderRoom(ARoom, APositionX, APositionY)   
   if (FMapRenderCurrentCellSize) > 5 then
      --dont render rooms if pixel size is less than N      
            
      FRoomRenderPosLeft = APositionX-(FMapRenderCurrentCellSizeDiv2)
      FRoomRenderPosTop = APositionY-(FMapRenderCurrentCellSizeDiv2)
      FRoomRenderPosRight = APositionX+(FMapRenderCurrentCellSizeDiv2)
      FRoomRenderPosBottom = APositionY+(FMapRenderCurrentCellSizeDiv2)
      
      local AColour = FRoomRenderColourRoom     
      if ARoom.Selected then
         AColour = 0xFFFFFF
      end
   
      if ((FRoomRenderPosRight-1) > FViewportLeft) and ((FRoomRenderPosBottom-1) > FViewportTop) and (FRoomRenderPosLeft < FViewportRight) and (FRoomRenderPosTop < FViewportBottom) then                                               
      WindowCircleOp(FMapRenderCurrentMushWindow,1, FRoomRenderPosLeft, FRoomRenderPosTop, FRoomRenderPosRight, FRoomRenderPosBottom, ColourRoomOutline, 0, 1, AColour, 0) -- circle
      end
   end                  
end

--------------------------------------------------------------------------------
local function UIWindowMapRenderCell(AChar, ACharColour, APositionX, APositionY)
   
   local AColourID = 0
   
   if ACharColour == nil then AColourID = 1 elseif ACharColour == "" then AColourID = 1
   else
      AColourID = string.byte(ACharColour)-47  --starts at '0' 1 used for split
   end
               
   FRenderColourCell = UIMapColours[AColourID]
   
   FMapRenderCurrentRectColour(FRenderColourCell)
   FMapRenderCurrentRect(APositionX-FMapRenderCurrentCellSizeDiv2, APositionY-FMapRenderCurrentCellSizeDiv2, APositionX+FMapRenderCurrentCellSizeDiv2, APositionY+FMapRenderCurrentCellSizeDiv2)      
end










--------------------------------------------------------------------------------  
function UIMapRenderRooms(ARegion, AParentScale, APositionX, APositionY)

   local AZ = 0
   local RoomRenderCount = 0
   local AScale = AParentScale
   local APositionScale = 1
   
   if ARegion.RegionStride == 1 then
      AScale = AScale / 2
      APositionScale = 2
   end
   
   --rescale to parent
   FMapRenderCurrentCellSize = (UIWindowMap.CellSize * AScale)  
   FMapRenderCurrentCellSizeDiv2 = (UIWindowMap.CellSizeDiv2 * AScale)
   FRoomRenderPlayerMinRadius = 4  
   FRoomRenderPlayerRadius = math_max(FMapRenderCurrentCellSizeDiv2, FRoomRenderPlayerMinRadius) + 1
   FRoomRenderPlayerOutlineRadius = math_max(FMapRenderCurrentCellSizeDiv2, FRoomRenderPlayerMinRadius) + 1   
   FRoomRenderRoomOutlineRadius = FMapRenderCurrentCellSizeDiv2 + 1         
   ACameraPositionX = UIWindowMap.CameraPositionX
   ACameraPositionY = UIWindowMap.CameraPositionY      
  
     --Position of the camera inside this region
   local FRegionCameraPositionX = (UIWindowMap.CameraPositionX - (APositionX)) / (AParentScale)      
   local FRegionCameraPositionY = (UIWindowMap.CameraPositionY - (APositionY)) / (AParentScale)   
   local FRegionCellSize = (UIWindowMap.CellSize) * (AParentScale) --Region Cell Size (after scaling)   
   local FRegionCellWidth = FViewportWidth/FRegionCellSize
   local FRegionCellHeight = FViewportHeight/FRegionCellSize   
   local FRegionCellLeft = math_floor(FRegionCameraPositionX - (FRegionCellWidth/2)) 
   local FRegionCellTop = math_floor(FRegionCameraPositionY - (FRegionCellHeight/2))
   local FRegionCellRight = math_floor(FRegionCameraPositionX + (FRegionCellWidth/2))
   local FRegionCellBottom = math_floor(FRegionCameraPositionY + (FRegionCellHeight/2))      
      
   local FRegionSectorLeft = math_floor(FRegionCellLeft / UIMapSectorSize)
   local FRegionSectorTop = math_floor(FRegionCellTop / UIMapSectorSize)
   local FRegionSectorRight = math_floor(FRegionCellRight / UIMapSectorSize)
   local FRegionSectorBottom = math_floor(FRegionCellBottom / UIMapSectorSize)   
   --if ARegion.RegionID == 1 then                          
   --   Note("VIEW FRegionSectorLTRB = ["..FRegionSectorLeft ..","..FRegionSectorTop..","..FRegionSectorRight..","..FRegionSectorBottom.."]")      
   --end    
   FRegionSectorLeft = math.max(FRegionSectorLeft, ARegion.RegionSectorLeft)   
   FRegionSectorTop = math.max(FRegionSectorTop, ARegion.RegionSectorTop)   
   FRegionSectorRight = math.min(FRegionSectorRight, ARegion.RegionSectorRight)
   FRegionSectorBottom = math.min(FRegionSectorBottom, ARegion.RegionSectorBottom)   
   --if ARegion.RegionID == 1 then                        
   --   Note("CLIP FRegionSectorLTRB = ["..FRegionSectorLeft ..","..FRegionSectorTop..","..FRegionSectorRight..","..FRegionSectorBottom.."]")      
   --end
               
   ASectors = ARegion.RegionSectorsXYZ   
   ASector = {}   
  
   --A Linewidth of 0 is faster than a linewidth of 1
   FMapRenderCurrentLineWidth = FMapRenderCurrentCellSize / 3
   if FMapRenderCurrentLineWidth < 0 then FMapRenderCurrentLineWidth = 0 end
   FMapRenderSurface.LineWidth(FMapRenderCurrentLineWidth)   
   
                
   --Setup Colours for this Region
   FRoomRenderColourRoom = UIMapColours[ARegion.RegionColour]   
   FRoomRenderColourStreet = UIMapColours[ARegion.RegionColour]
   FRenderColourCell = 0xFFFFFF
                              
   if ASectors then                 
      for AX = FRegionSectorLeft, FRegionSectorRight do               
         for AY = FRegionSectorTop, FRegionSectorBottom do
                                                      
            ASector = ASectors[AX..":"..AY..":"..AZ]
                          
            if ASector == nil then               
            else                                 
               for _,ARoom in pairs(ASector.SectorRoomsXYZ) do             
                  if ARoom then                        
   
                     FRenderCellMiddleX = ((APositionX - ACameraPositionX) * (FMapRenderCurrentCellSize/AScale)) + FViewportMiddleX 
                     FRenderCellMiddleY = ((APositionY - ACameraPositionY) * (FMapRenderCurrentCellSize/AScale)) + FViewportMiddleY                                                                                                                               
                     FRenderCellMiddleX = FRenderCellMiddleX+((ARoom.RoomPositionX*APositionScale) * FMapRenderCurrentCellSize) 
                     FRenderCellMiddleY = FRenderCellMiddleY+((ARoom.RoomPositionY*APositionScale) * FMapRenderCurrentCellSize)
                     
                     --add the width of the lines so that thick lines don't 'pop' into view                       
                     FRoomRenderPosLeft = FRenderCellMiddleX-(FMapRenderCurrentCellSize+FMapRenderCurrentLineWidth)
                     FRoomRenderPosTop = FRenderCellMiddleY-(FMapRenderCurrentCellSize+FMapRenderCurrentLineWidth)
                     FRoomRenderPosRight = FRenderCellMiddleX+(FMapRenderCurrentCellSize+FMapRenderCurrentLineWidth)
                     FRoomRenderPosBottom = FRenderCellMiddleY+(FMapRenderCurrentCellSize+FMapRenderCurrentLineWidth)                       
                         
                     --if (FRoomRenderPosRight >= FViewportLeft) and (FRoomRenderPosBottom >= FViewportTop) and (FRoomRenderPosLeft <= FViewportRight) and (FRoomRenderPosTop <= FViewportBottom) then
                        
                        FRenderCellLeft = FRenderCellMiddleX-(FMapRenderCurrentCellSize+1)
                        FRenderCellTop = FRenderCellMiddleY-(FMapRenderCurrentCellSize+1)
                        FRenderCellRight = FRenderCellMiddleX+(FMapRenderCurrentCellSize+1)
                        FRenderCellBottom = FRenderCellMiddleY+(FMapRenderCurrentCellSize+1)
                                                                        
                        UIWindowMapRenderRoomStreet(ARoom, FRenderCellMiddleX, FRenderCellMiddleY)                                                                          
                        UIWindowMapRenderRoom(ARoom, FRenderCellMiddleX, FRenderCellMiddleY)
                                                
                        RoomRenderCount = RoomRenderCount + 1                                    
                     --end                           
                  end
               end                           
            end        
         end
      end      
   end  
end



--------------------------------------------------------------------------------  
function UIMapRenderRoomsSurface(ARegion, AParentScale, APositionX, APositionY)        
   
   UIMapRenderCacheRoomsBuffer(ARegion, AParentScale, APositionX, APositionY)
      
   FMapRenderCurrentMushWindow = FMapRenderSurfaceMushWindow   
   FMapRenderCurrentRectColour = FMapRenderSurface.RectColour
   FMapRenderCurrentLineColour = FMapRenderSurface.LineColour 
   FMapRenderCurrentLine = FMapRenderSurface.Line
   FMapRenderCurrentRect = FMapRenderSurface.Rect
   
   UIMapRenderRooms(ARegion, AParentScale, APositionX, APositionY)  
                
end

--------------------------------------------------------------------------------
function UIMapRenderRoomsRecurseSurface(ARegion, AParentScale, AParentPositionX, AParentPositionY)   

   AParentPositionX = (AParentPositionX) + (ARegion.RegionParentPositionX*AParentScale)
   AParentPositionY = (AParentPositionY) + (ARegion.RegionParentPositionY*AParentScale)                               
   AParentScale = AParentScale*ARegion.RegionParentScale
             
   if ARegion.RegionType == 1 then --City      
      --UIMapRenderCellsSurface(AMapBuffer, ASurface, ARegion, ADelta,  AViewportMiddleX, AViewportMiddleY, AViewportLeft, AViewportTop, AViewportRight, AViewportBottom)
      UIMapRenderRoomsSurface(ARegion, AParentScale, AParentPositionX, AParentPositionY)
   elseif ARegion.RegionType == 2 then --Room      
      --UIMapRenderCellsSurface(AMapBuffer, ASurface, ARegion, ADelta,  AViewportMiddleX, AViewportMiddleY, AViewportLeft, AViewportTop, AViewportRight, AViewportBottom)
      UIMapRenderRoomsSurface(ARegion, AParentScale, AParentPositionX, AParentPositionY)
   elseif ARegion.RegionType == 3 then --Terrain    
      --UIMapRenderCellsSurface(AMapBuffer, ASurface, ARegion, AParentScale, AParentPositionX, AParentPositionY)                  
      UIMapRenderRoomsSurface(ARegion, AParentScale, AParentPositionX, AParentPositionY)
   end             
  
   for _,CRegion in pairs(ARegion.RegionChildren) do              
      UIMapRenderRoomsRecurseSurface(CRegion, AParentScale, AParentPositionX, AParentPositionY)         
   end
end

--------------------------------------------------------------------------------  
function UIMapRenderCells(ARegion, AParentScale, APositionX, APositionY)

   if not AParentScale then AParentScale = 1 end
   local CellRenderCount = 0   
   local AZ = 0    
   local AScale = (AParentScale*ARegion.RegionParentScale)
   local APositionScale = 1
   if ARegion.RegionParentScale == 2 and ARegion.RegionType == 3 then
      AScale = (AParentScale*1)
      APositionScale = 2
   end
   
   --rescale to parent
   FMapRenderCurrentCellSize = UIWindowMap.CellSize * AScale  
   FMapRenderCurrentCellSizeDiv2 = UIWindowMap.CellSizeDiv2 * AScale
     
   local ACameraPositionX = UIWindowMap.CameraPositionX
   local ACameraPositionY = UIWindowMap.CameraPositionY
        
   local FPositionOffsetX = ((APositionX - ACameraPositionX) * (FMapRenderCurrentCellSize/AScale)) + FViewportMiddleX 
   local FPositionOffsetY = ((APositionY - ACameraPositionY) * (FMapRenderCurrentCellSize/AScale)) + FViewportMiddleY          
   
   --Sector bounds to render (clip to region then view)
   local ASectorLeft = math.max(ARegion.RegionSectorLeft, math_floor((ACameraPositionX - (((FViewportRight-FViewportLeft)/2)/FMapRenderCurrentCellSize) ) / FUIMapSectorSize))   
   local ASectorTop = math.max(ARegion.RegionSectorTop, math_floor((ACameraPositionY - (((FViewportBottom-FViewportTop)/2)/FMapRenderCurrentCellSize) ) / FUIMapSectorSize))   
   local ASectorRight = math.min(ARegion.RegionSectorRight, math_ceil((ACameraPositionX + (((FViewportRight-FViewportLeft)/2)/FMapRenderCurrentCellSize) ) / FUIMapSectorSize))
   local ASectorBottom = math.min(ARegion.RegionSectorBottom, math_ceil((ACameraPositionY + (((FViewportBottom-FViewportTop)/2)/FMapRenderCurrentCellSize) ) / FUIMapSectorSize))
   
               
   local ASectors = ARegion.RegionSectorsXYZ   
   local ASector = nil   

   --Setup Colours for this Region       
   local FRenderColourCell = 0xFFFFFF
                            
   local AStr = ""
   local AStrColour = ""
   local AChar = ""
   local ACharColour = ""
        
   if ASectors then           
      for AX = ASectorLeft, ASectorRight do               
         for AY = ASectorTop, ASectorBottom do  
            ASector = ASectors[AX..":"..AY..":"..AZ]
            if ASector then
               for ASectorPosY = 1, FUIMapSectorSize do                  
                  
                  --get source string for this cell
                  AStr = ASector.SectorData[ASectorPosY]
                  AStrColour = ASector.SectorDataColour[ASectorPosY]
                  if (AStrColour) and (trim(AStrColour) ~= "") then
                     FRenderCellMiddleY = FPositionOffsetY+((ASector.CellTop + ASectorPosY-1) * FMapRenderCurrentCellSize)                            
                     FRoomRenderPosTop = FRenderCellMiddleY-FMapRenderCurrentCellSizeDiv2               
                     FRoomRenderPosBottom = FRoomRenderPosTop + FMapRenderCurrentCellSize
                     
                     --[[
                     --line can be drawn as one block                     
                     if StringIsRepeatedChar(string.sub(AStrColour,(#AStrColour/4)*1,(#AStrColour/4)*2)," ") then                     
                     elseif StringIsRepeatedChar(string.sub(AStrColour,(#AStrColour/4)*1,(#AStrColour/4)*2)) then                                                                                           
                        FRoomRenderPosLeft = FPositionOffsetX+((ASector.CellLeft+(#AStrColour/4)*1)*FMapRenderCurrentCellSize)                                                              
                        FRoomRenderPosRight = FPositionOffsetX+((ASector.CellLeft+(#AStrColour/4)*2)*FMapRenderCurrentCellSize)                               
                        ACharColour = string_sub(AStrColour,(#AStrColour/4)*1,(#AStrColour/4)*1) --get source char for this cell   
                        FRenderColourCell = UIMapColours[string_byte(ACharColour)-47] --starts at '0' 1 used for split                           
                        FMapRenderCurrentRectColour(FRenderColourCell)
                        FMapRenderCurrentRect(FRoomRenderPosLeft, FRoomRenderPosTop, FRoomRenderPosRight, FRoomRenderPosBottom)
                     end
                     --]]  
                            
                     if (FRoomRenderPosBottom > FViewportTop+1) and (FRoomRenderPosTop < FViewportBottom-1) then                        
                        for ASectorPosX = 1, FUIMapSectorSize do
                          
                           FRenderCellMiddleX = FPositionOffsetX+(
                           (ASector.CellLeft + ASectorPosX-1)--*ARegion.RegionStride) 
                           * FMapRenderCurrentCellSize) 
                                                                          
                           FRoomRenderPosLeft = FRenderCellMiddleX-FMapRenderCurrentCellSizeDiv2                        
                           FRoomRenderPosRight = FRoomRenderPosLeft + FMapRenderCurrentCellSize 
                                                                    
                           if (FRoomRenderPosRight > FViewportLeft+1) and (FRoomRenderPosLeft < FViewportRight-1)                               
                           then                                                                                                                                                                                                                                                                                          
                              --AChar = string_sub(AStr,ASectorPosX,ASectorPosX) --get source char for this cell   
                              ACharColour = string_sub(AStrColour,ASectorPosX,ASectorPosX) --get source colour for this cell
                              --if (AChar ~= " ") then                                                         
                              if (ACharColour ~= " ") then                                                                                                                                                
                                 UIWindowMapRenderCell(AChar,ACharColour,FRenderCellMiddleX,FRenderCellMiddleY) --render this cell
                                 CellRenderCount = CellRenderCount + 1            
                              end                              
                           end                        
                        end                                             
                     end                               
                  end                     
               end                                       
            end --if ASector then                   
         end --for AY = ASectorTop, ASectorBottom do    
      end --for AX = ASectorLeft, ASectorRight do                          
   end   
end




--------------------------------------------------------------------------------
function UIMapRenderCellsSurface(ARegion, AParentScale, APositionX, APositionY) 
  
   --create cached image if needed
   UIMapRenderCacheCellsBuffer(ARegion, AParentScale, APositionX, APositionY)    
      
   FMapRenderCurrentMushWindow = FMapRenderSurfaceMushWindow   
   FMapRenderCurrentRectColour = FMapRenderSurface.RectColour
   FMapRenderCurrentLineColour = FMapRenderSurface.LineColour 
   FMapRenderCurrentLine = FMapRenderSurface.Line
   FMapRenderCurrentRect = FMapRenderSurface.Rect   
   UIMapRenderCells(ARegion, AParentScale, APositionX, APositionY)    
end

--------------------------------------------------------------------------------
function UIMapRenderCellsRecurseSurface(ARegion, AParentScale, AParentPositionX, AParentPositionY)

   AParentPositionX = (AParentPositionX) + (ARegion.RegionParentPositionX*AParentScale)
   AParentPositionY = (AParentPositionY) + (ARegion.RegionParentPositionY*AParentScale)                               
   AParentScale =  AParentScale*ARegion.RegionParentScale
         
   if ARegion.RegionType==3 then --only render terrains as cells     
      UIMapRenderCellsSurface(ARegion, AParentScale, AParentPositionX, AParentPositionY)
   end                  
  
   for _,CRegion in pairs(ARegion.RegionChildren) do              
      UIMapRenderCellsRecurseSurface(CRegion, AParentScale, AParentPositionX, AParentPositionY)
   end
end

--------------------------------------------------------------------------------
function UIMapRenderRegionOverlay(AMapBuffer, ASurface, ARegion, AParentScale, AParentPositionX, AParentPositionY)

      
   --Calculate scales/dimensions for this region   
   local FWorldScale = AMapBuffer.RegionGetWorldScale(AMapBuffer.CurrentRegion, 1)     
   FMapRenderCurrentCellSize = UIWindowMap.CellSize / FWorldScale
   FMapRenderCurrentCellSizeDiv2 = UIWindowMap.CellSizeDiv2 / FWorldScale
   FRoomRenderPlayerMinRadius = 4  
   FRoomRenderPlayerRadius = math_max(FMapRenderCurrentCellSizeDiv2, FRoomRenderPlayerMinRadius) + 1
   FRoomRenderPlayerOutlineRadius = math_max(FMapRenderCurrentCellSizeDiv2, FRoomRenderPlayerMinRadius) + 1   
   FRoomRenderRoomOutlineRadius = FMapRenderCurrentCellSizeDiv2 + 1
   
    --Render Current Path            
   FMapRenderCurrentLineWidth = UIWindowMap.CellSizeDiv4
   if FMapRenderCurrentLineWidth < 2 then FMapRenderCurrentLineWidth = 2 end
   FMapRenderSurface.LineWidth(FMapRenderCurrentLineWidth)      
   
   if AMapBuffer.Path then
      if #AMapBuffer.Path > 0 then
      
         FMapRenderSurface.LineColour(UIMapColoursDefault.yellow)
         FMapRenderSurface.LineWidth(3)      
         local LineStartX = 0
         local LineStartY = 0
         local LineEndX = 0
         local LineEndY = 0
         
         local FPathRoom = AMapBuffer.Path[1] 
         local FPathRoomRegion = FPathRoom.Region
         
         local FPathRoomWorldScale = AMapBuffer.RegionGetWorldScale(FPathRoomRegion, 1) 
         local FPathRoomCellSize = UIWindowMap.CellSize / FPathRoomWorldScale
         local FPathRoomCellSizeDiv2 = UIWindowMap.CellSizeDiv2 / FPathRoomWorldScale
         local APathRoomX, APathRoomY, APathRoomZ = AMapBuffer.RegionGetWorldPos(FPathRoomRegion,FPathRoom.RoomPositionX,FPathRoom.RoomPositionY,FPathRoom.RoomPositionZ)    
      
         local FPathRoomMinRadius = 4  
         local FPathRoomRadius = math_max(FPathRoomCellSizeDiv2, FPathRoomMinRadius) + 1
         
         LineStartX = (( (APathRoomX) - ACameraPositionX) * UIWindowMap.CellSize) + FViewportMiddleX 
         LineStartY = (( (APathRoomY) - ACameraPositionY) * UIWindowMap.CellSize) + FViewportMiddleY  
         
         for I = 1, #AMapBuffer.Path-1 do  
         
            FPathRoom = AMapBuffer.Path[I+1] 
            FPathRoomRegion = FPathRoom.Region
            
            FPathRoomWorldScale = AMapBuffer.RegionGetWorldScale(FPathRoomRegion, 1) 
            FPathRoomCellSize = UIWindowMap.CellSize / FPathRoomWorldScale
            FPathRoomCellSizeDiv2 = UIWindowMap.CellSizeDiv2 / FPathRoomWorldScale
            APathRoomX, APathRoomY, APathRoomZ = AMapBuffer.RegionGetWorldPos(FPathRoomRegion,FPathRoom.RoomPositionX,FPathRoom.RoomPositionY,FPathRoom.RoomPositionZ)    
           
            FPathRoomMinRadius = 4  
            FPathRoomRadius = math_max(FPathRoomCellSizeDiv2, FPathRoomMinRadius) + 1
                  
            LineEndX = (( (APathRoomX) - ACameraPositionX) * UIWindowMap.CellSize) + FViewportMiddleX 
            LineEndY = (( (APathRoomY) - ACameraPositionY) * UIWindowMap.CellSize) + FViewportMiddleY  

            FMapRenderSurface.Line(LineStartX,LineStartY,LineEndX,LineEndY)      

            LineStartX = LineEndX
            LineStartY = LineEndY                
         end
         
         
      end
   end 
   --[[                 
   --Render Current Path Bezier            
   if #AMapBuffer.Path > 0 then
      FMapRenderSurface.LineColour(UIMapColoursDefault.yellow)           
      local Line1X = 0
      local Line1Y = 0
      local Line2X = 0
      local Line2Y = 0
      local Line3X = 0
      local Line3Y = 0
      local Line4X = 0
      local Line4Y = 0
      local LinePrevX = 0
      local LinePrevY = 0
      local LineNextX = 0
      local LineNextY = 0
      
      for I = 1, #AMapBuffer.Path-2 do                                      
         Line1X = round(((AMapBuffer.Path[I].RoomPositionX - ACameraPositionX) * ACellSize) + AViewportMiddleX) 
         Line1Y = round(((AMapBuffer.Path[I].RoomPositionY - ACameraPositionY) * ACellSize) + AViewportMiddleY)          
         Line4X = round(((AMapBuffer.Path[I+1].RoomPositionX - ACameraPositionX) * ACellSize) + AViewportMiddleX) 
         Line4Y = round(((AMapBuffer.Path[I+1].RoomPositionY - ACameraPositionY) * ACellSize) + AViewportMiddleY)               
         LineNextX = round(((AMapBuffer.Path[I+2].RoomPositionX - ACameraPositionX) * ACellSize) + AViewportMiddleX) 
         LineNextY = round(((AMapBuffer.Path[I+2].RoomPositionY - ACameraPositionY) * ACellSize) + AViewportMiddleY)         
         x1 = Line1X
         y1 = Line1Y
         x2 = Line4X
         y2 = Line4Y         
         x0 = LinePrevX
         y0 = LinePrevY            
         x3 = LineNextX
         y3 = LineNextY              
         --Assume we need to calculate the control
         --points between (x1,y1) and (x2,y2).
         --Then x0,y0 - the previous vertex,
         --x3,y3 - the next one.            
         local smooth_value = 1.0               
         xc1 = (x0 + x1) / 2.0
         yc1 = (y0 + y1) / 2.0
         xc2 = (x1 + x2) / 2.0
         yc2 = (y1 + y2) / 2.0
         xc3 = (x2 + x3) / 2.0
         yc3 = (y2 + y3) / 2.0         
         len1 = math.sqrt((x1-x0) * (x1-x0) + (y1-y0) * (y1-y0))
         len2 = math.sqrt((x2-x1) * (x2-x1) + (y2-y1) * (y2-y1))
         len3 = math.sqrt((x3-x2) * (x3-x2) + (y3-y2) * (y3-y2))         
         k1 = len1 / (len1 + len2)
         k2 = len2 / (len2 + len3)         
         xm1 = xc1 + (xc2 - xc1) * k1
         ym1 = yc1 + (yc2 - yc1) * k1         
         xm2 = xc2 + (xc3 - xc2) * k2
         ym2 = yc2 + (yc3 - yc2) * k2         
         --Resulting control points. Here smooth_value is mentioned
         --above coefficient K whose value should be in range [0...1].
         ctrl1_x = (xm1 + (xc2 - xm1) * smooth_value + x1 - xm1)
         ctrl1_y = (ym1 + (yc2 - ym1) * smooth_value + y1 - ym1)         
         ctrl2_x = (xm2 + (xc2 - xm2) * smooth_value + x2 - xm2)
         ctrl2_y = (ym2 + (yc2 - ym2) * smooth_value + y2 - ym2)                
         Line2X = ctrl1_x 
         Line2Y = ctrl1_y                     
         Line3X = ctrl2_x
         Line3Y = ctrl2_y                          
         WindowBezier(FMapRenderSurfaceMushWindow,
         round(Line1X)..", "..round(Line1Y)..", "..round(Line2X)..", "..round(Line2Y)..", "..
         round(Line3X)..", "..round(Line3Y)..", "..round(Line4X)..", "..round(Line4Y),         
         UIMapColoursDefault.cyan, 0, 2)  -- pen         
         LinePrevX = Line1X
         LinePrevY = Line1Y                                                                
      end
   end    
   --]]                
                   
   
   
   --Render Player Position   
   if AMapBuffer.TrackingMode == false then      
      FRoomRenderColourRoom = 0x44BB44   
      local FWorldX, FWorldY, FWorldZ = AMapBuffer.RegionGetWorldPos(AMapBuffer.CurrentRegion,AMapBuffer.PlayerPositionX,AMapBuffer.PlayerPositionY,AMapBuffer.PlayerPositionZ)    
      FRenderCellMiddleX = ((FWorldX - ACameraPositionX) * UIWindowMap.CellSize) + FViewportMiddleX 
      FRenderCellMiddleY = ((FWorldY - ACameraPositionY) * UIWindowMap.CellSize) + FViewportMiddleY
      FRoomRenderPosLeft = FRenderCellMiddleX-FMapRenderCurrentCellSizeDiv2
      FRoomRenderPosTop = FRenderCellMiddleY-FMapRenderCurrentCellSizeDiv2
      FRoomRenderPosRight = FRoomRenderPosLeft + FMapRenderCurrentCellSize 
      FRoomRenderPosBottom = FRoomRenderPosTop + FMapRenderCurrentCellSize          
      if (FRoomRenderPosLeft > FViewportLeft) and (FRoomRenderPosTop > FViewportTop) and (FRoomRenderPosRight < FViewportRight) and (FRoomRenderPosBottom < FViewportBottom) then                    
         --WindowCircleOp(UIWindowMap.MushWindow,1, APositionX-FRoomRenderPlayerOutlineRadius, APositionY-FRoomRenderPlayerOutlineRadius, APositionX+FRoomRenderPlayerOutlineRadius, APositionY+FRoomRenderPlayerOutlineRadius, ColourRoomOutline/2, 0, 1, 0, 1) -- circle   
         WindowCircleOp(FMapRenderCurrentMushWindow,1, FRenderCellMiddleX-FRoomRenderPlayerRadius ,FRenderCellMiddleY-FRoomRenderPlayerRadius, FRenderCellMiddleX+FRoomRenderPlayerRadius, FRenderCellMiddleY+FRoomRenderPlayerRadius, 0x88EE88, 0, 1, FRoomRenderColourRoom, 0) -- circle            
      end
   end   
   
   
   
   --Render Selected Rooms         
   --FRoomRenderColourRoom = 0xAAAAAA      
   --for _,ARoom in pairs(AMapBuffer.SelectedRooms) do
   --   FRenderCellMiddleX = ((ARoom.RoomPositionX - ACameraPositionX) * FMapRenderCurrentCellSize) + FViewportMiddleX 
   --   FRenderCellMiddleY = ((ARoom.RoomPositionY - ACameraPositionY) * FMapRenderCurrentCellSize) + FViewportMiddleY
   --   FRoomRenderPosLeft = FRenderCellMiddleX-FMapRenderCurrentCellSizeDiv2
   --   FRoomRenderPosTop = FRenderCellMiddleY-FMapRenderCurrentCellSizeDiv2
   --   FRoomRenderPosRight = FRoomRenderPosLeft + FMapRenderCurrentCellSize 
   --   FRoomRenderPosBottom = FRoomRenderPosTop + FMapRenderCurrentCellSize          
   --   if (FRoomRenderPosLeft > FViewportLeft) and (FRoomRenderPosTop > FViewportTop) and (FRoomRenderPosRight < FViewportRight) and (FRoomRenderPosBottom < FViewportBottom) then                    
   --      --WindowCircleOp(UIWindowMap.MushWindow,1, APositionX-FRoomRenderPlayerOutlineRadius, APositionY-FRoomRenderPlayerOutlineRadius, APositionX+FRoomRenderPlayerOutlineRadius, APositionY+FRoomRenderPlayerOutlineRadius, ColourRoomOutline/2, 0, 1, 0, 1) -- circle   
   --      WindowCircleOp(FMapRenderCurrentMushWindow,1, FRenderCellMiddleX-FRoomRenderPlayerRadius ,FRenderCellMiddleY-FRoomRenderPlayerRadius, FRenderCellMiddleX+FRoomRenderPlayerRadius, FRenderCellMiddleY+FRoomRenderPlayerRadius, 0x88EE88, 0, 1, FRoomRenderColourRoom, 0) -- circle            
   --   end
   --end
      

   
   
   --Render Hovering Room
   if AMapBuffer.HoveringRoom then                                 
      local AWorldScale = AMapBuffer.RegionGetWorldScale(AMapBuffer.HoveringRoom.Region, 1)
      local ARoomX, ARoomY, ARoomZ = AMapBuffer.RegionGetWorldPos(AMapBuffer.HoveringRoom.Region,AMapBuffer.HoveringRoom.RoomPositionX,AMapBuffer.HoveringRoom.RoomPositionY,AMapBuffer.HoveringRoom.RoomPositionZ)    
      local ACellSize = UIWindowMap.CellSize / AWorldScale 
      local ACellSizeDiv2 = UIWindowMap.CellSizeDiv2 / AWorldScale           
      
      
      FRoomRenderPlayerRadius = math_max(ACellSizeDiv2, FRoomRenderPlayerMinRadius) + 1
      FRoomRenderPlayerOutlineRadius = math_max(ACellSizeDiv2, FRoomRenderPlayerMinRadius) + 1   
      FRoomRenderRoomOutlineRadius = FMapRenderCurrentCellSizeDiv2 + 1               
      
      FRoomRenderColourRoom = 0x44FF44  
       
      FRenderCellMiddleX = ((  (ARoomX) - ACameraPositionX) * UIWindowMap.CellSize) + FViewportMiddleX 
      FRenderCellMiddleY = ((  (ARoomY) - ACameraPositionY) * UIWindowMap.CellSize) + FViewportMiddleY                 
      FRoomRenderPosLeft = FRenderCellMiddleX-(ACellSizeDiv2)
      FRoomRenderPosTop = FRenderCellMiddleY-(ACellSizeDiv2)
      FRoomRenderPosRight = FRoomRenderPosLeft + (ACellSize) 
      FRoomRenderPosBottom = FRoomRenderPosTop + (ACellSize)
                  
      FRoomRenderPlayerRadius = math_max(FRoomRenderPlayerRadius, FRoomRenderPlayerMinRadius)      
                   
      if (FRoomRenderPosLeft > FViewportLeft) and (FRoomRenderPosTop > FViewportTop) and (FRoomRenderPosRight < FViewportRight) and (FRoomRenderPosBottom < FViewportBottom) then                    
      --WindowCircleOp(UIWindowMap.MushWindow,1, APositionX-FRoomRenderPlayerOutlineRadius, APositionY-FRoomRenderPlayerOutlineRadius, APositionX+FRoomRenderPlayerOutlineRadius, APositionY+FRoomRenderPlayerOutlineRadius, ColourRoomOutline/2, 0, 1, 0, 1) -- circle   
         WindowCircleOp(FMapRenderCurrentMushWindow,1, FRenderCellMiddleX-FRoomRenderPlayerRadius ,FRenderCellMiddleY-FRoomRenderPlayerRadius, FRenderCellMiddleX+FRoomRenderPlayerRadius, FRenderCellMiddleY+FRoomRenderPlayerRadius, 0x88EE88, 0, 1, FRoomRenderColourRoom, 0) -- circle            
         WindowRectOp(FMapRenderCurrentMushWindow, 1, FRenderCellMiddleX-ACellSizeDiv2, FRenderCellMiddleY-ACellSizeDiv2, FRenderCellMiddleX+ACellSizeDiv2, FRenderCellMiddleY+ACellSizeDiv2, 0x0000FF)  -- Two Colour Border               
      end      
   end     
end

--------------------------------------------------------------------------------
function UIMapRenderToTarget(
   ASurface,
   ASurfaceBuffer,   
   AMapBuffer,     
   ARegion, 
   ADelta, 
   AViewportMiddleX, 
   AViewportMiddleY, 
   AViewportLeft, 
   AViewportTop,
   AViewportRight,
   AViewportBottom)
      
   
   
   UIMapRenderCacheSetup(
      ASurface,
      ASurfaceBuffer,   
      AMapBuffer,     
      ARegion, 
      ADelta, 
      AViewportMiddleX, 
      AViewportMiddleY, 
      AViewportLeft, 
      AViewportTop,
      AViewportRight,
      AViewportBottom)
      
   FMapRenderSurface = ASurface
   FMapRenderSurfaceMushWindow = ASurface.MushWindow
   
   FMapRenderSurfaceBuffer = ASurfaceBuffer
   FMapRenderSurfaceBufferMushWindow = ASurfaceBuffer.MushWindow
         
   FMapRenderMapBuffer = AMapBuffer
            
   
   FMapRenderCurrentMushWindow = FMapRenderSurfaceMushWindow   
   FMapRenderCurrentRectColour = FMapRenderSurface.RectColour
   FMapRenderCurrentLineColour = FMapRenderSurface.LineColour 
   FMapRenderCurrentLine = FMapRenderSurface.Line
   FMapRenderCurrentRect = FMapRenderSurface.Rect
   
   FMapRenderDelta = ADelta    
   FViewportMiddleX = AViewportMiddleX 
   FViewportMiddleY = AViewportMiddleY
   FViewportLeft = AViewportLeft
   FViewportTop = AViewportTop 
   FViewportRight = AViewportRight 
   FViewportBottom = AViewportBottom
   FViewportWidth = FViewportRight-FViewportLeft
   FViewportHeight = AViewportBottom-AViewportTop
   
   
   if FRenderColourCell == nil then
      FRenderColourCell = 0x0000FF
   end
   
   UIMapRenderCellsRecurseSurface(ARegion, 1.0, 0, 0)
   UIMapRenderRoomsRecurseSurface(ARegion, 1.0, 0, 0)   
end
