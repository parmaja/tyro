--------------------------------------------------------------------------------
--//DiscUI Widget Bar 
--------------------------------------------------------------------------------

function UIWidgetBarCreate(AWindow, AWidgetLeft, AWidgetTop, AWidgetRight, AWidgetBottom)
   
    local self = UIWidgetCreate(AWindow, AWidgetLeft, AWidgetTop, AWidgetRight, AWidgetBottom)
          
   --Overrides
   
   self.WidgetType = UIWidget_Bar
   self.WidgetTypeName = "WidgetBar"
   self.SetCaption("Bar")      
   self.ColourFont = 0xFFFFFF
   
   --Additions
   
   local FFontBarName = "Consolas"
   local FFontBarHeight = 9
   
   self.Font = "FontBar" .. self.id    
   
   self.BorderSize = 5
   self.Value = 0.0
   self.ColourBar = 0x333333
   self.ColourFontShadow = 0x252525   
   
   
         
   --Callbacks         
   self.OnClick = {}   
      
   
   
   function self.SetValue(AValue)

      self.Value = AValue      
      self.Render()   
      
   end    
   
   self.RenderParent = self.Render
   function self.Render()      
      self.RenderParent()  
      
      self.Window.TextColour(0xFFFFFF)
                              
      self.Window.RectColour(self.ColourBar)
      --self.Window.Rect(self.Left,self.Top,self.Left+(self.Width*self.Value),self.Bottom)
      
      --WindowGradient (self.Window.  MushWindow, self.Left, self.Top, self.Left+(self.Width*self.Value), self.Bottom, 
      --          self.ColourBar, 
      --          ColourNameToRGB ("black"), 
      --          1)  -- left to right

--      WindowGradient (self.Window.MushWindow,self.Left, self.Top, self.Left+(((self.Width*self.Value))/3), self.Bottom,                 
--                ColourNameToRGB ("black"),
--                self.ColourBar, 
--                1)  -- left to right

                
      --self.Window.Rect(self.Left+(((self.Width*self.Value))/3) ,self.Top,self.Left+(self.Width*self.Value),self.Bottom)
      
      
    self.GradientThickness = 8
    
WindowGradient (self.Window.MushWindow,
   self.Left, self.Top , self.Left+(self.Width*self.Value),  self.Top + ((self.Height/2) - (self.GradientThickness/2)),                
                ColourNameToRGB ("black"),
                self.ColourBar, 
                2)  -- left to right
                             
      self.Window.Rect(self.Left, self.Top + ((self.Height/2) - (self.GradientThickness/2)), self.Left+(self.Width*self.Value), self.Top + ((self.Height/2) + (self.GradientThickness/2)))
      

WindowGradient (self.Window.MushWindow,
   self.Left, self.Top + ((self.Height/2) + (self.GradientThickness/2)), self.Left+(self.Width*self.Value),  self.Bottom-1,                
                self.ColourBar,
                ColourNameToRGB ("black"),                
                2)  -- left to right
      
                
                
      local APosX = self.Left + math.max((self.Width*self.Value) - (self.CaptionWidth+self.BorderSize), self.BorderSize)       
      local APosY = self.Top + (self.HeightDiv2 - self.CaptionHeightDiv2)
      
      --Render shadow
      self.Window.TextColour(self.ColourFontShadow)
      self.Window.Text(self.Caption, self.Font, APosX-1, APosY-1, APosX-1 + self.CaptionWidth, APosY-1 + self.CaptionHeight)      
      self.Window.Text(self.Caption, self.Font, APosX+1, APosY+1, APosX+1 + self.CaptionWidth, APosY+1 + self.CaptionHeight)      
      self.Window.Text(self.Caption, self.Font, APosX-1, APosY+1, APosX-1 + self.CaptionWidth, APosY+1 + self.CaptionHeight)      
      self.Window.Text(self.Caption, self.Font, APosX+1, APosY-1, APosX+1 + self.CaptionWidth, APosY-1 + self.CaptionHeight)      
      --Render text      
                  
      self.Window.TextColour(UIColourBlend(self.ColourBar, self.ColourFont, 0.7))      
      --self.Window.TextColour(self.ColourFont)
      self.Window.Text(self.Caption, self.Font, APosX, APosY, APosX + self.CaptionWidth, APosY + self.CaptionHeight)
                                    
   end
   
   --Setup Bar
   UIFontCreate(self.Window.MushWindow, self.Font, FFontBarName, FFontBarHeight, true) 
   
               
   return self      
end