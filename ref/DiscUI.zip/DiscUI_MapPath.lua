--------------------------------------------------------------------------------
--//DiscUI Map Path
--------------------------------------------------------------------------------

--local references for speed
local math_pow = math.pow
local math_sqrt = math.sqrt
   
----------------------------------------------------------------
-- local variables
----------------------------------------------------------------

local INF = 1/0
local cachedPaths = nil

----------------------------------------------------------------
-- local functions
----------------------------------------------------------------

local function dist(x1, y1, x2, y2)
   return math_sqrt(math_pow(x2-x1,2) + math_pow(y2-y1,2))      
end

local function dist_between ( nodeA, nodeB )
   return dist(nodeA.RoomPositionX, nodeA.RoomPositionY, nodeB.RoomPositionX, nodeB.RoomPositionY)
end

local function heuristic_cost_estimate ( nodeA, nodeB )
   return dist(nodeA.RoomPositionX, nodeA.RoomPositionY, nodeB.RoomPositionX, nodeB.RoomPositionY)
end

--check to see if this room is a neighbor to the targer
local function is_valid_node(node, neighbor)   
   if neighbor.ExitNorthRoom == node or neighbor.ExitNorthEastRoom == node or
      neighbor.ExitEastRoom == node or neighbor.ExitSouthEastRoom == node or
      neighbor.ExitSouthRoom == node or neighbor.ExitSouthWestRoom == node or 
      neighbor.ExitWestRoom == node or neighbor.ExitNorthWestRoom == node then        
      return true 
      
   --TODO should rely on method above only. room id's might be the same if DB write off.       
   elseif neighbor.ExitNorth == node.RoomID or neighbor.ExitNorthEast == node.RoomID or
      neighbor.ExitEast == node.RoomID or neighbor.ExitSouthEast == node.RoomID or
      neighbor.ExitSouth == node.RoomID or neighbor.ExitSouthWest == node.RoomID or 
      neighbor.ExitWest == node.RoomID or neighbor.ExitNorthWest == node.RoomID then        
      return true
   end      
   return false
end

local function lowest_f_score(set, f_score)
   local lowest, bestNode = INF, nil
   for _, node in ipairs(set) do
      local score = f_score[node]
      if score < lowest then
         lowest, bestNode = score, node
      end
   end
   return bestNode
end

--return a table of room objects that are the exists of given node
local function neighbor_nodes(theNode, nodes)
   local neighbors = {}
   
   if not theNode then return neighbors end
   
   --gets any neighbour rooms, stores object reference in room for performance/caching
   if theNode.ExitNorth > -1 then  
      if not theNode.ExitNorthRoom then theNode.ExitNorthRoom = UIMapBuffer.RoomGet(theNode.ExitNorth) end      
      if theNode.ExitNorthRoom then table.insert(neighbors,theNode.ExitNorthRoom) end        
   end
   if theNode.ExitNorthEast > -1 then
      if not theNode.ExitNorthEastRoom then theNode.ExitNorthEastRoom = UIMapBuffer.RoomGet(theNode.ExitNorthEast) end
      if theNode.ExitNorthEastRoom then table.insert(neighbors,theNode.ExitNorthEastRoom) end    
   end
   if theNode.ExitEast > -1 then
      if not theNode.ExitEastRoom then theNode.ExitEastRoom = UIMapBuffer.RoomGet(theNode.ExitEast) end
      if theNode.ExitEastRoom then table.insert(neighbors,theNode.ExitEastRoom) end
   end
   if theNode.ExitSouthEast > -1 then
      if not theNode.ExitSouthEastRoom then theNode.ExitSouthEastRoom = UIMapBuffer.RoomGet(theNode.ExitSouthEast) end
      if theNode.ExitSouthEastRoom then table.insert(neighbors,theNode.ExitSouthEastRoom) end
   end
   if theNode.ExitSouth > -1 then
      if not theNode.ExitSouthRoom then theNode.ExitSouthRoom = UIMapBuffer.RoomGet(theNode.ExitSouth) end
      if theNode.ExitSouthRoom then table.insert(neighbors,theNode.ExitSouthRoom) end
   end
   if theNode.ExitSouthWest > -1 then
      if not theNode.ExitSouthWestRoom then theNode.ExitSouthWestRoom = UIMapBuffer.RoomGet(theNode.ExitSouthWest) end
      if theNode.ExitSouthWestRoom then table.insert(neighbors,theNode.ExitSouthWestRoom) end
   end
   if theNode.ExitWest > -1 then
      if not theNode.ExitWestRoom then theNode.ExitWestRoom = UIMapBuffer.RoomGet(theNode.ExitWest) end
      if theNode.ExitWestRoom then table.insert(neighbors,theNode.ExitWestRoom) end
   end
   if theNode.ExitNorthWest > -1 then
      if not theNode.ExitNorthWestRoom then theNode.ExitNorthWestRoom = UIMapBuffer.RoomGet(theNode.ExitNorthWest) end
      if theNode.ExitNorthWestRoom then table.insert(neighbors,theNode.ExitNorthWestRoom) end
   end
   if theNode.ExitUp > -1 then
      if not theNode.ExitUpRoom then theNode.ExitUpRoom = UIMapBuffer.RoomGet(theNode.ExitUp) end
      if theNode.ExitUpRoom then table.insert(neighbors,theNode.ExitUpRoom) end
   end
   if theNode.ExitDown > -1 then
      if not theNode.ExitDownRoom then theNode.ExitDownRoom = UIMapBuffer.RoomGet(theNode.ExitDown) end
      if theNode.ExitDownRoom then table.insert(neighbors,theNode.ExitDownRoom) end
   end           
   return neighbors
end

local function not_in(set,theNode)
   for _, node in ipairs(set) do
      if node == theNode then return false end
   end
   return true
end

local function remove_node(set, theNode)
   for i, node in ipairs(set) do
      if node == theNode then 
         set[i] = set[#set]
         set[#set] = nil
         break
      end
   end   
end

local function unwind_path(flat_path, map, current_node)
   if map[current_node] then
      table.insert (flat_path, 1, map[current_node]) 
      return unwind_path(flat_path, map, map[current_node])
   else
      return flat_path
   end
end

----------------------------------------------------------------
-- pathfinding functions
----------------------------------------------------------------

local function a_star(start, goal, nodes, valid_node_func)

   local closedset = {}
   local openset = {start}
   local came_from = {}
   
   if valid_node_func then     
      is_valid_node = valid_node_func 
   end

   local g_score, f_score = {}, {}
   g_score[start] = 0
   f_score[start] = g_score[start] + heuristic_cost_estimate(start, goal)

   while #openset > 0 do     
      local current = lowest_f_score(openset, f_score)
      if current == goal then
         local path = unwind_path({}, came_from, goal)
         table.insert (path, goal)
         return path
      end
      
      remove_node (openset, current)    
      table.insert(closedset,current)
      
      local neighbors = neighbor_nodes(current, nodes)
 
      for _, neighbor in ipairs (neighbors) do 
         if not_in(closedset, neighbor) then         
            local tentative_g_score = g_score[current] + dist_between(current, neighbor)
             
            if not_in(openset, neighbor) or tentative_g_score < g_score [ neighbor ] then 
               came_from[neighbor] = current
               g_score[neighbor] = tentative_g_score
               f_score[neighbor] = g_score[neighbor] + heuristic_cost_estimate(neighbor, goal)
               if not_in(openset, neighbor) then
                  table.insert(openset, neighbor)
               end
            end
         end
      end
   end
   return nil -- no valid path
end

----------------------------------------------------------------
-- exposed functions
----------------------------------------------------------------

 function clear_cached_paths ()
   cachedPaths = nil
end

function PathFind(start, goal, nodes, ignore_cache, valid_node_func)
   if not cachedPaths then cachedPaths = {} end
   if not cachedPaths[start] then
      cachedPaths[start] = {}
   elseif cachedPaths[start][goal] and not ignore_cache then
      return cachedPaths[start][goal]
   end   
   return a_star(start, goal, nodes, valid_node_func)
end

