--------------------------------------------------------------------------------
--//DiscUI Map Vars + functions
--------------------------------------------------------------------------------

-- Global variables
UIMapExitPath = 1
UIMapExitDoor = 2
UIMapExitOther = 3
UIMapSectorSize = 16
UIMapBlankData = "                "

-- Colours
UIMapColoursDefault = {
   ['default'] = 0x303030,
   ['white'] = 0xFFFFFF,
   ['black'] = 0x000000,
   ['red'] = 0x3333AA,
   ['green'] = 0x33AA33,
   ['blue'] = 0x663333,   
   ['magenta'] = 0xAA33AA,   
   ['cyan'] = 0xAAAA33,
   ['yellow'] = 0x33AAAA,
   ['orange'] = 0x0088AA,
   ['lime'] = 0x55FF55  
}

UIMapColours = {
   [1] = UIMapColoursDefault.default,
   [2] = UIMapColoursDefault.white,
   [3] = UIMapColoursDefault.black,
   [4] = UIMapColoursDefault.red,
   [5] = UIMapColoursDefault.green,
   [6] = UIMapColoursDefault.blue,
   [7] = UIMapColoursDefault.magenta,
   [8] = UIMapColoursDefault.cyan,
   [9] = UIMapColoursDefault.yellow,
   [10] = UIMapColoursDefault.orange,
   [11] = UIMapColoursDefault.lime,         
}

UIMapColoursID = {
   ['default'] = 1,
   ['white'] = 2,
   ['black'] = 3,
   ['red'] = 4,
   ['green'] = 5,
   ['blue'] = 6,   
   ['magenta'] = 7,   
   ['cyan'] = 8,
   ['yellow'] = 9,
   ['orange'] = 10,      
   ['lime'] = 10   
}

UIMapColoursRGBToID = {
   [0xC0C0C0] = 1,
   [0xFFFFFF] = 2,
   [0x000000] = 3,
   [0x0000FF] = 4,
   [0x008000] = 5,   
   [0xFF0000] = 6,   
   [0xFF00FF] = 7,   
   [0xFFFF00] = 8,
   [0x00FFFF] = 9,
   [0x007FFF] = 10,
   [0x007FFF] = 11
}
   
ColourStreet = 0x888888
ColourTerrain = 0x222222   
ColourFill = 0x000000
ColourRoom = 0x666666
ColourRoomOutline = 0x777777

UIMapExitTypeColour = {  
   [0] = 0x0000FF, --UIMapExitError
   [1] = ColourStreet, --UIMapExitPath
   [2] = 0x3333FF, --UIMapExitDoor
   [3] = ColourRoomOutline --UIMapExitOther   
}

UIMapDirectionConvert = {  
   ['north'] = "n",
   ['n'] = "north",
   ['northeast'] = "ne",
   ['ne'] = "northeast",  
   ['east'] = "e",
   ['e'] = "east",
   ['southeast'] = "se",
   ['se'] = "southeast",
   ['south'] = "s",
   ['s'] = "south",
   ['southwest'] = "sw",
   ['sw'] = "southwest",      
   ['west'] = "w",
   ['w'] = "west",
   ['northwest'] = "nw",
   ['nw'] = "northwest",      
   ['up'] = "u",
   ['u'] = "up",  
   ['down'] = "d",
   ['d'] = "down"                 
  }
  
UIMapDirectionMin = {
   ['north'] = "n",
   ['n'] = "n",
   ['northeast'] = "ne",
   ['ne'] = "ne",  
   ['east'] = "e",
   ['e'] = "e",
   ['southeast'] = "se",
   ['se'] = "se",
   ['south'] = "s",
   ['s'] = "s",
   ['southwest'] = "sw",
   ['sw'] = "sw",      
   ['west'] = "w",
   ['w'] = "w",
   ['northwest'] = "nw",
   ['nw'] = "nw",
   ['up'] = "u",
   ['u'] = "u",
   ['down'] = "d",   
   ['d'] = "d"          
}

UIMapDirectionToVector = {
   ['n'] = {x=0,y=-1,z=0},  
   ['ne'] = {x=1,y=-1,z=0},    
   ['e'] = {x=1,y=0,z=0}, 
   ['se'] = {x=1,y=1,z=0},  
   ['s'] = {x=0,y=1,z=0},  
   ['sw'] = {x=-1,y=1,z=0},       
   ['w'] = {x=-1,y=0,z=0},
   ['nw'] = {x=-1,y=-1,z=0},
   ['u'] = {x=0,y=0,z=1},
   ['d'] = {x=0,y=0,z=-1}
}  

UIMapDirectionToExit = {
   ['n'] = "ExitNorth",
   ['ne'] = "ExitNorthEast",    
   ['e'] = "ExitEast",
   ['se'] = "ExitSouthEast",
   ['s'] = "ExitSouth", 
   ['sw'] = "ExitSouthWest",       
   ['w'] = "ExitWest",
   ['nw'] = "ExitNorthWest",
   ['u'] = "ExitUp",
   ['d'] = "ExitDown"    
}

UIMapDirectionToExitType = {
   ['n'] = "ExitNorthType",
   ['ne'] = "ExitNorthEastType",    
   ['e'] = "ExitEastType",
   ['se'] = "ExitSouthEastType",
   ['s'] = "ExitSouthType", 
   ['sw'] = "ExitSouthWestType",       
   ['w'] = "ExitWestType",
   ['nw'] = "ExitNorthWestType",
   ['u'] = "ExitUpType",
   ['d'] = "ExitDownType"    
}

UIMapDirectionToExitRoom = {
   ['n'] = "ExitNorthRoom",
   ['ne'] = "ExitNorthEastRoom",    
   ['e'] = "ExitEastRoom",
   ['se'] = "ExitSouthEastRoom",
   ['s'] = "ExitSouthRoom", 
   ['sw'] = "ExitSouthWestRoom",       
   ['w'] = "ExitWestRoom",
   ['nw'] = "ExitNorthWestRoom",
   ['u'] = "ExitUpRoom",
   ['d'] = "ExitDownRoom"     
}

UIMapDirectionOpposite = {
   ['n'] = "s",
   ['ne'] = "sw",    
   ['e'] = "w",
   ['se'] = "nw",
   ['s'] = "n", 
   ['sw'] = "ne",       
   ['w'] = "e",
   ['nw'] = "se",
   ['u'] = "d",
   ['d'] = "u",       
}


--------------------------------------------------------------------------------
--//DiscUI Map Functions
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
function UIMapGetCharExitType(AChar)
   if (AChar == "+") then
      --Exit is a door 
      return UIMapExitDoor         
   elseif (AChar == "\\") or (AChar == "/") or (AChar == "|") or (AChar == "-") or (AChar == "x") then
      --Exit is a path
      return UIMapExitPath
   else
      return UIMapExitOther      
   end                     
end
         
--------------------------------------------------------------------------------
--//Colours
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
function UIMapColoursWrite()
       
end

--------------------------------------------------------------------------------
function UIMapColoursRead()
   
end

function UIMapTrackingItemReset(ATrackingItem)
   ATrackingItem.RoomName = ""
   ATrackingItem.Exits = {}
end

--------------------------------------------------------------------------------
function UIMapRegionReset(ARegion)
   ARegion.RegionID = 0  
   ARegion.RegionName = "Region"
   ARegion.RegionStride = 2
   ARegion.RegionType = 1        
   ARegion.RegionColour = 1
   ARegion.RegionSectorLeft = 0
   ARegion.RegionSectorTop = 0
   ARegion.RegionSectorRight = 0
   ARegion.RegionSectorBottom = 0
   ARegion.RegionSectorUp = 0
   ARegion.RegionSectorDown = 0   
   ARegion.RegionParentID = 0    
   ARegion.RegionParentScale = 1.0
   ARegion.RegionParentPositionX = 0   
   ARegion.RegionParentPositionY = 0
   ARegion.RegionParentPositionZ = 0
   
   --Additions not in DB
   ARegion.RegionParent = nil
   ARegion.RegionChildren = {}
   ARegion.RegionSectorsXYZ = {}
   ARegion.RegionRoomsXYZ = {}  
   ARegion.RegionStreets = {} 
   ARegion.RegionImage = nil
   ARegion.Cached = false
end

--------------------------------------------------------------------------------
function UIMapSectorReset(ASector)           
   ASector.SectorID = 0
   ASector.RegionID = 0
   ASector.SectorPositionX = 0
   ASector.SectorPositionY = 0
   ASector.SectorPositionZ = 0
   ASector.CellLeft = 0
   ASector.CellTop = 0  
   ASector.CellRight = 0
   ASector.CellBottom = 0   
   ASector.CellUp = 0
   ASector.CellDown = 0
   ASector.SectorData = {}
   ASector.SectorDataColour = {} 
   
   for I = 1, 16 do
      table.insert(ASector.SectorData, string.sub(UIMapBlankData,1))
      table.insert(ASector.SectorDataColour, string.sub(UIMapBlankData,1))
   end  
   
   --Additions not in DB
   ASector.Region = nil   
   ASector.SectorRoomsXYZ = {}
   ASector.SectorPortalsXYZ = {}
   ASector.Cached = false                             
end

--------------------------------------------------------------------------------
function UIMapRoomReset(ARoom)
   --not read, reset table      
   ARoom.RoomID = 0
   ARoom.RegionID = 0
   ARoom.SectorID = 0   
   ARoom.RoomTypeID = 0
   ARoom.RoomSubTypeID = 0
   ARoom.RoomPositionX = 0
   ARoom.RoomPositionY = 0
   ARoom.RoomPositionZ = 0
   ARoom.RoomName = ""
   ARoom.RoomDescription = {}
   ARoom.ExitNorth = -1
   ARoom.ExitNorthType = 0
   ARoom.ExitNorthEast = -1
   ARoom.ExitNorthEastType = 0
   ARoom.ExitEast = -1
   ARoom.ExitEastType = 0
   ARoom.ExitSouthEast = -1
   ARoom.ExitSouthEastType = 0
   ARoom.ExitSouth = -1
   ARoom.ExitSouthType = 0
   ARoom.ExitSouthWest = -1
   ARoom.ExitSouthWestType = 0
   ARoom.ExitWest = -1
   ARoom.ExitWestType = 0
   ARoom.ExitNorthWest = -1
   ARoom.ExitNorthWestType = 0
   ARoom.ExitUp = -1
   ARoom.ExitUpType = 0
   ARoom.ExitDown = -1
   ARoom.ExitDownType = 0
   
   --Additions not in DB
   ARoom.Region = nil
   ARoom.Sector = nil
   ARoom.RoomStreets = {}
   ARoom.RoomPlaces = {} 
   ARoom.Selected = false     
   ARoom.ExitNorthRoom = nil   
   ARoom.ExitNorthEastRoom = nil   
   ARoom.ExitEastRoom = nil   
   ARoom.ExitSouthEastRoom = nil   
   ARoom.ExitSouthRoom = nil   
   ARoom.ExitSouthWestRoom = nil   
   ARoom.ExitWestRoom = nil   
   ARoom.ExitNorthWestRoom = nil   
   ARoom.ExitUpRoom = nil   
   ARoom.ExitDownRoom = nil  
   ARoom.Cached = false          
end

--------------------------------------------------------------------------------
function UIMapPlaceReset(APlace)        
   APlace.PlaceID = 0
   APlace.RegionID = 0
   APlace.PlaceName = "" 
     
   --Additions not in DB
   APlace.PlaceRooms = {}
   APlace.Selected = false   
end

--------------------------------------------------------------------------------
function UIMapPortalReset(APortal)
   APortal.PortalID = 0
   APortal.RegionID = 0
   APortal.SectorID = 0
   APortal.PortalActivation = 0
   APortal.PortalPositionX = 0
   APortal.PortalPositionY = 0
   APortal.PortalRoomID = 0
   APortal.PortalTargetRegionID = 0
   APortal.PortalTargetPositionX = 0
   APortal.PortalTargetPositionY = 0
   APortal.PortalTargetRoomID = 0
   
   --Additions not in DB 
   APortal.Selected = false     
end

--------------------------------------------------------------------------------
function UIMapStreetReset(AStreet)
   AStreet.StreetID = 0
   AStreet.RegionID = 0
   AStreet.StreetName = ""
   
    --Additions not in DB
   AStreet.StreetRooms = {}  
   AStreet.Selected = false
   AStreet.Cached = false
end