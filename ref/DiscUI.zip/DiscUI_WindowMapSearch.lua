--------------------------------------------------------------------------------
--//DiscUI Map Edit Window Variables
--------------------------------------------------------------------------------

UIWindowMapSearchBorderWidth = 5
UIWindowMapSearch = {}

--------------------------------------------------------------------------------
--//DiscUI Map Edit Window Functions
--------------------------------------------------------------------------------

function UIWindowMapSearchCreate(AMapBuffer)   

   --Create Window
   UIWindowMapSearch = UIWindowCreate("MapSearch", UI_BarLeftWidth, 0, 300, UI_BarTopHeight, 4)      
      
   UIWindowMapSearch.MapBuffer = AMapBuffer  
             
   UIWindowMapSearch.TitleBarText = "Map Search"
   
   local FBorderWidth = 4
   local FButtonWidth = ((UIWindowMapSearch.Width-(FBorderWidth*6))) / 6
   local FButtonHeight = 15
   local FRowTop = UIWindowMapSearch.TitleBarHeight+FBorderWidth
   local FRowBottom = UIWindowMapSearch.Height-FBorderWidth
   
   local FColumnLeft = FBorderWidth            
   local FColumnRight = UIWindowMapSearch.Width - FBorderWidth                         
        
   UIWindowMapSearch.ListviewRoomSearch = UIWindowMapSearch.WidgetCreate(UIWidget_Listview, 
      FColumnLeft, 
      FRowTop, 
      FColumnRight, 
      FRowBottom-((FButtonHeight+FBorderWidth)*2))
  
   UIWindowMapSearch.ListviewRoomSearch.OnItemSelect = OnListviewItemSelect
  
   UIWindowMapSearch.EditBoxRoomSearch = UIWindowMapSearch.WidgetCreate(UIWidget_Editbox, 
      FColumnLeft, 
      UIWindowMapSearch.ListviewRoomSearch.Bottom+FBorderWidth,
      FColumnRight,
      UIWindowMapSearch.ListviewRoomSearch.Bottom+FBorderWidth+FButtonHeight)
      
   UIWindowMapSearch.ButtonRoomSearch = UIWindowMapSearch.WidgetCreate(UIWidget_Button, 
      FColumnLeft, 
      UIWindowMapSearch.EditBoxRoomSearch.Bottom+FBorderWidth, 
      FColumnRight, 
      UIWindowMapSearch.EditBoxRoomSearch.Bottom+FBorderWidth+FButtonHeight)
      
   UIWindowMapSearch.ButtonRoomSearch.SetCaption("Room Search")
   UIWindowMapSearch.ButtonRoomSearch.OnMouseButton = ButtonRoomSearchMouseButton
   
   
   -- Assign Callbacks ()
   
   UIWindowMapSearch.Render()         
   UIWindowMapSearch.Show()   
end


local co = nil

function TickleCo() 
   if co and UIWindowMap.CameraAnimateFlag then
      if coroutine.status (co) == "suspended" then   
         coroutine.resume(co)
      end
  end
end


function OnListviewItemSelect(AItem)

   --get selected room
   
   local ARoom = AItem.Data
   local ARegion = ARoom.Region
   local AOffsetX = 0
   local AOffsetY = 0
   local AScale = 1.0
      
   while ARegion do                        
      world.Note(ARegion.RegionName)
      AScale = AScale * ARegion.RegionParentScale
      AOffsetX = ARegion.RegionParentPositionX + (AOffsetX*ARegion.RegionParentScale)
      AOffsetY = ARegion.RegionParentPositionY + (AOffsetY*ARegion.RegionParentScale)       
      ARegion = ARegion.RegionParent      
   end
   
   AOffsetX = AOffsetX + (ARoom.RoomPositionX * AScale)
   AOffsetY = AOffsetY + (ARoom.RoomPositionY * AScale)
         
   world.Note("ITEM SELECTED : " .. AItem.Text)
   world.Note("ROOM : " .. ARoom.RoomName)   
   
   UIWindowMapSearch.Render()
   Repaint()
   
   UIWindowMap.CameraAnimateTo(AOffsetX, AOffsetY, 2)
   
   UIWindowMap.AnimNow = UIMushGetTime()
   --temp declared in windowmap
   
   
    co = coroutine.create(
    
    function ()
    
      while (1==1) do
      
         local AStamp = UIMushGetTime()
         local BStamp = AStamp
                     
         while (BStamp-AStamp < 0.1) do            
            --world.Note("CO ROUTINE")         
                        
            UIWindowMap.Render()         
            Repaint()
                        
            if not UIWindowMap.CameraAnimateFlag then 
               coroutine.yield()
            end   
      
            BStamp = UIMushGetTime()
         end
         coroutine.yield()
          
      end     
    end)    
    
    coroutine.resume(co)

end

function ButtonRoomSearchMouseButton(AMouseX, AMouseY, Button, State)
   UIMushCaptureKeyboard(false)
   
   if UIMapBuffer.SelectedRooms then
      for I,Room in pairs(UIMapBuffer.SelectedRooms) do
         Room.Selected = false      
      end
   end
   
   UIMapBuffer.SelectedRooms = {}
         
   UIWindowMapSearch.ListviewRoomSearch.Lines = {} 
   for I, Room in pairs(UIMapBuffer.Rooms) do
      if string.find(string.lower(Room.RoomName),string.lower(UIWindowMapSearch.EditBoxRoomSearch.Caption)) then
         UIWindowMapSearch.ListviewRoomSearch.LineAdd(Room.RoomName, Room)
         table.insert(UIMapBuffer.SelectedRooms,Room)
         Room.Selected = true
      end           
   end
   UIWindowMapSearch.Render()
   UIWindowMap.Render()
   Repaint()
   --Redraw()
   
end

